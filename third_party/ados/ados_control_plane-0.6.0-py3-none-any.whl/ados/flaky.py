from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field

from .event_store import EventStore, _iso, _utcnow


@dataclass
class FailureLoopDetector:
    max_history: int = 20
    loop_threshold: int = 3
    stop_threshold: int = 5
    _history: deque[str] = field(default_factory=deque)

    def add(self, signature: str) -> str:
        if len(self._history) >= self.max_history:
            self._history.popleft()
        self._history.append(signature)
        count = Counter(self._history)[signature]
        if count >= self.stop_threshold:
            return "AUTONOMY_STOPPED"
        if count >= self.loop_threshold:
            return "REPAIR_LOOP_DETECTED"
        return "CONTINUE"


@dataclass
class FlakeTracker:
    outcomes: dict[str, list[bool]] = field(default_factory=dict)

    def record(self, test_id: str, passed: bool) -> None:
        self.outcomes.setdefault(test_id, []).append(passed)
        self.outcomes[test_id] = self.outcomes[test_id][-50:]

    def flake_probability(self, test_id: str) -> float:
        vals = self.outcomes.get(test_id, [])
        if len(vals) < 4:
            return 0.0
        transitions = sum(1 for a, b in zip(vals, vals[1:]) if a != b)
        return transitions / (len(vals) - 1)

    def is_flaky(self, test_id: str, threshold: float = 0.25) -> bool:
        return self.flake_probability(test_id) >= threshold


class PersistentFlakeTracker:
    """SQLite-backed flake history capped per test id."""

    def __init__(self, store: EventStore, *, max_history: int = 50):
        if max_history < 4:
            raise ValueError("max_history must be >= 4")
        self.store = store
        self.max_history = max_history

    def record(self, test_id: str, passed: bool) -> None:
        if not test_id:
            raise ValueError("test_id is required")
        with self.store.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            cx.execute(
                "INSERT INTO flake_outcomes(test_id,passed,recorded_at) VALUES(?,?,?)",
                (test_id, 1 if passed else 0, _iso(_utcnow())),
            )
            cx.execute(
                """DELETE FROM flake_outcomes
                   WHERE test_id=? AND id NOT IN (
                       SELECT id FROM flake_outcomes WHERE test_id=? ORDER BY id DESC LIMIT ?
                   )""",
                (test_id, test_id, self.max_history),
            )

    def outcomes(self, test_id: str) -> list[bool]:
        with self.store.session() as cx:
            rows = cx.execute(
                "SELECT passed FROM flake_outcomes WHERE test_id=? ORDER BY id",
                (test_id,),
            ).fetchall()
        return [bool(row["passed"]) for row in rows]

    def flake_probability(self, test_id: str) -> float:
        vals = self.outcomes(test_id)
        if len(vals) < 4:
            return 0.0
        transitions = sum(1 for a, b in zip(vals, vals[1:]) if a != b)
        return transitions / (len(vals) - 1)

    def is_flaky(self, test_id: str, threshold: float = 0.25) -> bool:
        return self.flake_probability(test_id) >= threshold


class PersistentFailureLoopDetector:
    """Durable repair-loop detector scoped by task id."""

    def __init__(self, store: EventStore, *, max_history: int = 20, loop_threshold: int = 3, stop_threshold: int = 5):
        if not (1 <= loop_threshold <= stop_threshold <= max_history):
            raise ValueError("require 1 <= loop_threshold <= stop_threshold <= max_history")
        self.store = store
        self.max_history = max_history
        self.loop_threshold = loop_threshold
        self.stop_threshold = stop_threshold

    def add(self, task_id: str, signature: str) -> str:
        if not task_id or not signature:
            raise ValueError("task_id and signature are required")
        with self.store.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            cx.execute(
                "INSERT INTO repair_failures(task_id,signature,recorded_at) VALUES(?,?,?)",
                (task_id, signature, _iso(_utcnow())),
            )
            cx.execute(
                """DELETE FROM repair_failures
                   WHERE task_id=? AND id NOT IN (
                       SELECT id FROM repair_failures WHERE task_id=? ORDER BY id DESC LIMIT ?
                   )""",
                (task_id, task_id, self.max_history),
            )
            row = cx.execute(
                "SELECT COUNT(*) AS n FROM repair_failures WHERE task_id=? AND signature=?",
                (task_id, signature),
            ).fetchone()
            count = int(row["n"])
        if count >= self.stop_threshold:
            return "AUTONOMY_STOPPED"
        if count >= self.loop_threshold:
            return "REPAIR_LOOP_DETECTED"
        return "CONTINUE"
