from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class IdempotencyStore:
    processed: set[str] = field(default_factory=set)

    def accept(self, event_id: str) -> bool:
        if event_id in self.processed:
            return False
        self.processed.add(event_id)
        return True


@dataclass
class ReconciliationCursor:
    value: str | None = None

    def advance(self, new_value: str) -> None:
        self.value = new_value


def exponential_backoff(attempt: int, base_seconds: float = 1.0, cap_seconds: float = 300.0) -> float:
    return min(cap_seconds, base_seconds * (2 ** max(0, attempt - 1)))


def classify_provider_error(status_code: int) -> str:
    if status_code in {401, 403}:
        return "AUTH_OR_PERMISSION"
    if status_code == 429:
        return "RATE_LIMIT"
    if 500 <= status_code <= 599:
        return "PROVIDER_TRANSIENT"
    if 400 <= status_code <= 499:
        return "PERMANENT_INPUT_ERROR"
    return "UNKNOWN"
