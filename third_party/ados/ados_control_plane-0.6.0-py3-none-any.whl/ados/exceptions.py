from __future__ import annotations

import base64
import hashlib
import hmac
import json
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

from .crypto import sign_ed25519, verify_ed25519


MIN_BREAK_GLASS_SECRET_BYTES = 32


@dataclass(frozen=True)
class ControlledException:
    exception_id: str
    rule_id: str
    scope: str
    approved_by: tuple[str, ...]
    reason: str
    expires_at: str
    irreversible: bool = False
    signature: str | None = None  # legacy HMAC; reversible/dev only
    approval_signatures: tuple[str, ...] = ()  # "approver_id:<base64-ed25519>"

    def unsigned_payload(self) -> bytes:
        data = asdict(self)
        data.pop("signature", None)
        data.pop("approval_signatures", None)
        return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

    def approver_payload(self, approver_id: str) -> bytes:
        return self.unsigned_payload() + b"\nAPPROVER:" + approver_id.encode("utf-8")

    def signed(self, secret: bytes) -> "ControlledException":
        """Legacy shared-secret approval for reversible development exceptions."""
        if len(secret) < MIN_BREAK_GLASS_SECRET_BYTES:
            raise ValueError(f"break-glass signing secret must be at least {MIN_BREAK_GLASS_SECRET_BYTES} bytes")
        if self.irreversible:
            raise ValueError("irreversible break-glass exceptions require independent Ed25519 approver signatures")
        sig = hmac.new(secret, self.unsigned_payload(), hashlib.sha256).hexdigest()
        return replace(self, signature=sig)

    def add_approval(self, approver_id: str, private_key_pem: bytes) -> "ControlledException":
        if not approver_id or approver_id not in self.approved_by:
            raise ValueError("approver_id must be listed in approved_by")
        signature, _ = sign_ed25519(self.approver_payload(approver_id), private_key_pem)
        retained = [item for item in self.approval_signatures if not item.startswith(approver_id + ":")]
        retained.append(f"{approver_id}:{signature}")
        return replace(self, approval_signatures=tuple(sorted(retained)))

    def signature_valid(self, secret: bytes) -> bool:
        if not self.signature or len(secret) < MIN_BREAK_GLASS_SECRET_BYTES:
            return False
        expected = hmac.new(secret, self.unsigned_payload(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(self.signature, expected)

    def valid_approvers(self, approval_public_keys: Mapping[str, bytes] | None) -> set[str]:
        if not approval_public_keys:
            return set()
        valid: set[str] = set()
        for item in self.approval_signatures:
            if ":" not in item:
                continue
            approver_id, signature = item.rsplit(":", 1)
            if approver_id not in self.approved_by:
                continue
            key = approval_public_keys.get(approver_id)
            if key and verify_ed25519(self.approver_payload(approver_id), signature, key):
                valid.add(approver_id)
        return valid

    def is_valid(
        self,
        now: datetime | None = None,
        require_two_person_for_irreversible: bool = True,
        secret: bytes | None = None,
        approval_public_keys: Mapping[str, bytes] | None = None,
        require_signature: bool = True,
    ) -> bool:
        now = now or datetime.now(timezone.utc)
        expiry = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
        if now >= expiry or not self.approved_by:
            return False
        valid_approvers = self.valid_approvers(approval_public_keys)
        if self.irreversible:
            required = 2 if require_two_person_for_irreversible else 1
            return len(valid_approvers) >= required
        if valid_approvers:
            return True
        if require_signature:
            return secret is not None and self.signature_valid(secret)
        return secret is None or self.signature_valid(secret)

    def to_file(self, path: str | Path) -> None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(asdict(self), sort_keys=True, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    @classmethod
    def from_file(cls, path: str | Path) -> "ControlledException":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        raw["approved_by"] = tuple(raw.get("approved_by", ()))
        raw["approval_signatures"] = tuple(raw.get("approval_signatures", ()))
        return cls(**raw)
