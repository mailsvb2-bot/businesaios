from __future__ import annotations

import hashlib
from contextlib import contextmanager
import json
import sqlite3
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .models import Evidence, Lease


MAX_LEASE_TTL_SECONDS = 86_400


SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS task_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    generation INTEGER,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    prev_hash TEXT,
    event_hash TEXT
);
CREATE INDEX IF NOT EXISTS idx_task_events_task ON task_events(task_id, id);

CREATE TABLE IF NOT EXISTS evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    claim TEXT NOT NULL,
    repository TEXT NOT NULL,
    subject_sha TEXT NOT NULL,
    subject_tree TEXT,
    generation INTEGER,
    source TEXT NOT NULL,
    conclusion TEXT NOT NULL,
    verified_at TEXT NOT NULL,
    run_id TEXT,
    artifact_digest TEXT,
    context_hash TEXT,
    inputs_hash TEXT,
    tags_json TEXT NOT NULL,
    ttl_seconds INTEGER,
    signature TEXT,
    signature_algorithm TEXT NOT NULL DEFAULT 'hmac-sha256',
    signer_id TEXT,
    control_plane_version TEXT,
    policy_digest TEXT,
    provenance_digest TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_evidence_claim_repo_sha ON evidence(claim, repository, subject_sha);

CREATE TABLE IF NOT EXISTS leases (
    task_id TEXT NOT NULL,
    scope TEXT NOT NULL,
    holder TEXT NOT NULL,
    generation INTEGER NOT NULL,
    expires_at TEXT NOT NULL,
    fencing_token INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(task_id, scope)
);

CREATE TABLE IF NOT EXISTS idempotency_events (
    namespace TEXT NOT NULL,
    event_id TEXT NOT NULL,
    first_seen_at TEXT NOT NULL,
    PRIMARY KEY(namespace, event_id)
);

CREATE TABLE IF NOT EXISTS reconciliation_cursors (
    namespace TEXT PRIMARY KEY,
    cursor_value TEXT,
    version INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS feature_flags (
    name TEXT PRIMARY KEY,
    stage TEXT NOT NULL,
    kill_switch INTEGER NOT NULL DEFAULT 0,
    version INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS flake_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_id TEXT NOT NULL,
    passed INTEGER NOT NULL,
    recorded_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_flake_outcomes_test ON flake_outcomes(test_id, id DESC);

CREATE TABLE IF NOT EXISTS repair_failures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    signature TEXT NOT NULL,
    recorded_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_repair_failures_task ON repair_failures(task_id, id DESC);

CREATE TABLE IF NOT EXISTS scheduled_tasks (
    task_id TEXT PRIMARY KEY,
    components_json TEXT NOT NULL,
    dependencies_json TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 0,
    execution_kind TEXT NOT NULL DEFAULT 'IDEMPOTENT',
    idempotency_key TEXT,
    status TEXT NOT NULL DEFAULT 'PENDING',
    holder TEXT,
    lease_expires_at TEXT,
    fencing_token INTEGER NOT NULL DEFAULT 0,
    attempts INTEGER NOT NULL DEFAULT 0,
    version INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_scheduled_tasks_status_priority ON scheduled_tasks(status, priority DESC, task_id);

CREATE TABLE IF NOT EXISTS control_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stream TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    prev_hash TEXT,
    event_hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_control_events_stream ON control_events(stream, id);

CREATE TABLE IF NOT EXISTS control_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TRIGGER IF NOT EXISTS task_events_no_update
BEFORE UPDATE ON task_events BEGIN
    SELECT RAISE(ABORT, 'task_events is append-only');
END;
CREATE TRIGGER IF NOT EXISTS task_events_no_delete
BEFORE DELETE ON task_events BEGIN
    SELECT RAISE(ABORT, 'task_events is append-only');
END;
CREATE TRIGGER IF NOT EXISTS evidence_no_update
BEFORE UPDATE ON evidence BEGIN
    SELECT RAISE(ABORT, 'evidence is append-only');
END;
CREATE TRIGGER IF NOT EXISTS evidence_no_delete
BEFORE DELETE ON evidence BEGIN
    SELECT RAISE(ABORT, 'evidence is append-only');
END;
CREATE TRIGGER IF NOT EXISTS control_events_no_update
BEFORE UPDATE ON control_events BEGIN
    SELECT RAISE(ABORT, 'control_events is append-only');
END;
CREATE TRIGGER IF NOT EXISTS control_events_no_delete
BEFORE DELETE ON control_events BEGIN
    SELECT RAISE(ABORT, 'control_events is append-only');
END;
"""


class ConcurrencyConflict(RuntimeError):
    pass


class LeaseConflict(RuntimeError):
    pass


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(ts: str) -> datetime:
    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _event_hash(task_id: str, event_type: str, generation: int | None, payload_json: str, created_at: str, prev_hash: str | None) -> str:
    material = json.dumps(
        {
            "task_id": task_id,
            "event_type": event_type,
            "generation": generation,
            "payload_json": payload_json,
            "created_at": created_at,
            "prev_hash": prev_hash,
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


def _control_event_hash(stream: str, event_type: str, payload_json: str, created_at: str, prev_hash: str | None) -> str:
    material = json.dumps(
        {
            "stream": stream,
            "event_type": event_type,
            "payload_json": payload_json,
            "created_at": created_at,
            "prev_hash": prev_hash,
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


class ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc, tb):
        try:
            return super().__exit__(exc_type, exc, tb)
        finally:
            self.close()


class EventStore:
    def __init__(self, path: str | Path):
        self.path = str(path)
        parent = Path(self.path).parent
        parent.mkdir(parents=True, exist_ok=True)
        self.journal_mode = self._probe_journal_mode(parent)
        with self.session() as cx:
            cx.execute(f"PRAGMA journal_mode={self.journal_mode.upper()}")
            cx.executescript(SCHEMA)
            self._migrate(cx)

    @staticmethod
    def _probe_journal_mode(directory: Path) -> str:
        """Return WAL when the filesystem really supports it, else DELETE.

        Probe a disposable database rather than the control-plane database.
        On filesystems that reject WAL, SQLite can leave the attempted database
        connection unusable; probing out-of-band avoids poisoning the real DB.
        """
        import tempfile

        fd, raw_path = tempfile.mkstemp(prefix=".ados-sqlite-probe-", suffix=".db", dir=directory)
        import os
        os.close(fd)
        probe = Path(raw_path)
        mode = "delete"
        cx = None
        try:
            cx = sqlite3.connect(str(probe), timeout=5.0)
            row = cx.execute("PRAGMA journal_mode=WAL").fetchone()
            if row and str(row[0]).lower() == "wal":
                cx.execute("CREATE TABLE IF NOT EXISTS probe(x INTEGER)")
                cx.execute("INSERT INTO probe(x) VALUES(1)")
                cx.commit()
                mode = "wal"
        except sqlite3.Error:
            mode = "delete"
        finally:
            if cx is not None:
                try:
                    cx.close()
                except sqlite3.Error:
                    pass
            for suffix in ("", "-wal", "-shm"):
                try:
                    Path(str(probe) + suffix).unlink()
                except FileNotFoundError:
                    pass
                except OSError:
                    pass
        return mode

    def _migrate(self, cx: sqlite3.Connection) -> None:
        def ensure_column(table: str, column: str, ddl: str) -> None:
            cols = {row[1] for row in cx.execute(f"PRAGMA table_info({table})").fetchall()}
            if column not in cols:
                cx.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")

        ensure_column("task_events", "prev_hash", "prev_hash TEXT")
        ensure_column("task_events", "event_hash", "event_hash TEXT")
        ensure_column("evidence", "signature_algorithm", "signature_algorithm TEXT NOT NULL DEFAULT 'hmac-sha256'")
        ensure_column("evidence", "signer_id", "signer_id TEXT")
        ensure_column("evidence", "control_plane_version", "control_plane_version TEXT")
        ensure_column("evidence", "policy_digest", "policy_digest TEXT")
        ensure_column("evidence", "provenance_digest", "provenance_digest TEXT")
        ensure_column("leases", "fencing_token", "fencing_token INTEGER NOT NULL DEFAULT 0")
        ensure_column("scheduled_tasks", "execution_kind", "execution_kind TEXT NOT NULL DEFAULT 'IDEMPOTENT'")
        ensure_column("scheduled_tasks", "idempotency_key", "idempotency_key TEXT")
        ensure_column("scheduled_tasks", "fencing_token", "fencing_token INTEGER NOT NULL DEFAULT 0")
        ensure_column("scheduled_tasks", "attempts", "attempts INTEGER NOT NULL DEFAULT 0")
        ensure_column("scheduled_tasks", "created_at", "created_at TEXT")
        cx.execute("UPDATE scheduled_tasks SET created_at=COALESCE(created_at, updated_at) WHERE created_at IS NULL")

    def connect(self) -> sqlite3.Connection:
        cx = sqlite3.connect(self.path, timeout=30.0, factory=ClosingConnection)
        cx.row_factory = sqlite3.Row
        cx.execute("PRAGMA foreign_keys=ON")
        cx.execute("PRAGMA busy_timeout=30000")
        return cx

    @contextmanager
    def session(self):
        cx = self.connect()
        try:
            yield cx
            cx.commit()
        except Exception:
            cx.rollback()
            raise
        finally:
            cx.close()

    def append_event(
        self,
        task_id: str,
        event_type: str,
        payload: dict[str, Any],
        generation: int | None = None,
        *,
        expected_last_id: int | None = None,
    ) -> int:
        payload_json = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        created_at = _iso(_utcnow())
        with self.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            row = cx.execute(
                "SELECT id,event_hash FROM task_events WHERE task_id=? ORDER BY id DESC LIMIT 1",
                (task_id,),
            ).fetchone()
            last_id = int(row["id"]) if row else 0
            prev_hash = row["event_hash"] if row else None
            if expected_last_id is not None and last_id != expected_last_id:
                raise ConcurrencyConflict(f"task {task_id!r} stale version: expected last_event_id={expected_last_id}, actual={last_id}")
            digest = _event_hash(task_id, event_type, generation, payload_json, created_at, prev_hash)
            cur = cx.execute(
                """INSERT INTO task_events(task_id,event_type,generation,payload_json,created_at,prev_hash,event_hash)
                   VALUES(?,?,?,?,?,?,?)""",
                (task_id, event_type, generation, payload_json, created_at, prev_hash, digest),
            )
            cx.commit()
            return int(cur.lastrowid)

    def events(self, task_id: str) -> list[dict[str, Any]]:
        with self.session() as cx:
            rows = cx.execute(
                "SELECT id,event_type,generation,payload_json,created_at,prev_hash,event_hash FROM task_events WHERE task_id=? ORDER BY id",
                (task_id,),
            ).fetchall()
        return [
            {
                "id": row["id"],
                "event_type": row["event_type"],
                "generation": row["generation"],
                "payload": json.loads(row["payload_json"]),
                "payload_json": row["payload_json"],
                "created_at": row["created_at"],
                "prev_hash": row["prev_hash"],
                "event_hash": row["event_hash"],
            }
            for row in rows
        ]

    def last_event_id(self, task_id: str) -> int:
        with self.session() as cx:
            row = cx.execute("SELECT id FROM task_events WHERE task_id=? ORDER BY id DESC LIMIT 1", (task_id,)).fetchone()
        return int(row["id"]) if row else 0

    def verify_event_chain(self, task_id: str) -> bool:
        events = self.events(task_id)
        if not events:
            return False
        prev_hash: str | None = None
        for event in events:
            # Legacy events written before chain support cannot be trusted as part of a verified chain.
            if not event["event_hash"]:
                return False
            if event["prev_hash"] != prev_hash:
                return False
            expected = _event_hash(
                task_id,
                event["event_type"],
                event["generation"],
                event["payload_json"],
                event["created_at"],
                prev_hash,
            )
            if expected != event["event_hash"]:
                return False
            prev_hash = event["event_hash"]
        return True

    def append_control_event(
        self,
        stream: str,
        event_type: str,
        payload: dict[str, Any],
        *,
        connection: sqlite3.Connection | None = None,
    ) -> int:
        if not stream or not event_type:
            raise ValueError("stream and event_type are required")
        payload_json = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        created_at = _iso(_utcnow())

        def write(cx: sqlite3.Connection) -> int:
            row = cx.execute(
                "SELECT event_hash FROM control_events WHERE stream=? ORDER BY id DESC LIMIT 1",
                (stream,),
            ).fetchone()
            prev_hash = row["event_hash"] if row else None
            digest = _control_event_hash(stream, event_type, payload_json, created_at, prev_hash)
            cur = cx.execute(
                """INSERT INTO control_events(stream,event_type,payload_json,created_at,prev_hash,event_hash)
                   VALUES(?,?,?,?,?,?)""",
                (stream, event_type, payload_json, created_at, prev_hash, digest),
            )
            return int(cur.lastrowid)

        if connection is not None:
            return write(connection)
        with self.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            return write(cx)

    def control_events(self, stream: str) -> list[dict[str, Any]]:
        with self.session() as cx:
            rows = cx.execute(
                "SELECT id,event_type,payload_json,created_at,prev_hash,event_hash FROM control_events WHERE stream=? ORDER BY id",
                (stream,),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "event_type": row["event_type"],
                "payload": json.loads(row["payload_json"]),
                "payload_json": row["payload_json"],
                "created_at": row["created_at"],
                "prev_hash": row["prev_hash"],
                "event_hash": row["event_hash"],
            }
            for row in rows
        ]

    def verify_control_chain(self, stream: str) -> bool:
        events = self.control_events(stream)
        if not events:
            return False
        prev_hash: str | None = None
        for event in events:
            if event["prev_hash"] != prev_hash:
                return False
            expected = _control_event_hash(
                stream, event["event_type"], event["payload_json"], event["created_at"], prev_hash
            )
            if expected != event["event_hash"]:
                return False
            prev_hash = event["event_hash"]
        return True

    def record_evidence(self, ev: Evidence) -> int:
        with self.session() as cx:
            cur = cx.execute(
                """INSERT INTO evidence(
                    claim,repository,subject_sha,subject_tree,generation,source,conclusion,verified_at,run_id,
                    artifact_digest,context_hash,inputs_hash,tags_json,ttl_seconds,signature,signature_algorithm,
                    signer_id,control_plane_version,policy_digest,provenance_digest
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    ev.claim,
                    ev.repository,
                    ev.subject_sha,
                    ev.subject_tree,
                    ev.generation,
                    ev.source,
                    ev.conclusion,
                    ev.verified_at,
                    ev.run_id,
                    ev.artifact_digest,
                    ev.context_hash,
                    ev.inputs_hash,
                    json.dumps(list(ev.tags)),
                    ev.ttl_seconds,
                    ev.signature,
                    ev.signature_algorithm,
                    ev.signer_id,
                    ev.control_plane_version,
                    ev.policy_digest,
                    ev.provenance_digest,
                ),
            )
            return int(cur.lastrowid)

    def record_evidence_and_event(
        self,
        task_id: str,
        ev: Evidence,
        *,
        event_type: str,
        payload: dict[str, Any],
        generation: int | None = None,
        expected_last_id: int | None = None,
    ) -> tuple[int, int]:
        """Atomically persist signed evidence and its task-journal certification event.

        If optimistic concurrency fails, neither row is committed. This prevents a
        stale certification race from leaving otherwise-valid evidence behind.
        """
        payload_json = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        created_at = _iso(_utcnow())
        with self.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            row = cx.execute(
                "SELECT id,event_hash FROM task_events WHERE task_id=? ORDER BY id DESC LIMIT 1",
                (task_id,),
            ).fetchone()
            last_id = int(row["id"]) if row else 0
            prev_hash = row["event_hash"] if row else None
            if expected_last_id is not None and last_id != expected_last_id:
                raise ConcurrencyConflict(
                    f"task {task_id!r} stale version: expected last_event_id={expected_last_id}, actual={last_id}"
                )
            evidence_cur = cx.execute(
                """INSERT INTO evidence(
                    claim,repository,subject_sha,subject_tree,generation,source,conclusion,verified_at,run_id,
                    artifact_digest,context_hash,inputs_hash,tags_json,ttl_seconds,signature,signature_algorithm,
                    signer_id,control_plane_version,policy_digest,provenance_digest
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    ev.claim, ev.repository, ev.subject_sha, ev.subject_tree, ev.generation, ev.source,
                    ev.conclusion, ev.verified_at, ev.run_id, ev.artifact_digest, ev.context_hash, ev.inputs_hash,
                    json.dumps(list(ev.tags)), ev.ttl_seconds, ev.signature, ev.signature_algorithm,
                    ev.signer_id, ev.control_plane_version, ev.policy_digest, ev.provenance_digest,
                ),
            )
            digest = _event_hash(task_id, event_type, generation, payload_json, created_at, prev_hash)
            event_cur = cx.execute(
                """INSERT INTO task_events(task_id,event_type,generation,payload_json,created_at,prev_hash,event_hash)
                   VALUES(?,?,?,?,?,?,?)""",
                (task_id, event_type, generation, payload_json, created_at, prev_hash, digest),
            )
            return int(evidence_cur.lastrowid), int(event_cur.lastrowid)

    def evidence_for(self, claim: str, repository: str, subject_sha: str) -> list[Evidence]:
        with self.session() as cx:
            rows = cx.execute(
                "SELECT * FROM evidence WHERE claim=? AND repository=? AND subject_sha=? ORDER BY id DESC",
                (claim, repository, subject_sha),
            ).fetchall()
        return [
            Evidence(
                claim=r["claim"],
                repository=r["repository"],
                subject_sha=r["subject_sha"],
                subject_tree=r["subject_tree"],
                generation=r["generation"],
                source=r["source"],
                conclusion=r["conclusion"],
                verified_at=r["verified_at"],
                run_id=r["run_id"],
                artifact_digest=r["artifact_digest"],
                context_hash=r["context_hash"],
                inputs_hash=r["inputs_hash"],
                tags=tuple(json.loads(r["tags_json"])),
                ttl_seconds=r["ttl_seconds"],
                signature=r["signature"],
                signature_algorithm=r["signature_algorithm"],
                signer_id=r["signer_id"],
                control_plane_version=r["control_plane_version"],
                policy_digest=r["policy_digest"],
                provenance_digest=r["provenance_digest"],
            )
            for r in rows
        ]


    def assert_clock_sane(self, max_backward_seconds: int = 300) -> None:
        """Fail closed if wall clock moved materially backwards since last trusted use.

        Forward jumps may expire work early but cannot resurrect stale evidence. A
        backward jump is more dangerous because it can extend leases/evidence, so
        the control plane records the maximum observed UTC timestamp.
        """
        now = _utcnow()
        now_iso = _iso(now)
        with self.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            row = cx.execute("SELECT value FROM control_meta WHERE key='clock:last_seen_utc'").fetchone()
            if row is not None:
                previous = _parse(row["value"])
                if (previous - now).total_seconds() > max_backward_seconds:
                    raise RuntimeError(
                        f"system clock moved backwards beyond allowed skew: previous={_iso(previous)} now={now_iso}"
                    )
                if now <= previous:
                    return
            cx.execute(
                """INSERT INTO control_meta(key,value,updated_at) VALUES('clock:last_seen_utc',?,?)
                   ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at""",
                (now_iso, now_iso),
            )

    def accept_idempotent_event(self, namespace: str, event_id: str) -> bool:
        if not namespace or not event_id:
            raise ValueError("namespace and event_id are required")
        with self.session() as cx:
            try:
                cx.execute(
                    "INSERT INTO idempotency_events(namespace,event_id,first_seen_at) VALUES(?,?,?)",
                    (namespace, event_id, _iso(_utcnow())),
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def reconciliation_cursor(self, namespace: str) -> tuple[str | None, int]:
        with self.session() as cx:
            row = cx.execute("SELECT cursor_value,version FROM reconciliation_cursors WHERE namespace=?", (namespace,)).fetchone()
        if row is None:
            return None, 0
        return row["cursor_value"], int(row["version"])

    def advance_reconciliation_cursor(self, namespace: str, new_value: str, *, expected_version: int) -> int:
        with self.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            row = cx.execute("SELECT version FROM reconciliation_cursors WHERE namespace=?", (namespace,)).fetchone()
            actual = int(row["version"]) if row else 0
            if actual != expected_version:
                raise ConcurrencyConflict(f"cursor {namespace!r} stale version: expected={expected_version}, actual={actual}")
            new_version = actual + 1
            cx.execute(
                """INSERT INTO reconciliation_cursors(namespace,cursor_value,version,updated_at) VALUES(?,?,?,?)
                   ON CONFLICT(namespace) DO UPDATE SET cursor_value=excluded.cursor_value,version=excluded.version,updated_at=excluded.updated_at""",
                (namespace, new_value, new_version, _iso(_utcnow())),
            )
            cx.commit()
            return new_version

    def require_lease(self, task_id: str, scope: str, holder: str, generation: int) -> Lease:
        lease = self.lease(task_id, scope)
        if lease is None:
            raise LeaseConflict(f"active lease {task_id}:{scope} required")
        if lease.holder != holder:
            raise LeaseConflict(f"lease {task_id}:{scope} held by {lease.holder!r}, not {holder!r}")
        if lease.generation != generation:
            raise LeaseConflict(f"lease generation stale: held={lease.generation} required={generation}")
        return lease

    def acquire_lease(self, task_id: str, scope: str, holder: str, generation: int, ttl_seconds: int = 900) -> Lease:
        if not task_id or not scope or not holder:
            raise ValueError("task_id, scope and holder are required")
        if ttl_seconds <= 0 or ttl_seconds > MAX_LEASE_TTL_SECONDS:
            raise ValueError(f"ttl_seconds must be > 0 and <= {MAX_LEASE_TTL_SECONDS}")
        self.assert_clock_sane()
        now = _utcnow(); expires = now + timedelta(seconds=ttl_seconds)
        with self.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            row = cx.execute("SELECT * FROM leases WHERE task_id=? AND scope=?", (task_id, scope)).fetchone()
            if row is not None and _parse(row["expires_at"]) > now and row["holder"] != holder:
                raise LeaseConflict(f"lease {task_id}:{scope} held by {row['holder']!r} until {row['expires_at']}")
            fence = (int(row["fencing_token"]) if row is not None else 0) + 1
            cx.execute(
                """INSERT INTO leases(task_id,scope,holder,generation,expires_at,fencing_token) VALUES(?,?,?,?,?,?)
                   ON CONFLICT(task_id,scope) DO UPDATE SET holder=excluded.holder,generation=excluded.generation,
                       expires_at=excluded.expires_at,fencing_token=excluded.fencing_token""",
                (task_id, scope, holder, generation, _iso(expires), fence),
            )
        return Lease(task_id, scope, holder, generation, _iso(expires), fence)

    def renew_lease(self, task_id: str, scope: str, holder: str, generation: int, ttl_seconds: int = 900) -> Lease:
        if not task_id or not scope or not holder:
            raise ValueError("task_id, scope and holder are required")
        if ttl_seconds <= 0 or ttl_seconds > MAX_LEASE_TTL_SECONDS:
            raise ValueError(f"ttl_seconds must be > 0 and <= {MAX_LEASE_TTL_SECONDS}")
        self.assert_clock_sane()
        now = _utcnow(); expires = now + timedelta(seconds=ttl_seconds)
        with self.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            row = cx.execute("SELECT * FROM leases WHERE task_id=? AND scope=?", (task_id, scope)).fetchone()
            if row is None or row["holder"] != holder:
                raise LeaseConflict(f"lease {task_id}:{scope} is not held by {holder!r}")
            if int(row["generation"]) != generation:
                raise LeaseConflict(f"lease generation stale: held={row['generation']} requested={generation}")
            if _parse(row["expires_at"]) <= now:
                raise LeaseConflict(f"lease {task_id}:{scope} expired at {row['expires_at']}")
            fence = int(row["fencing_token"])
            cx.execute("UPDATE leases SET expires_at=? WHERE task_id=? AND scope=?", (_iso(expires), task_id, scope))
        return Lease(task_id, scope, holder, generation, _iso(expires), fence)

    def validate_fence(self, task_id: str, scope: str, holder: str, generation: int, fencing_token: int) -> Lease:
        lease = self.require_lease(task_id, scope, holder, generation)
        if lease.fencing_token != fencing_token:
            raise LeaseConflict(
                f"stale fencing token for {task_id}:{scope}: supplied={fencing_token} current={lease.fencing_token}"
            )
        return lease

    def release_lease(self, task_id: str, scope: str, holder: str) -> None:
        with self.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            row = cx.execute("SELECT holder FROM leases WHERE task_id=? AND scope=?", (task_id, scope)).fetchone()
            if row is None:
                return
            if row["holder"] != holder:
                raise LeaseConflict(f"lease {task_id}:{scope} is held by {row['holder']!r}, not {holder!r}")
            cx.execute("DELETE FROM leases WHERE task_id=? AND scope=?", (task_id, scope))

    def lease(self, task_id: str, scope: str, *, include_expired: bool = False) -> Lease | None:
        with self.session() as cx:
            row = cx.execute("SELECT * FROM leases WHERE task_id=? AND scope=?", (task_id, scope)).fetchone()
        if row is None:
            return None
        lease = Lease(row["task_id"], row["scope"], row["holder"], int(row["generation"]), row["expires_at"], int(row["fencing_token"]))
        if not include_expired and _parse(lease.expires_at) <= _utcnow():
            return None
        return lease

