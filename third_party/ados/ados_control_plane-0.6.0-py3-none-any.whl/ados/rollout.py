from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ProductProfile(str, Enum):
    WEB_SAAS = "WEB_SAAS"
    DESKTOP = "DESKTOP"
    RUNTIME_LIBRARY = "RUNTIME_LIBRARY"
    BOT = "BOT"
    BACKEND_SERVICE = "BACKEND_SERVICE"
    DOCUMENT_ENGINE = "DOCUMENT_ENGINE"


@dataclass(frozen=True)
class RolloutPlan:
    profile: ProductProfile
    stages: tuple[str, ...]
    rollback_mode: str

    def __post_init__(self):
        if not self.stages or self.stages[0] != "OFF":
            raise ValueError("rollout plans must begin with OFF")
        if len(set(self.stages)) != len(self.stages):
            raise ValueError("rollout plan stages must be unique")


def default_rollout(profile: ProductProfile, rollback_safe: bool = True) -> RolloutPlan:
    if profile is ProductProfile.WEB_SAAS:
        return RolloutPlan(profile, ("OFF", "INTERNAL", "5%", "25%", "50%", "100%"), "automatic" if rollback_safe else "stop_and_forward_fix")
    if profile is ProductProfile.DESKTOP:
        return RolloutPlan(profile, ("OFF", "INTERNAL", "PILOT_RING", "STABLE_RING"), "halt_update_ring")
    if profile is ProductProfile.RUNTIME_LIBRARY:
        return RolloutPlan(profile, ("OFF", "CONTRACT_TESTS", "PILOT_CONSUMERS", "SUPPORTED_CONSUMERS"), "version_pin")
    if profile is ProductProfile.BOT:
        return RolloutPlan(profile, ("OFF", "TEST_BOT", "PILOT_CHAT", "ALL_CHATS"), "disable_feature_or_redeploy")
    if profile is ProductProfile.DOCUMENT_ENGINE:
        return RolloutPlan(profile, ("OFF", "GOLDEN_SUITE", "PILOT_TEMPLATES", "STABLE_TEMPLATES"), "version_pin")
    return RolloutPlan(profile, ("OFF", "STAGING", "PRODUCTION"), "automatic" if rollback_safe else "stop_and_forward_fix")
