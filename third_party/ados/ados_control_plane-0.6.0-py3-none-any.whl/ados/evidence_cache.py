from __future__ import annotations

from dataclasses import dataclass

from .util import stable_hash


@dataclass(frozen=True)
class EvidenceInputs:
    gate: str
    content_hashes: dict[str, str]
    dependency_versions: dict[str, str]
    policy_version: str
    environment_fingerprint: str

    def key(self) -> str:
        return stable_hash({
            "gate": self.gate,
            "content_hashes": self.content_hashes,
            "dependency_versions": self.dependency_versions,
            "policy_version": self.policy_version,
            "environment_fingerprint": self.environment_fingerprint,
        })


def reusable(previous: EvidenceInputs, current: EvidenceInputs) -> bool:
    return previous.key() == current.key()
