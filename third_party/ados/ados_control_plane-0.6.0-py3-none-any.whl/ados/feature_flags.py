from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping

from .event_store import ConcurrencyConflict, EventStore, _iso, _utcnow
from .evidence import EvidenceError, require_evidence, task_security_context_hash
from .models import Task
from .rollout import ProductProfile, RolloutPlan, default_rollout


class RolloutStage(str, Enum):
    """Legacy generic names kept for source compatibility; persistent rollout uses plan stage strings."""
    OFF = "OFF"
    INTERNAL = "INTERNAL"
    PILOT = "PILOT"
    COHORT = "COHORT"
    GENERAL = "GENERAL"


@dataclass
class FeatureFlag:
    name: str
    stage: str = "OFF"
    kill_switch: bool = False

    def advance(self, plan: RolloutPlan, health_ok: bool, required_evidence_ok: bool) -> str:
        if self.kill_switch:
            self.stage = "OFF"; return self.stage
        if not health_ok or not required_evidence_ok:
            return self.stage
        if self.stage not in plan.stages:
            raise ValueError(f"flag stage {self.stage!r} is not part of rollout plan {plan.stages}")
        idx = plan.stages.index(self.stage)
        if idx < len(plan.stages) - 1:
            self.stage = plan.stages[idx + 1]
        return self.stage

    def disable(self) -> None:
        self.stage = "OFF"


@dataclass(frozen=True)
class StoredFeatureFlag:
    flag: FeatureFlag
    version: int


class PersistentFeatureFlagStore:
    def __init__(self, store: EventStore): self.store = store

    def get(self, name: str) -> StoredFeatureFlag:
        with self.store.session() as cx:
            row = cx.execute("SELECT name,stage,kill_switch,version FROM feature_flags WHERE name=?", (name,)).fetchone()
        if row is None: return StoredFeatureFlag(FeatureFlag(name), 0)
        return StoredFeatureFlag(FeatureFlag(row["name"], str(row["stage"]), bool(row["kill_switch"])), int(row["version"]))

    def _write(self, name: str, stage: str, kill_switch: bool, *, expected_version: int) -> StoredFeatureFlag:
        now = _iso(_utcnow())
        with self.store.session() as cx:
            cx.execute("BEGIN IMMEDIATE"); row = cx.execute("SELECT version FROM feature_flags WHERE name=?", (name,)).fetchone()
            actual = int(row["version"]) if row else 0
            if actual != expected_version: raise ConcurrencyConflict(f"feature flag {name!r} stale version: expected={expected_version}, actual={actual}")
            version = actual + 1
            cx.execute("""INSERT INTO feature_flags(name,stage,kill_switch,version,updated_at) VALUES(?,?,?,?,?)
               ON CONFLICT(name) DO UPDATE SET stage=excluded.stage,kill_switch=excluded.kill_switch,version=excluded.version,updated_at=excluded.updated_at""",
               (name, stage, 1 if kill_switch else 0, version, now))
            self.store.append_control_event(f"feature:{name}", "FEATURE_FLAG_UPDATED", {"name": name, "stage": stage, "kill_switch": kill_switch, "version": version}, connection=cx)
        return self.get(name)

    def advance(
        self, name: str, *, task: Task, expected_version: int,
        plan: RolloutPlan | None = None,
        profile: ProductProfile = ProductProfile.BACKEND_SERVICE,
        signature_secret: bytes | None = None,
        verification_keys: Mapping[str, bytes] | None = None,
        require_asymmetric: bool = False,
        required_claim: str = "release_verified", health_claim: str = "rollout_health_verified",
        health_required_tags: set[str] | None = None,
        policy_digest: str | None = None,
        accepted_control_plane_versions: set[str] | None = None,
    ) -> StoredFeatureFlag:
        if task.candidate is None: raise EvidenceError("rollout task has no exact candidate")
        if task.blockers: raise EvidenceError("rollout task has durable blockers")
        candidate = task.candidate; context_hash = task_security_context_hash(task)
        require_evidence(self.store, required_claim, candidate.repository, candidate.sha,
            generation=candidate.generation, subject_tree=candidate.tree, signature_secret=signature_secret,
            verification_keys=verification_keys, require_asymmetric=require_asymmetric, context_hash=context_hash,
            policy_digest=policy_digest, required_tags={"artifact", "provenance", "release"},
            accepted_control_plane_versions=accepted_control_plane_versions)
        require_evidence(self.store, health_claim, candidate.repository, candidate.sha,
            generation=candidate.generation, subject_tree=candidate.tree, signature_secret=signature_secret,
            verification_keys=verification_keys, require_asymmetric=require_asymmetric, context_hash=context_hash,
            policy_digest=policy_digest, required_tags=health_required_tags,
            accepted_control_plane_versions=accepted_control_plane_versions)
        current = self.get(name)
        if current.version != expected_version: raise ConcurrencyConflict(f"feature flag {name!r} stale version: expected={expected_version}, actual={current.version}")
        rollout = plan or default_rollout(profile)
        flag = FeatureFlag(current.flag.name, current.flag.stage, current.flag.kill_switch); before = flag.stage
        flag.advance(rollout, True, True)
        if flag.stage == before: return current
        return self._write(name, flag.stage, flag.kill_switch, expected_version=expected_version)

    def set_kill_switch(self, name: str, enabled: bool, *, expected_version: int) -> StoredFeatureFlag:
        current = self.get(name)
        if current.version != expected_version: raise ConcurrencyConflict(f"feature flag {name!r} stale version: expected={expected_version}, actual={current.version}")
        stage = "OFF" if enabled else current.flag.stage
        if current.flag.kill_switch == enabled and current.flag.stage == stage: return current
        return self._write(name, stage, enabled, expected_version=expected_version)

    def disable(self, name: str, *, expected_version: int) -> StoredFeatureFlag:
        current = self.get(name)
        if current.version != expected_version: raise ConcurrencyConflict(f"feature flag {name!r} stale version: expected={expected_version}, actual={current.version}")
        if current.flag.stage == "OFF": return current
        return self._write(name, "OFF", current.flag.kill_switch, expected_version=expected_version)
