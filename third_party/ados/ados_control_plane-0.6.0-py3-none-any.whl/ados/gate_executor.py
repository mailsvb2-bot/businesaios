from __future__ import annotations

import multiprocessing as mp
import os
import signal
import subprocess
import time
from dataclasses import dataclass

from .gates import Gate, GateContext
from .models import GateResult, GateStatus


@dataclass(frozen=True)
class GateExecutionPolicy:
    max_workers: int = 4
    timeout_seconds: float = 1800.0
    start_method: str = "spawn"
    hard_timeout_seconds: float = 21_600.0

    def __post_init__(self):
        if self.max_workers < 1 or self.max_workers > 64:
            raise ValueError("max_workers must be between 1 and 64")
        if self.timeout_seconds <= 0 or self.timeout_seconds > 21_600:
            raise ValueError("timeout_seconds must be > 0 and <= 21600")
        if self.hard_timeout_seconds < self.timeout_seconds or self.hard_timeout_seconds > 86_400:
            raise ValueError("hard_timeout_seconds must be >= timeout_seconds and <=86400")
        if self.start_method not in {"spawn", "forkserver"}:
            raise ValueError("start_method must be 'spawn' or 'forkserver'; raw fork is unsafe for the control plane")
        if self.start_method not in mp.get_all_start_methods():
            raise ValueError(f"start_method {self.start_method!r} is unavailable on this platform")

    def deadline_for(self, gate: Gate) -> float:
        raw = getattr(gate, "timeout_seconds", None)
        requested = self.timeout_seconds if raw is None else float(raw)
        if requested <= 0:
            raise ValueError("gate timeout must be > 0")
        return min(requested, self.hard_timeout_seconds)


def _worker(gate: Gate, ctx: GateContext, out) -> None:
    try:
        if os.name != "nt":
            try: os.setsid()
            except OSError: pass
        result = gate.run(ctx)
        if not isinstance(result, GateResult):
            raise TypeError(f"gate returned {type(result).__name__}, expected GateResult")
        if result.gate != gate.name:
            raise ValueError(f"gate result identity mismatch: expected={gate.name!r} actual={result.gate!r}")
        out.send(("ok", result))
    except BaseException as exc:
        try:
            out.send(("error", type(exc).__name__, str(exc)))
        except BaseException:
            pass
    finally:
        try:
            out.close()
        except BaseException:
            pass


@dataclass
class _Running:
    name: str
    process: mp.Process
    out: object
    started: float
    timeout_seconds: float


def _terminate_worker_tree(proc: mp.Process) -> None:
    if not proc.is_alive():
        proc.join(timeout=0.2); return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        else:
            os.killpg(proc.pid, signal.SIGTERM)
    except Exception:
        try: proc.terminate()
        except Exception: pass
    proc.join(timeout=1)
    if proc.is_alive():
        try:
            if os.name != "nt": os.killpg(proc.pid, signal.SIGKILL)
            elif hasattr(proc, "kill"): proc.kill()
        except Exception:
            try:
                if hasattr(proc, "kill"): proc.kill()
            except Exception: pass
        proc.join(timeout=1)


def execute_gates_isolated(gates: list[Gate], ctx: GateContext, policy: GateExecutionPolicy) -> list[GateResult]:
    if not gates:
        return []
    mp_ctx = mp.get_context(policy.start_method)
    pending = list(gates)
    running: list[_Running] = []
    results: dict[str, GateResult] = {}

    while pending or running:
        while pending and len(running) < policy.max_workers:
            gate = pending.pop(0)
            parent_out, child_out = mp_ctx.Pipe(duplex=False)
            proc = mp_ctx.Process(target=_worker, args=(gate, ctx, child_out), daemon=True)
            try:
                proc.start()
            except Exception as exc:
                results[gate.name] = GateResult(gate.name, GateStatus.FAIL, f"gate process failed to start: {type(exc).__name__}: {exc}")
                try:
                    parent_out.close(); child_out.close()
                except Exception:
                    pass
                continue
            child_out.close()
            running.append(_Running(gate.name, proc, parent_out, time.monotonic(), policy.deadline_for(gate)))

        time.sleep(0.005)
        for item in list(running):
            if item.out.poll():
                try:
                    message = item.out.recv()
                except EOFError:
                    message = None
                if message is None:
                    results[item.name] = GateResult(item.name, GateStatus.FAIL, "gate worker closed result channel without result")
                elif message[0] == "ok":
                    results[item.name] = message[1]
                else:
                    _, exc_type, text = message
                    results[item.name] = GateResult(item.name, GateStatus.FAIL, f"gate crashed: {exc_type}: {text}")
                item.process.join(timeout=1)
                if item.process.is_alive():
                    _terminate_worker_tree(item.process)
                try: item.out.close()
                except Exception: pass
                running.remove(item)
                continue

            elapsed = time.monotonic() - item.started
            if elapsed > item.timeout_seconds:
                _terminate_worker_tree(item.process)
                results[item.name] = GateResult(item.name, GateStatus.FAIL, f"gate timed out after {item.timeout_seconds:.3f}s")
                try: item.out.close()
                except Exception: pass
                running.remove(item)
                continue
            if item.process.is_alive():
                continue
            item.process.join(timeout=1)
            if item.out.poll(0.01):
                try: message = item.out.recv()
                except EOFError: message = None
                if message is not None and message[0] == "ok": results[item.name] = message[1]
                elif message is not None:
                    _, exc_type, text = message
                    results[item.name] = GateResult(item.name, GateStatus.FAIL, f"gate crashed: {exc_type}: {text}")
                else: results[item.name] = GateResult(item.name, GateStatus.FAIL, f"gate worker exited code={item.process.exitcode} without result")
            else:
                results[item.name] = GateResult(item.name, GateStatus.FAIL, f"gate worker exited code={item.process.exitcode} without result")
            try: item.out.close()
            except Exception: pass
            running.remove(item)

    return [results[gate.name] for gate in gates]
