from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Protocol

from .event_store import EventStore
from .evidence import EvidenceError, require_evidence, task_security_context_hash
from .models import Task, TaskState


ALLOWED: dict[TaskState, set[TaskState]] = {
    TaskState.READY: {TaskState.WORKING, TaskState.BLOCKED, TaskState.ABORTED, TaskState.SUPERSEDED},
    TaskState.WORKING: {TaskState.VALIDATING, TaskState.BLOCKED, TaskState.ABORTED, TaskState.SUPERSEDED},
    TaskState.VALIDATING: {TaskState.WORKING, TaskState.BLOCKED, TaskState.READY_TO_RELEASE, TaskState.ABORTED, TaskState.SUPERSEDED},
    TaskState.BLOCKED: {TaskState.READY, TaskState.WORKING, TaskState.ABORTED, TaskState.SUPERSEDED},
    TaskState.READY_TO_RELEASE: {TaskState.RELEASING, TaskState.WORKING, TaskState.BLOCKED, TaskState.ABORTED, TaskState.SUPERSEDED},
    TaskState.RELEASING: {
        TaskState.CANARY, TaskState.PARTIALLY_DEPLOYED,
        TaskState.BLOCKED, TaskState.WORKING, TaskState.DEGRADED, TaskState.RECOVERING,
    },
    TaskState.CANARY: {TaskState.PARTIALLY_DEPLOYED, TaskState.DONE, TaskState.DEGRADED, TaskState.RECOVERING, TaskState.ROLLED_BACK},
    TaskState.PARTIALLY_DEPLOYED: {TaskState.DONE, TaskState.DEGRADED, TaskState.RECOVERING, TaskState.ROLLED_BACK},
    # A production regression can be discovered after a task was previously DONE.
    TaskState.DONE: {TaskState.DEGRADED, TaskState.RECOVERING},
    TaskState.DEGRADED: {TaskState.RECOVERING, TaskState.ROLLED_BACK, TaskState.DONE, TaskState.BLOCKED},
    TaskState.RECOVERING: {TaskState.ROLLED_BACK, TaskState.DONE, TaskState.BLOCKED, TaskState.WORKING},
    TaskState.ROLLED_BACK: {TaskState.WORKING, TaskState.DONE, TaskState.SUPERSEDED},
    TaskState.ABORTED: set(),
    TaskState.SUPERSEDED: set(),
}


class InvalidTransition(ValueError):
    pass


class TransitionGuard(Protocol):
    def allow(self, task: Task, target: TaskState) -> bool: ...


@dataclass
class EvidenceTransitionGuard:
    store: EventStore
    signature_secret: bytes | None = None
    verification_keys: Mapping[str, bytes] | None = None
    allow_unsigned_dev: bool = False
    ready_claim: str = "required_gates_passed"
    release_claim: str = "release_verified"
    health_claim: str = "rollout_health_verified"
    recovery_claim: str = "recovery_verified"
    rollback_claim: str = "rollback_verified"
    accepted_sources: frozenset[str] = frozenset({"ados_control_plane"})
    require_asymmetric: bool = True
    policy_digest: str | None = None
    accepted_control_plane_versions: frozenset[str] = frozenset()
    health_required_tags: frozenset[str] = frozenset({"health", "candidate", "production"})

    def _has(self, task: Task, claim: str) -> bool:
        if task.candidate is None:
            return False
        try:
            required_tags: set[str] | None = None
            if claim == self.release_claim:
                required_tags = {"artifact", "provenance", "release"}
            elif claim == self.health_claim:
                required_tags = set(self.health_required_tags)
            ev = require_evidence(
                self.store, claim, task.candidate.repository, task.candidate.sha,
                generation=task.candidate.generation, subject_tree=task.candidate.tree,
                signature_secret=self.signature_secret, verification_keys=self.verification_keys,
                require_asymmetric=self.require_asymmetric, accepted_sources=set(self.accepted_sources),
                context_hash=task_security_context_hash(task), policy_digest=self.policy_digest,
                required_tags=required_tags,
                accepted_control_plane_versions=set(self.accepted_control_plane_versions) if self.accepted_control_plane_versions else None,
            )
            if claim == self.release_claim and not ev.provenance_digest:
                return False
            return True
        except EvidenceError:
            return False

    def allow(self, task: Task, target: TaskState) -> bool:
        if task.blockers:
            return False
        if target is TaskState.READY_TO_RELEASE:
            if self.signature_secret is None and not self.verification_keys and not self.allow_unsigned_dev:
                return False
            return self._has(task, self.ready_claim)
        if task.state is TaskState.RELEASING and target in {TaskState.CANARY, TaskState.PARTIALLY_DEPLOYED}:
            if self.signature_secret is None and not self.verification_keys and not self.allow_unsigned_dev:
                return False
            return self._has(task, self.release_claim)
        if target is TaskState.DONE and task.state in {TaskState.CANARY, TaskState.PARTIALLY_DEPLOYED, TaskState.DEGRADED}:
            return self._has(task, self.health_claim)
        if target is TaskState.DONE and task.state is TaskState.RECOVERING:
            return self._has(task, self.recovery_claim)
        if target is TaskState.ROLLED_BACK:
            return self._has(task, self.rollback_claim)
        return True


def _requires_guard(task: Task, target: TaskState) -> bool:
    if target is TaskState.READY_TO_RELEASE:
        return True
    if task.state is TaskState.RELEASING and target in {TaskState.CANARY, TaskState.PARTIALLY_DEPLOYED}:
        return True
    if target is TaskState.DONE and task.state in {TaskState.CANARY, TaskState.PARTIALLY_DEPLOYED, TaskState.DEGRADED, TaskState.RECOVERING}:
        return True
    if target is TaskState.ROLLED_BACK:
        return True
    return False


def transition(task: Task, target: TaskState, *, guard: TransitionGuard | None = None) -> Task:
    if target not in ALLOWED[task.state]:
        raise InvalidTransition(f"{task.state.value} -> {target.value} is not allowed")
    if _requires_guard(task, target) and (guard is None or not guard.allow(task, target)):
        raise InvalidTransition(f"{task.state.value} -> {target.value} requires verified evidence")
    task.state = target
    return task
