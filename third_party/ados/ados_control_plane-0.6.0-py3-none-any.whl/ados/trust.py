from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .models import ActionDecision, PolicyResult


class InstructionSource(str, Enum):
    CONTROL_PLANE = "CONTROL_PLANE"
    SIGNED_POLICY = "SIGNED_POLICY"
    AUTHORIZED_HUMAN = "AUTHORIZED_HUMAN"
    REPOSITORY = "REPOSITORY"
    ISSUE = "ISSUE"
    PR_COMMENT = "PR_COMMENT"
    LOG = "LOG"
    WEB = "WEB"
    EXTERNAL_SERVICE = "EXTERNAL_SERVICE"
    USER_CONTENT = "USER_CONTENT"


TRUSTED_INSTRUCTION_SOURCES = {
    InstructionSource.CONTROL_PLANE,
    InstructionSource.SIGNED_POLICY,
    InstructionSource.AUTHORIZED_HUMAN,
}


@dataclass(frozen=True)
class Instruction:
    source: InstructionSource
    text: str
    attempts_privilege_change: bool = False
    attempts_policy_change: bool = False


def instruction_firewall(instruction: Instruction) -> PolicyResult:
    if instruction.source not in TRUSTED_INSTRUCTION_SOURCES:
        if instruction.attempts_privilege_change or instruction.attempts_policy_change:
            return PolicyResult(
                ActionDecision.DENY,
                f"untrusted source {instruction.source.value} cannot alter privileges/policy",
                "PROMPT_INJECTION_TRUST_BOUNDARY",
            )
        return PolicyResult(
            ActionDecision.REQUIRE_APPROVAL,
            f"content from {instruction.source.value} is data, not authoritative instruction",
            "UNTRUSTED_INSTRUCTION_SOURCE",
        )
    return PolicyResult(ActionDecision.ALLOW, "trusted instruction source")
