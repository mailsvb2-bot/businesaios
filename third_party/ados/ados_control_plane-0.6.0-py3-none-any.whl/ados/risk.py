from __future__ import annotations

from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import PurePosixPath
from typing import Iterable

from .models import RiskLevel


@dataclass(frozen=True)
class RiskRule:
    pattern: str
    level: RiskLevel
    reason: str
    allow_downgrade: bool = False


DEFAULT_RULES = (
    RiskRule("**/migrations/**", RiskLevel.CRITICAL, "database migration"),
    RiskRule("migrations/**", RiskLevel.CRITICAL, "database migration"),
    RiskRule("**/auth/**", RiskLevel.HIGH, "authentication/authorization"),
    RiskRule("src/auth/**", RiskLevel.HIGH, "authentication/authorization"),
    RiskRule("**/payments/**", RiskLevel.CRITICAL, "financial flow"),
    RiskRule("**/billing/**", RiskLevel.CRITICAL, "financial flow"),
    RiskRule("**/licens*", RiskLevel.HIGH, "licensing"),
    RiskRule(".github/workflows/**", RiskLevel.HIGH, "CI trust boundary"),
    RiskRule(".ados/**", RiskLevel.HIGH, "ADOS policy/configuration"),
    RiskRule("**/*.md", RiskLevel.LOW, "documentation"),
    RiskRule("*.md", RiskLevel.LOW, "documentation"),
    RiskRule("**/*.txt", RiskLevel.LOW, "documentation/text"),
    RiskRule("*.txt", RiskLevel.LOW, "documentation/text"),
)

SEMANTIC_SEGMENTS: tuple[tuple[set[str], RiskLevel, str], ...] = (
    ({"payment", "payments", "billing", "invoice", "checkout", "wallet", "money", "tariff", "subscription"}, RiskLevel.CRITICAL, "financial semantics"),
    ({"auth", "oauth", "oidc", "sso", "permission", "permissions", "rbac", "acl", "session", "credential", "credentials", "secret", "secrets"}, RiskLevel.HIGH, "identity/security semantics"),
    ({"migration", "migrations", "schema", "database", "db", "storage"}, RiskLevel.HIGH, "persistent-data semantics"),
    ({"deploy", "deployment", "release", "production", "infra", "terraform", "k8s", "kubernetes"}, RiskLevel.HIGH, "deployment semantics"),
)

ORDER = {RiskLevel.LOW: 0, RiskLevel.MEDIUM: 1, RiskLevel.HIGH: 2, RiskLevel.CRITICAL: 3}


def _semantic_match(path: str) -> tuple[RiskLevel, str] | None:
    normalized = path.lower().replace("-", "_")
    tokens: set[str] = set()
    for part in PurePosixPath(normalized).parts:
        tokens.update(x for x in part.replace(".", "_").split("_") if x)
    hits = [(level, reason) for words, level, reason in SEMANTIC_SEGMENTS if tokens & words]
    if not hits:
        return None
    return max(hits, key=lambda item: ORDER[item[0]])


def classify_risk(
    changed_files: Iterable[str],
    rules: Iterable[RiskRule] = DEFAULT_RULES,
    *,
    overrides: Iterable[RiskRule] = (),
) -> tuple[RiskLevel, list[str]]:
    files = list(changed_files)
    if not files:
        return RiskLevel.MEDIUM, ["no changed files supplied: default MEDIUM"]

    global_level = RiskLevel.LOW
    reasons: list[str] = []
    overrides = tuple(overrides)
    for path in files:
        matched = [rule for rule in rules if fnmatch(path, rule.pattern) or fnmatch("/" + path, rule.pattern)]
        semantic = _semantic_match(path)
        candidates: list[tuple[RiskLevel, str]] = [(r.level, r.reason) for r in matched]
        if semantic is not None:
            candidates.append(semantic)
        override_matches = [rule for rule in overrides if fnmatch(path, rule.pattern) or fnmatch("/" + path, rule.pattern)]
        downgrade = [rule for rule in override_matches if rule.allow_downgrade]
        floors = [rule for rule in override_matches if not rule.allow_downgrade]
        for rule in floors:
            candidates.append((rule.level, f"project-reviewed risk floor: {rule.reason}"))
        if not candidates:
            path_level = RiskLevel.MEDIUM
            reasons.append(f"{path}: conservative default MEDIUM")
        else:
            path_level = max((level for level, _ in candidates), key=lambda x: ORDER[x])
            for level, reason in candidates:
                reasons.append(f"{path}: {reason} -> {level.value}")
        if downgrade:
            # Explicit downgrades are possible only through the protected impact
            # policy. Certification of that policy change is separately governed.
            chosen = min(downgrade, key=lambda r: ORDER[r.level])
            path_level = chosen.level
            reasons.append(f"{path}: explicitly approved risk downgrade: {chosen.reason} -> {chosen.level.value}")
        if ORDER[path_level] > ORDER[global_level]:
            global_level = path_level
    return global_level, list(dict.fromkeys(reasons))
