from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from .models import GateResult, GateStatus


class FeatureSurface(str, Enum):
    UI = "UI"; API = "API"; BACKGROUND = "BACKGROUND"; DESKTOP = "DESKTOP"


@dataclass(frozen=True)
class FeatureWiring:
    surface: FeatureSurface = FeatureSurface.UI
    domain: bool = False; persistence: bool = False; authorization: bool = False; api: bool = False
    frontend_state: bool = False; navigation: bool = False; visible_control: bool = False
    success_ux: bool = False; error_ux: bool = False; observability: bool = False; e2e_journey: bool = False
    evidence_refs: dict[str, str] = field(default_factory=dict)


SURFACE_REQUIRED = {
    FeatureSurface.UI: ("domain", "persistence", "authorization", "api", "frontend_state", "navigation", "visible_control", "success_ux", "error_ux", "e2e_journey"),
    FeatureSurface.API: ("domain", "authorization", "api", "success_ux", "error_ux", "e2e_journey"),
    FeatureSurface.BACKGROUND: ("domain", "persistence", "observability", "e2e_journey"),
    FeatureSurface.DESKTOP: ("domain", "persistence", "frontend_state", "navigation", "visible_control", "success_ux", "error_ux", "e2e_journey"),
}


def wiring_gate(feature: FeatureWiring, require_persistence: bool | None = None, require_observability: bool | None = None,
                required_fields: tuple[str, ...] | None = None, *, require_measured_evidence: bool = False) -> GateResult:
    required = list(required_fields or SURFACE_REQUIRED[feature.surface])
    if require_persistence is True and "persistence" not in required: required.append("persistence")
    elif require_persistence is False and "persistence" in required: required.remove("persistence")
    if require_observability is True and "observability" not in required: required.append("observability")
    elif require_observability is False and "observability" in required: required.remove("observability")
    missing = [name for name in required if not getattr(feature, name)]
    unmeasured = [name for name in required if getattr(feature, name) and name not in feature.evidence_refs] if require_measured_evidence else []
    if missing:
        return GateResult("wiring", GateStatus.FAIL, f"feature is not {feature.surface.value.lower()}-ready; missing={missing}", {"surface": feature.surface.value, "required": required})
    if unmeasured:
        return GateResult("wiring", GateStatus.UNKNOWN, f"wiring assertions lack measured evidence: {unmeasured}")
    return GateResult("wiring", GateStatus.PASS, f"feature reachable end-to-end on {feature.surface.value}", {"evidence_refs": feature.evidence_refs})
