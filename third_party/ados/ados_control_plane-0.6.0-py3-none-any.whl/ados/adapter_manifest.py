from __future__ import annotations

import hashlib
import importlib
import inspect
import json
import sys
import types
from dataclasses import dataclass
from pathlib import Path

from .gates import Gate, GateContext, RESERVED_CORE_GATES
from .models import GateResult


class AdapterManifestError(ValueError):
    pass


@dataclass(frozen=True)
class AdapterSpec:
    gate: str
    module: str
    attribute: str
    source_file: str
    sha256: str
    execution: str = "python_trusted"
    allow_in_release: bool = False
    capabilities: tuple[str, ...] = ()


@dataclass(frozen=True)
class AdapterManifest:
    version: int
    adapters: tuple[AdapterSpec, ...]

    @classmethod
    def from_file(cls, path: str | Path) -> "AdapterManifest":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise AdapterManifestError("adapter manifest must be a JSON object")
        version = int(raw.get("version", 1))
        specs: list[AdapterSpec] = []
        for item in raw.get("adapters", []):
            try:
                specs.append(AdapterSpec(
                    gate=item["gate"],
                    module=item["module"],
                    attribute=item["attribute"],
                    source_file=item["source_file"],
                    sha256=item["sha256"].lower(),
                    execution=str(item.get("execution", "python_trusted")),
                    allow_in_release=bool(item.get("allow_in_release", False)),
                    capabilities=tuple(sorted(str(x) for x in item.get("capabilities", ()))),
                ))
            except (KeyError, TypeError) as exc:
                raise AdapterManifestError(f"invalid adapter entry: {item!r}") from exc
        if len({s.gate for s in specs}) != len(specs):
            raise AdapterManifestError("duplicate gate in adapter manifest")
        for spec in specs:
            if spec.execution != "python_trusted":
                raise AdapterManifestError(f"unsupported adapter execution mode {spec.execution!r}; use command gates for sandboxable project checks")
        return cls(version=version, adapters=tuple(specs))


def _inside(root: Path, path: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _verified_source(root: Path, spec: AdapterSpec) -> Path:
    rel = Path(spec.source_file)
    if rel.is_absolute() or ".." in rel.parts:
        raise AdapterManifestError(f"adapter source path escapes repository: {spec.source_file!r}")
    source = (root / rel).resolve(strict=True)
    if not _inside(root, source):
        raise AdapterManifestError(f"adapter source resolves outside repository: {spec.source_file!r}")
    actual_digest = sha256_file(source)
    if actual_digest != spec.sha256:
        raise AdapterManifestError(
            f"adapter source digest mismatch for gate={spec.gate!r}: expected={spec.sha256} actual={actual_digest}"
        )
    return source


def _instantiate_exact_adapter(root: Path, spec: AdapterSpec) -> Gate:
    """Compile the exact approved source bytes, bypassing import/pyc caches."""
    source = _verified_source(root, spec)
    added_sys_path = False
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
        added_sys_path = True
    try:
        package_name = spec.module.rpartition(".")[0]
        if package_name:
            importlib.import_module(package_name)
        module = types.ModuleType(spec.module)
        module.__file__ = str(source)
        module.__package__ = package_name
        module.__loader__ = None
        previous = sys.modules.get(spec.module)
        sys.modules[spec.module] = module
        try:
            code = compile(source.read_bytes(), str(source), "exec")
            exec(code, module.__dict__)
        except Exception:
            if previous is None:
                sys.modules.pop(spec.module, None)
            else:
                sys.modules[spec.module] = previous
            raise
        obj = getattr(module, spec.attribute)
        if inspect.isclass(obj):
            obj = obj()
        elif callable(obj) and not hasattr(obj, "run"):
            obj = obj()
        if not hasattr(obj, "run") or not hasattr(obj, "name"):
            raise AdapterManifestError(f"adapter {spec.module}:{spec.attribute} is not Gate-like")
        if obj.name != spec.gate:
            raise AdapterManifestError(f"adapter name mismatch: manifest={spec.gate!r} object={obj.name!r}")
        return obj
    finally:
        if added_sys_path:
            try:
                sys.path.remove(str(root))
            except ValueError:
                pass


@dataclass(frozen=True)
class PinnedAdapterGate:
    """Spawn-safe descriptor for an approved repository adapter.

    Dynamic repository classes are intentionally not pickled into worker processes.
    The worker receives this ADOS-owned descriptor, re-verifies the protected manifest
    and source digest, then compiles the exact approved source bytes locally.
    """

    root: str
    manifest_path: str
    manifest_sha256: str
    spec: AdapterSpec

    @property
    def name(self) -> str:
        return self.spec.gate

    @property
    def allow_in_release(self) -> bool:
        return self.spec.allow_in_release

    @property
    def capabilities(self) -> tuple[str, ...]:
        return self.spec.capabilities

    def run(self, ctx: GateContext) -> GateResult:
        root = Path(self.root).resolve()
        manifest_path = Path(self.manifest_path).resolve()
        if not _inside(root, manifest_path):
            raise AdapterManifestError("adapter manifest escaped repository after scheduling")
        if sha256_file(manifest_path) != self.manifest_sha256:
            raise AdapterManifestError("adapter manifest changed after scheduling")
        current = AdapterManifest.from_file(manifest_path)
        matching = [item for item in current.adapters if item.gate == self.spec.gate]
        if matching != [self.spec]:
            raise AdapterManifestError(f"adapter manifest entry changed for gate={self.spec.gate!r}")
        adapter = _instantiate_exact_adapter(root, self.spec)
        result = adapter.run(ctx)
        if not isinstance(result, GateResult):
            raise TypeError(f"adapter returned {type(result).__name__}, expected GateResult")
        return result


def load_manifest_adapters(root: Path, manifest_path: Path) -> dict[str, Gate]:
    root = root.resolve()
    manifest_path = manifest_path.resolve()
    if not _inside(root, manifest_path):
        raise AdapterManifestError("adapter manifest must be inside repository root")
    manifest = AdapterManifest.from_file(manifest_path)
    forbidden = RESERVED_CORE_GATES.intersection(spec.gate for spec in manifest.adapters)
    if forbidden:
        raise AdapterManifestError(f"adapter manifest cannot override reserved core gates: {sorted(forbidden)}")
    manifest_digest = sha256_file(manifest_path)
    loaded: dict[str, Gate] = {}
    for spec in manifest.adapters:
        # Fail before scheduling if the manifest points outside the repo or the
        # approved source digest is already stale.
        _verified_source(root, spec)
        loaded[spec.gate] = PinnedAdapterGate(
            root=str(root),
            manifest_path=str(manifest_path),
            manifest_sha256=manifest_digest,
            spec=spec,
        )
    return loaded
