from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

from . import __version__
from .crypto import sign_ed25519, verify_ed25519
from .event_store import EventStore


class AuditAnchorError(ValueError):
    pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


@dataclass(frozen=True)
class AuditAnchor:
    schema_version: int
    created_at: str
    control_plane_version: str
    task_roots: tuple[tuple[str, int, str], ...]
    control_roots: tuple[tuple[str, int, str], ...]
    evidence_count: int
    evidence_digest: str
    signature_algorithm: str = "ed25519"
    signer_id: str | None = None
    signature: str | None = None

    def unsigned_payload(self) -> bytes:
        data = asdict(self); data.pop("signature", None)
        return _canonical(data)

    def signed(self, private_key_pem: bytes) -> "AuditAnchor":
        prepared = replace(self, signature=None, signature_algorithm="ed25519")
        _, signer = sign_ed25519(b"ados-audit-anchor-key", private_key_pem)
        prepared = replace(prepared, signer_id=signer)
        sig, actual = sign_ed25519(prepared.unsigned_payload(), private_key_pem)
        if actual != signer: raise AuditAnchorError("anchor signer identity changed")
        return replace(prepared, signature=sig)

    def verify(self, keys: Mapping[str, bytes]) -> bool:
        if not self.signature or not self.signer_id or self.signature_algorithm != "ed25519": return False
        key = keys.get(self.signer_id)
        return bool(key and verify_ed25519(self.unsigned_payload(), self.signature, key))

    def write(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), sort_keys=True, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    @classmethod
    def from_file(cls, path: str | Path) -> "AuditAnchor":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        raw["task_roots"] = tuple(tuple(x) for x in raw.get("task_roots", ()))
        raw["control_roots"] = tuple(tuple(x) for x in raw.get("control_roots", ()))
        return cls(**raw)


def create_anchor(store: EventStore, private_key_pem: bytes) -> AuditAnchor:
    with store.session() as cx:
        tasks = cx.execute(
            """SELECT t.task_id,t.id,t.event_hash FROM task_events t
               JOIN (SELECT task_id,MAX(id) AS max_id FROM task_events GROUP BY task_id) x
                 ON t.task_id=x.task_id AND t.id=x.max_id ORDER BY t.task_id"""
        ).fetchall()
        controls = cx.execute(
            """SELECT c.stream,c.id,c.event_hash FROM control_events c
               JOIN (SELECT stream,MAX(id) AS max_id FROM control_events GROUP BY stream) x
                 ON c.stream=x.stream AND c.id=x.max_id ORDER BY c.stream"""
        ).fetchall()
        evidence = cx.execute(
            """SELECT id,claim,repository,subject_sha,subject_tree,generation,source,conclusion,verified_at,
                      artifact_digest,context_hash,inputs_hash,tags_json,ttl_seconds,signature,signature_algorithm,
                      signer_id,control_plane_version,policy_digest,provenance_digest
               FROM evidence ORDER BY id"""
        ).fetchall()
    ev_material = [dict(row) for row in evidence]
    return AuditAnchor(
        schema_version=1,
        created_at=_now(),
        control_plane_version=__version__,
        task_roots=tuple((str(r["task_id"]), int(r["id"]), str(r["event_hash"] or "")) for r in tasks),
        control_roots=tuple((str(r["stream"]), int(r["id"]), str(r["event_hash"] or "")) for r in controls),
        evidence_count=len(evidence),
        evidence_digest="sha256:" + hashlib.sha256(_canonical(ev_material)).hexdigest(),
    ).signed(private_key_pem)


def verify_anchor_against_store(anchor: AuditAnchor, store: EventStore, keys: Mapping[str, bytes]) -> bool:
    if not anchor.verify(keys): return False
    # Recreate an unsigned snapshot and compare roots/digests. A newer database is
    # allowed only when caller explicitly anchors again; release verification uses
    # exact equality to prevent rollback/replacement of the local DB.
    with store.session() as cx:
        tasks = cx.execute("SELECT task_id,MAX(id) max_id FROM task_events GROUP BY task_id ORDER BY task_id").fetchall()
        current_task_roots = []
        for row in tasks:
            ev = cx.execute("SELECT event_hash FROM task_events WHERE id=?", (row["max_id"],)).fetchone()
            current_task_roots.append((str(row["task_id"]), int(row["max_id"]), str(ev["event_hash"] or "")))
        controls = cx.execute("SELECT stream,MAX(id) max_id FROM control_events GROUP BY stream ORDER BY stream").fetchall()
        current_control_roots = []
        for row in controls:
            ev = cx.execute("SELECT event_hash FROM control_events WHERE id=?", (row["max_id"],)).fetchone()
            current_control_roots.append((str(row["stream"]), int(row["max_id"]), str(ev["event_hash"] or "")))
        evidence = cx.execute(
            """SELECT id,claim,repository,subject_sha,subject_tree,generation,source,conclusion,verified_at,
                      artifact_digest,context_hash,inputs_hash,tags_json,ttl_seconds,signature,signature_algorithm,
                      signer_id,control_plane_version,policy_digest,provenance_digest FROM evidence ORDER BY id"""
        ).fetchall()
    digest = "sha256:" + hashlib.sha256(_canonical([dict(r) for r in evidence])).hexdigest()
    return tuple(current_task_roots) == anchor.task_roots and tuple(current_control_roots) == anchor.control_roots and len(evidence) == anchor.evidence_count and digest == anchor.evidence_digest
