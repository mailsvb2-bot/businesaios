from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .crypto import sign_ed25519, verify_ed25519
from .models import Candidate
from .util import sha256_regular_file


class DeploymentAttestationError(ValueError):
    pass


def _canonical(data: dict[str, Any]) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _parse_time(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise DeploymentAttestationError(f"invalid deployment timestamp {value!r}") from exc
    if parsed.tzinfo is None:
        raise DeploymentAttestationError("deployment timestamps must be timezone-aware")
    return parsed.astimezone(timezone.utc)


@dataclass(frozen=True)
class DeploymentAttestation:
    schema_version: int
    repository: str
    subject_sha: str
    subject_tree: str
    generation: int
    artifact_digest: str
    deployment_id: str
    environment: str
    target: str
    status: str
    probe_id: str
    probe_version: str
    measurements_hash: str
    issued_at: str
    expires_at: str
    signature_algorithm: str = "ed25519"
    signer_id: str | None = None
    signature: str | None = None

    def unsigned_payload(self) -> bytes:
        data = asdict(self)
        data.pop("signature", None)
        return _canonical(data)

    def signed(self, private_key_pem: bytes) -> "DeploymentAttestation":
        prepared = replace(self, signature=None, signature_algorithm="ed25519")
        _, signer = sign_ed25519(b"ados-deployment-attestation-key", private_key_pem)
        prepared = replace(prepared, signer_id=signer)
        signature, actual = sign_ed25519(prepared.unsigned_payload(), private_key_pem)
        if actual != signer:
            raise DeploymentAttestationError("deployment signer identity changed")
        return replace(prepared, signature=signature)

    def verify_signature(self, keys: Mapping[str, bytes]) -> bool:
        if self.signature_algorithm != "ed25519" or not self.signature or not self.signer_id:
            return False
        key = keys.get(self.signer_id)
        return bool(key and verify_ed25519(self.unsigned_payload(), self.signature, key))

    def digest(self) -> str:
        material = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return "sha256:" + hashlib.sha256(material).hexdigest()

    def to_file(self, path: str | Path) -> None:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(asdict(self), sort_keys=True, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    @classmethod
    def from_file(cls, path: str | Path) -> "DeploymentAttestation":
        return cls(**json.loads(Path(path).read_text(encoding="utf-8")))

    @classmethod
    def issue(
        cls,
        *,
        repository: str,
        candidate: Candidate,
        artifact: Path,
        deployment_id: str,
        environment: str,
        target: str,
        status: str,
        probe_id: str,
        probe_version: str,
        measurements_hash: str,
        private_key_pem: bytes,
        ttl_seconds: int = 1800,
    ) -> "DeploymentAttestation":
        if ttl_seconds <= 0 or ttl_seconds > 86_400:
            raise DeploymentAttestationError("deployment attestation ttl must be >0 and <=86400")
        normalized_status = status.strip().upper()
        if normalized_status not in {"HEALTHY", "DEGRADED", "ROLLED_BACK"}:
            raise DeploymentAttestationError("deployment status must be HEALTHY|DEGRADED|ROLLED_BACK")
        for name, value in {
            "deployment_id": deployment_id, "environment": environment, "target": target,
            "probe_id": probe_id, "probe_version": probe_version, "measurements_hash": measurements_hash,
        }.items():
            if not isinstance(value, str) or not value.strip():
                raise DeploymentAttestationError(f"{name} must be non-empty")
        if not measurements_hash.startswith("sha256:") or len(measurements_hash) != 71:
            raise DeploymentAttestationError("measurements_hash must use sha256:<64hex>")
        now = datetime.now(timezone.utc)
        expires = datetime.fromtimestamp(now.timestamp() + ttl_seconds, tz=timezone.utc)
        return cls(
            schema_version=1,
            repository=repository,
            subject_sha=candidate.sha,
            subject_tree=candidate.tree or "",
            generation=candidate.generation,
            artifact_digest=sha256_regular_file(artifact),
            deployment_id=deployment_id.strip(),
            environment=environment.strip(),
            target=target.strip(),
            status=normalized_status,
            probe_id=probe_id.strip(),
            probe_version=probe_version.strip(),
            measurements_hash=measurements_hash.lower(),
            issued_at=now.isoformat().replace("+00:00", "Z"),
            expires_at=expires.isoformat().replace("+00:00", "Z"),
        ).signed(private_key_pem)


def verify_deployment_attestation(
    attestation: DeploymentAttestation,
    *,
    keys: Mapping[str, bytes],
    repository: str,
    candidate: Candidate,
    artifact_digest: str,
    required_environment: str = "production",
    required_status: str = "HEALTHY",
) -> None:
    if attestation.schema_version != 1:
        raise DeploymentAttestationError("unsupported deployment attestation schema")
    if not attestation.verify_signature(keys):
        raise DeploymentAttestationError("deployment attestation signature is invalid or untrusted")
    if attestation.repository != repository:
        raise DeploymentAttestationError("deployment attestation repository mismatch")
    if attestation.subject_sha != candidate.sha or attestation.subject_tree != (candidate.tree or ""):
        raise DeploymentAttestationError("deployment attestation candidate mismatch")
    if attestation.generation != candidate.generation:
        raise DeploymentAttestationError("deployment attestation generation mismatch")
    if attestation.artifact_digest != artifact_digest:
        raise DeploymentAttestationError("deployment attestation artifact digest does not match certified release artifact")
    if attestation.environment != required_environment:
        raise DeploymentAttestationError(
            f"deployment attestation environment mismatch: expected={required_environment!r} actual={attestation.environment!r}"
        )
    if attestation.status != required_status:
        raise DeploymentAttestationError(
            f"deployment attestation status mismatch: expected={required_status!r} actual={attestation.status!r}"
        )
    issued = _parse_time(attestation.issued_at)
    expires = _parse_time(attestation.expires_at)
    now = datetime.now(timezone.utc)
    if expires <= issued:
        raise DeploymentAttestationError("deployment attestation expiry is not after issue time")
    if now < issued:
        raise DeploymentAttestationError("deployment attestation is from the future")
    if now >= expires:
        raise DeploymentAttestationError("deployment attestation is expired")
