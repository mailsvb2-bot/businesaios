from __future__ import annotations

import re
from dataclasses import dataclass

from .models import GateResult, GateStatus


USES_LINE = re.compile(r"^\s*(?:-\s*)?uses:\s*['\"]?([^@'\"\s]+)@([^'\"\s#]+)['\"]?\s*(?:#.*)?$")
HEX40 = re.compile(r"^[0-9a-fA-F]{40}$")


@dataclass(frozen=True)
class DependencyPolicy:
    require_lockfile: bool = True
    require_action_sha_pinning: bool = True
    require_sbom_for_release: bool = True


def github_action_pinning_gate(workflow_text: str) -> GateResult:
    violations: list[str] = []
    for line in workflow_text.splitlines():
        if line.lstrip().startswith("#"):
            continue
        match = USES_LINE.match(line)
        if not match:
            continue
        action, ref = match.groups()
        if action.startswith("./"):
            continue
        if not HEX40.fullmatch(ref):
            violations.append(f"{action}@{ref}")
    if violations:
        return GateResult("supply_chain", GateStatus.FAIL, f"GitHub Actions not pinned to immutable SHA: {violations}")
    return GateResult("supply_chain", GateStatus.PASS, "GitHub Actions immutable references verified")
