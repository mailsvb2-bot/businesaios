from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from .models import ActionDecision, ActionRequest, DevelopmentLane, GateResult, GateStatus, Task
from .policy import Constitution, PolicyEngine
from .supply_chain import github_action_pinning_gate


@dataclass
class GateContext:
    root: Path
    task: Task
    changed_files: tuple[str, ...]
    deleted_files: tuple[str, ...] = ()
    lane: DevelopmentLane = DevelopmentLane.DEVELOPMENT
    # Current work is judged by the already-anchored base policy.  Candidate
    # policy is validated as a proposed transition, but cannot silently weaken
    # the judge that evaluates itself.
    trusted_policy_root: Path | None = None
    governance_approved: bool = False
    governance_approval_id: str | None = None


class Gate(Protocol):
    name: str
    def run(self, ctx: GateContext) -> GateResult: ...


# Project adapters may add project-semantic gates, but never replace the Safety Kernel.
RESERVED_CORE_GATES = frozenset({"source", "safety", "supply_chain", "governance"})


def _inside(root: Path, candidate: Path) -> bool:
    try:
        return os.path.commonpath([str(root), str(candidate)]) == str(root)
    except ValueError:
        return False


class SourceGate:
    name = "source"

    def run(self, ctx: GateContext) -> GateResult:
        root = ctx.root.resolve()
        deleted = set(ctx.deleted_files)
        bad: list[str] = []
        missing: list[str] = []
        for raw in (*ctx.changed_files, *ctx.deleted_files):
            p = Path(raw)
            if p.is_absolute() or ".." in p.parts:
                bad.append(raw); continue
            resolved = (root / p).resolve(strict=False)
            if not _inside(root, resolved):
                bad.append(raw)
        if bad:
            return GateResult(self.name, GateStatus.FAIL, f"path escapes repository root: {sorted(set(bad))}")
        for raw in ctx.changed_files:
            if raw in deleted:
                continue
            p = root / raw
            if not p.exists():
                missing.append(raw); continue
            if not _inside(root, p.resolve()):
                bad.append(raw)
        if bad:
            return GateResult(self.name, GateStatus.FAIL, f"symlink/path escapes repository root: {sorted(set(bad))}")
        if missing:
            return GateResult(self.name, GateStatus.FAIL, f"changed files missing but not declared deleted: {missing}")
        return GateResult(self.name, GateStatus.PASS, "source paths valid", {"declared_deleted": sorted(deleted)})


class RepositorySafetyGate:
    name = "safety"

    def run(self, ctx: GateContext) -> GateResult:
        policy_root = (ctx.trusted_policy_root or ctx.root).resolve()
        constitution_path = policy_root / ".ados/constitution.json"
        if not constitution_path.exists():
            return GateResult(self.name, GateStatus.UNKNOWN, "repository constitution missing")
        try:
            constitution = Constitution.from_file(constitution_path)
        except Exception as exc:
            return GateResult(self.name, GateStatus.FAIL, f"invalid repository constitution: {type(exc).__name__}: {exc}")
        engine = PolicyEngine(constitution)
        req = ActionRequest(
            action="modify_files",
            actor_role="builder",
            environment="dev",
            changed_files=tuple(dict.fromkeys((*ctx.changed_files, *ctx.deleted_files))),
            deleted_files=len(ctx.deleted_files),
        )
        results = engine.evaluate(req)
        denies = [r for r in results if r.decision is ActionDecision.DENY]
        if denies:
            final = denies[0]
            return GateResult(self.name, GateStatus.FAIL, f"repository safety policy denies change: {final.reason}", {"rule_id": final.rule_id})
        approvals = [r for r in results if r.decision is ActionDecision.REQUIRE_APPROVAL]
        # Repository refactors and policy evolution must not deadlock themselves.
        # REQUIRE_APPROVAL findings become risk/governance signals; actual destructive
        # production capabilities are controlled separately and still fail closed.
        return GateResult(
            self.name,
            GateStatus.PASS,
            "repository safety policy satisfied" if not approvals else "repository change allowed with governed review signals",
            {"review_signals": [{"rule_id": r.rule_id, "reason": r.reason} for r in approvals], "lane": ctx.lane.value},
        )


class GovernanceGate:
    name = "governance"

    def run(self, ctx: GateContext) -> GateResult:
        """Validate changes to the ADOS/CI trusted computing base without bootstrap deadlock."""
        try:
            from .adapter_manifest import load_manifest_adapters
            from .command_gates import load_command_gates
            from .impact import ImpactModel
            from .project_config import ProjectConfig
            from .provenance import BuildSpec
            candidate_constitution = Constitution.from_file(ctx.root / ".ados/constitution.json")
            ImpactModel.from_file(ctx.root / ".ados/impact.json")
            project = ProjectConfig.from_file(ctx.root / ".ados/project.json")
            manifest = ctx.root / project.command_manifest
            gates = load_command_gates(ctx.root, manifest) if manifest.exists() else {}
            adapter_path = ctx.root / project.adapter_manifest
            if adapter_path.exists():
                load_manifest_adapters(ctx.root, adapter_path)
            build_path = ctx.root / project.build_manifest
            if build_path.exists():
                BuildSpec.from_file(build_path)
        except Exception as exc:
            return GateResult(self.name, GateStatus.FAIL, f"trusted policy/config is invalid: {type(exc).__name__}: {exc}")

        required_protected = {
            project.command_manifest, project.adapter_manifest, project.build_manifest,
            ".ados/project.json", ".ados/constitution.json", ".ados/impact.json", ".ados/sbom.json",
            *project.trust.evidence_public_key_files, *project.trust.break_glass_public_key_files,
            *project.trust.runner_public_key_files, *project.trust.vulnerability_public_key_files,
            *project.trust.deployment_public_key_files,
        }
        unprotected = sorted(path for path in required_protected if path and not candidate_constitution.is_protected_path(path))
        if unprotected:
            return GateResult(self.name, GateStatus.FAIL, f"candidate TCB paths are not constitution-protected: {unprotected}")

        trusted_root = (ctx.trusted_policy_root or ctx.root).resolve()
        try:
            trusted_constitution = Constitution.from_file(trusted_root / ".ados/constitution.json")
            trusted_project = ProjectConfig.from_file(trusted_root / ".ados/project.json")
        except Exception as exc:
            return GateResult(self.name, GateStatus.FAIL, f"anchored trusted policy is unavailable: {type(exc).__name__}: {exc}")

        tcb_paths = tuple(dict.fromkeys((*ctx.changed_files, *ctx.deleted_files)))
        tcb_changed = any(
            trusted_constitution.is_protected_path(path)
            or candidate_constitution.is_protected_path(path)
            or path.startswith(".github/workflows/")
            or path == "CODEOWNERS"
            for path in tcb_paths
        )
        if tcb_changed and ctx.lane is not DevelopmentLane.DEVELOPMENT and not ctx.governance_approved:
            return GateResult(
                self.name, GateStatus.FAIL,
                "trusted-computing-base change requires independent signed governance approval anchored in the base policy",
                {"approval_required": True, "changed_tcb_paths": sorted(tcb_paths)},
            )

        # Candidate policy may strengthen the next baseline, but it cannot
        # silently weaken a few security invariants even when file review was
        # accidentally broad. Deliberate weakening requires a future explicit
        # policy design, not an implicit self-edit.
        weakenings: list[str] = []
        # Core trust *roles* may not disappear, but individual keys are deliberately
        # rotatable/revocable under the already-required two-person TCB approval.
        # Treating every old key as immortal would make compromise recovery impossible
        # and would perversely enlarge the trust surface over time.
        if trusted_project.trust.require_asymmetric_release_signing and not project.trust.require_asymmetric_release_signing:
            weakenings.append("asymmetric release signing disabled")
        if project.trust.require_asymmetric_release_signing and not project.trust.evidence_public_key_files:
            weakenings.append("asymmetric evidence trust root removed")
        if len(trusted_project.trust.break_glass_public_key_files) >= 2 and len(project.trust.break_glass_public_key_files) < 2:
            weakenings.append("two-person governance trust quorum removed")
        if trusted_project.trust.require_runner_attestation_for_certification and not project.trust.require_runner_attestation_for_certification:
            weakenings.append("disposable runner attestation disabled")
        if project.trust.require_runner_attestation_for_certification and not project.trust.runner_public_key_files:
            weakenings.append("runner attestation trust root removed")
        if trusted_project.trust.require_vulnerability_attestation_for_release and not project.trust.require_vulnerability_attestation_for_release:
            weakenings.append("release vulnerability attestation disabled")
        if project.trust.require_vulnerability_attestation_for_release and not project.trust.vulnerability_public_key_files:
            weakenings.append("vulnerability-scanner trust root removed")
        severity_rank = {"NONE": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
        if severity_rank[project.trust.vulnerability_max_severity] > severity_rank[trusted_project.trust.vulnerability_max_severity]:
            weakenings.append("vulnerability severity policy weakened")
        if trusted_project.trust.require_deployment_attestation_for_health and not project.trust.require_deployment_attestation_for_health:
            weakenings.append("deployment/health attestation disabled")
        if project.trust.require_deployment_attestation_for_health and not project.trust.deployment_public_key_files:
            weakenings.append("deployment/health trust root removed")
        if project.trust.deployment_environment != trusted_project.trust.deployment_environment:
            weakenings.append("protected deployment environment changed")
        if trusted_project.audit.require_external_anchor_for_release and not project.audit.require_external_anchor_for_release:
            weakenings.append("external release audit anchor disabled")
        if trusted_project.strict_project_gates and not project.strict_project_gates:
            weakenings.append("strict project gates disabled")
        remote_rank = {"disabled": 0, "auto": 1, "required": 2}
        if remote_rank[project.remote_base.mode] < remote_rank[trusted_project.remote_base.mode]:
            weakenings.append("remote-base truth policy weakened")
        if trusted_project.remote_base.host is not None and project.remote_base.host is None:
            weakenings.append("remote host pin removed")
        if not trusted_project.remote_base.allow_local_filesystem_for_release and project.remote_base.allow_local_filesystem_for_release:
            weakenings.append("filesystem remote release exception enabled")
        if trusted_project.require_hermetic_build and not project.require_hermetic_build:
            weakenings.append("hermetic build requirement disabled")
        if trusted_project.trust.accepted_control_plane_versions and not project.trust.accepted_control_plane_versions:
            weakenings.append("control-plane version allowlist removed")
        if set(trusted_project.rollout.health_required_tags) - set(project.rollout.health_required_tags):
            weakenings.append("production health evidence tags removed")
        if project.evidence.rollout_health_ttl_seconds > trusted_project.evidence.rollout_health_ttl_seconds:
            weakenings.append("production health evidence TTL increased")
        if project.evidence.recovery_ttl_seconds > trusted_project.evidence.recovery_ttl_seconds:
            weakenings.append("recovery evidence TTL increased")
        if weakenings:
            return GateResult(self.name, GateStatus.FAIL, "candidate policy weakens anchored invariants: " + "; ".join(weakenings))

        changed_workflows = [p for p in ctx.changed_files if p.startswith(".github/workflows/") and p.endswith((".yml", ".yaml"))]
        failures: list[str] = []
        for rel in changed_workflows:
            path = ctx.root / rel
            if path.exists():
                result = github_action_pinning_gate(path.read_text(encoding="utf-8"))
                if result.status is GateStatus.FAIL:
                    failures.append(f"{rel}: {result.reason}")
        if ctx.lane is not DevelopmentLane.DEVELOPMENT and project.strict_project_gates:
            semantic = {"tests", "architecture"}
            missing = sorted(name for name in semantic if name not in gates)
            if missing:
                failures.append(f"strict project lanes require real command/adapters for {missing}")
        if ctx.lane is DevelopmentLane.RELEASE and project.strict_project_gates:
            required = {"release", "full_regression", "dependency_audit"}
            missing = sorted(name for name in required if name not in gates)
            if missing:
                failures.append(f"release lane requires real project gates {missing}")
        if failures:
            return GateResult(self.name, GateStatus.FAIL, "; ".join(failures))
        return GateResult(
            self.name, GateStatus.PASS, "trusted policy/config is internally consistent",
            {
                "configured_gates": sorted(gates), "tcb_changed": tcb_changed,
                "governance_approval_id": ctx.governance_approval_id if tcb_changed else None,
            },
        )


class SupplyChainGate:
    name = "supply_chain"

    def _lockfile_failures(self, root: Path) -> list[str]:
        failures: list[str] = []
        if (root / "pyproject.toml").exists() and not any((root / x).exists() for x in ("uv.lock", "poetry.lock", "Pipfile.lock", "requirements.lock")):
            failures.append("Python project has no recognized dependency lock (uv.lock/poetry.lock/Pipfile.lock/requirements.lock)")
        if (root / "package.json").exists() and not any((root / x).exists() for x in ("package-lock.json", "pnpm-lock.yaml", "yarn.lock")):
            failures.append("Node project has no recognized lockfile")
        if (root / "Cargo.toml").exists() and not (root / "Cargo.lock").exists():
            failures.append("Rust project has no Cargo.lock")
        return failures

    def run(self, ctx: GateContext) -> GateResult:
        workflows = []
        if ctx.lane is DevelopmentLane.RELEASE:
            workflow_dir = ctx.root / ".github/workflows"
            if workflow_dir.exists():
                workflows = [p.relative_to(ctx.root).as_posix() for p in workflow_dir.rglob("*.yml")]
                workflows += [p.relative_to(ctx.root).as_posix() for p in workflow_dir.rglob("*.yaml")]
        else:
            workflows = [p for p in ctx.changed_files if p.startswith(".github/workflows/") and p.endswith((".yml", ".yaml"))]
        failures: list[str] = []
        for rel in sorted(set(workflows)):
            path = ctx.root / rel
            if not path.exists():
                failures.append(f"{rel}: missing"); continue
            result = github_action_pinning_gate(path.read_text(encoding="utf-8"))
            if result.status is GateStatus.FAIL:
                failures.append(f"{rel}: {result.reason}")
        if ctx.lane is DevelopmentLane.RELEASE:
            failures.extend(self._lockfile_failures(ctx.root))
            sbom = ctx.root / ".ados/sbom.json"
            if not sbom.exists() or not sbom.is_file() or sbom.is_symlink():
                failures.append("release requires a regular .ados/sbom.json bound into build provenance")
            else:
                try:
                    raw = json.loads(sbom.read_text(encoding="utf-8"))
                    if not isinstance(raw, dict) or not isinstance(raw.get("components"), list):
                        raise ValueError("components list missing")
                except Exception as exc:
                    failures.append(f"invalid .ados/sbom.json: {exc}")
        if failures:
            return GateResult(self.name, GateStatus.FAIL, "; ".join(failures))
        if not workflows and ctx.lane is not DevelopmentLane.RELEASE:
            return GateResult(self.name, GateStatus.SKIP, "no changed supply-chain surface")
        return GateResult(self.name, GateStatus.PASS, "immutable workflow references and release dependency prerequisites verified")


class PlaceholderGate:
    def __init__(self, name: str):
        self.name = name

    def run(self, ctx: GateContext) -> GateResult:
        return GateResult(self.name, GateStatus.UNKNOWN, f"{self.name} requires project-specific measured adapter/command")


def default_gate_registry() -> dict[str, Gate]:
    registry: dict[str, Gate] = {
        "source": SourceGate(),
        "safety": RepositorySafetyGate(),
        "supply_chain": SupplyChainGate(),
        "governance": GovernanceGate(),
    }
    for name in [
        "architecture", "tests", "full_regression", "dependency_audit", "contracts", "compatibility", "integration",
        "wiring", "ux", "accessibility", "user_journey", "golden", "tenant_isolation",
        "security", "red_team", "release", "data_migration", "health", "recovery", "rollback",
    ]:
        registry[name] = PlaceholderGate(name)
    return registry
