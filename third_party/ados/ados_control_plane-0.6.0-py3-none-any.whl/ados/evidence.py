from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import asdict, replace
from datetime import datetime, timezone
from typing import Mapping

from . import __version__
from .crypto import sign_ed25519, verify_ed25519
from .event_store import EventStore
from .models import Claim, ClaimKind, Evidence, Task


class EvidenceError(ValueError):
    pass


MIN_SIGNING_SECRET_BYTES = 32


def task_security_context_hash(task: Task) -> str:
    """Hash durable task inputs that may invalidate release evidence."""
    metadata = {k: v for k, v in task.metadata.items() if k != "risk_reasons"}
    candidate = None
    if task.candidate is not None:
        candidate = {
            "repository": task.candidate.repository,
            "branch": task.candidate.branch,
            "sha": task.candidate.sha,
            "tree": task.candidate.tree,
            "generation": task.candidate.generation,
        }
    payload = {
        "task_id": task.task_id,
        "repository": task.repository,
        "goal": task.goal,
        "base_sha": task.base_sha,
        "base_ref": task.base_ref,
        "candidate": candidate,
        "blockers": sorted(task.blockers),
        "metadata": metadata,
    }
    material = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str
    ).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


def _parse(ts: str) -> datetime:
    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def is_fresh(ev: Evidence, now: datetime | None = None, max_clock_skew_seconds: int = 300) -> bool:
    now = now or datetime.now(timezone.utc)
    try:
        age = (now - _parse(ev.verified_at)).total_seconds()
    except (TypeError, ValueError):
        return False
    if age < -max_clock_skew_seconds:
        return False
    if ev.ttl_seconds is None:
        return True
    if ev.ttl_seconds < 0:
        return False
    return age <= ev.ttl_seconds


def _unsigned_evidence_payload(ev: Evidence) -> bytes:
    data = asdict(ev)
    data.pop("signature", None)
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sign_evidence(ev: Evidence, secret: bytes) -> Evidence:
    """Legacy/dev HMAC signing.

    Release policy can require asymmetric Ed25519 signatures; HMAC remains useful
    for local development and backwards-compatible tests, but should not be treated
    as an independent trust domain.
    """
    if len(secret) < MIN_SIGNING_SECRET_BYTES:
        raise EvidenceError(f"evidence signing secret must be at least {MIN_SIGNING_SECRET_BYTES} bytes")
    prepared = replace(
        ev,
        signature_algorithm="hmac-sha256",
        signer_id=ev.signer_id or "shared-secret",
        control_plane_version=ev.control_plane_version or __version__,
    )
    signature = hmac.new(secret, _unsigned_evidence_payload(prepared), hashlib.sha256).hexdigest()
    return replace(prepared, signature=signature)


def sign_evidence_ed25519(ev: Evidence, private_key_pem: bytes) -> Evidence:
    prepared = replace(
        ev,
        signature_algorithm="ed25519",
        control_plane_version=ev.control_plane_version or __version__,
        signature=None,
    )
    # signer_id is itself signed; derive it first, then sign the final payload.
    _, signer_id = sign_ed25519(b"ados-key-identification", private_key_pem)
    prepared = replace(prepared, signer_id=signer_id)
    signature, actual_signer = sign_ed25519(_unsigned_evidence_payload(prepared), private_key_pem)
    if actual_signer != signer_id:
        raise EvidenceError("signer identity changed while signing evidence")
    return replace(prepared, signature=signature)


def evidence_signature_valid(
    ev: Evidence,
    secret: bytes | None = None,
    verification_keys: Mapping[str, bytes] | None = None,
) -> bool:
    if not ev.signature:
        return False
    if ev.signature_algorithm == "ed25519":
        if not ev.signer_id or not verification_keys:
            return False
        key = verification_keys.get(ev.signer_id)
        if key is None:
            return False
        return verify_ed25519(_unsigned_evidence_payload(ev), ev.signature, key)
    if ev.signature_algorithm != "hmac-sha256" or secret is None or len(secret) < MIN_SIGNING_SECRET_BYTES:
        return False
    expected = hmac.new(secret, _unsigned_evidence_payload(ev), hashlib.sha256).hexdigest()
    return hmac.compare_digest(ev.signature, expected)


def require_evidence(
    store: EventStore,
    claim: str,
    repository: str,
    subject_sha: str,
    accepted_conclusions: set[str] | None = None,
    generation: int | None = None,
    subject_tree: str | None = None,
    accepted_sources: set[str] | None = None,
    signature_secret: bytes | None = None,
    verification_keys: Mapping[str, bytes] | None = None,
    require_asymmetric: bool = False,
    context_hash: str | None = None,
    policy_digest: str | None = None,
    provenance_digest: str | None = None,
    required_tags: set[str] | None = None,
    accepted_control_plane_versions: set[str] | None = None,
) -> Evidence:
    store.assert_clock_sane()
    accepted = accepted_conclusions or {"success", "pass", "passed", "true"}
    for ev in store.evidence_for(claim, repository, subject_sha):
        if ev.conclusion.lower() not in accepted or not is_fresh(ev):
            continue
        if generation is not None and ev.generation != generation:
            continue
        if subject_tree is not None and ev.subject_tree != subject_tree:
            continue
        if accepted_sources is not None and ev.source not in accepted_sources:
            continue
        if context_hash is not None and ev.context_hash != context_hash:
            continue
        if policy_digest is not None and ev.policy_digest != policy_digest:
            continue
        if provenance_digest is not None and ev.provenance_digest != provenance_digest:
            continue
        if required_tags is not None and not required_tags.issubset(set(ev.tags)):
            continue
        if accepted_control_plane_versions is not None and ev.control_plane_version not in accepted_control_plane_versions:
            continue
        if require_asymmetric and ev.signature_algorithm != "ed25519":
            continue
        if signature_secret is not None or verification_keys is not None or require_asymmetric:
            if not evidence_signature_valid(ev, secret=signature_secret, verification_keys=verification_keys):
                continue
        return ev
    raise EvidenceError(
        f"No fresh accepted evidence for claim={claim!r} repo={repository!r} sha={subject_sha!r}"
    )


def validate_claim(
    store: EventStore,
    claim: Claim,
    repository: str | None = None,
    subject_sha: str | None = None,
) -> bool:
    if claim.kind in {ClaimKind.UNKNOWN, ClaimKind.ASSUMED}:
        return False
    if claim.kind is ClaimKind.DERIVED:
        if not repository or not subject_sha or not claim.evidence_claim:
            return False
        try:
            require_evidence(store, claim.evidence_claim, repository, subject_sha)
            return True
        except EvidenceError:
            return False
    if claim.kind is ClaimKind.OBSERVED:
        if not repository or not subject_sha or not claim.evidence_claim:
            raise EvidenceError("OBSERVED claims require repository, subject_sha and evidence_claim")
        require_evidence(store, claim.evidence_claim, repository, subject_sha)
        return True
    return False
