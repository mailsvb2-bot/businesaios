from __future__ import annotations

import argparse
import importlib
import inspect
import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from .exceptions import ControlledException, MIN_BREAK_GLASS_SECRET_BYTES
from .crypto import generate_keypair, load_public_key, public_key_fingerprint, read_key
from .audit_anchor import AuditAnchor, AuditAnchorError, create_anchor, verify_anchor_against_store
from .provenance import BuildSpec, ProvenanceError, provenance_digest, run_isolated_build, verify_artifact_provenance
from .runner_attestation import RunnerAttestation, RunnerAttestationError, verify_runner_attestation
from .vulnerability_attestation import (
    VulnerabilityAttestation, VulnerabilityAttestationError, verify_vulnerability_attestation,
)
from .deployment_attestation import (
    DeploymentAttestation, DeploymentAttestationError, verify_deployment_attestation,
)
from .assessment_evidence import (
    AssessmentNotReleasable,
    assessment_results_hash,
    build_release_verified_evidence,
    build_required_gates_evidence,
    build_operational_evidence,
    validate_artifact_digest,
)
from .adapter_manifest import AdapterManifestError, load_manifest_adapters
from .command_gates import CommandGate, CommandGateConfigError, load_command_gates
from .event_store import ConcurrencyConflict, EventStore, LeaseConflict
from .evidence import EvidenceError, require_evidence, task_security_context_hash
from .models import Candidate, DevelopmentLane, ExecutionKind, TaskState
from .state_machine import EvidenceTransitionGuard, InvalidTransition
from .task_store import TaskJournal, TaskAlreadyExists, TaskNotFound
from .impact import ImpactModel
from .gates import Gate, GateContext
from .git_identity import (
    canonical_remote_ref, current_branch, derive_candidate_diff, detached_candidate_worktree,
    git_remote_exists, repository_host_from_remote, repository_identity_from_remote, resolve_commit, resolve_remote_ref, verify_exact_candidate,
)
from .models import ActionRequest, Task
from .orchestrator import Orchestrator
from .policy import Constitution, PolicyEngine
from .project_config import ProjectConfig, policy_digest, certification_policy_digest
from .profile_packs import impact_for_profile
from .rollout import ProductProfile, default_rollout
from .util import sha256_regular_file, write_json
from .doctor import run_doctor
from .feature_flags import PersistentFeatureFlagStore
from .flaky import PersistentFailureLoopDetector, PersistentFlakeTracker
from .scheduler import PersistentScheduler, ScheduledTask


MIN_EVIDENCE_SECRET_BYTES = 32


DEFAULT_CONSTITUTION = {
    "protected_branches": ["main", "master"],
    "protected_paths": [
        ".ados/constitution.json", ".ados/impact.json", ".ados/project.json",
        ".ados/adapters.json", ".ados/commands.json", ".ados/build.json",
        ".ados/sbom.json", ".ados/trust/", ".github/workflows/", "CODEOWNERS",
    ],
    "prohibited_actions": ["delete_repository", "force_push_main", "delete_backups"],
    "deletion_budget": {"max_files_deleted": 5, "max_deleted_line_ratio": 0.20},
}

DEFAULT_IMPACT = {
    "component_patterns": {
        "ui": ["frontend/**", "web/**", "src/ui/**"],
        "api": ["api/**", "backend/api/**", "src/api/**"],
        "auth": ["**/auth/**", "src/auth/**"],
        "integrations": ["**/integrations/**", "**/providers/**"],
        "database": ["**/migrations/**", "migrations/**", "**/models/**"],
        "supply_chain": [".github/workflows/**"],
    },
    "dependencies": {"ui": ["api"], "integrations": ["auth"]},
    "component_gates": {
        "ui": ["wiring", "ux", "accessibility"], "api": ["contracts"],
        "auth": ["security"], "integrations": ["contracts", "integration", "wiring"],
        "database": ["data_migration"], "supply_chain": ["supply_chain"],
    },
    "risk_overrides": [],
}

DEFAULT_PROJECT = {
    "profile": "BACKEND_SERVICE",
    "repository_id": None,
    "capabilities": [],
    "scheduler_resources": [],
    "control_role": "controller_auditor",
    "always_gates": [],
    "adapter_manifest": ".ados/adapters.json",
    "command_manifest": ".ados/commands.json",
    "build_manifest": ".ados/build.json",
    "gate_execution": {"max_workers": 4, "timeout_seconds": 1800.0, "hard_timeout_seconds": 21600.0, "start_method": "spawn"},
    "rollback_safe": False,
    "remote_base": {"mode": "auto", "remote": "origin", "ref": None, "host": None, "timeout_seconds": 15.0},
    "trust": {
        "require_asymmetric_release_signing": True,
        "evidence_public_key_files": [],
        "break_glass_public_key_files": [],
        "runner_public_key_files": [],
        "vulnerability_public_key_files": [],
        "deployment_public_key_files": [],
        "require_runner_attestation_for_certification": True,
        "runner_attestation_env": "ADOS_RUNNER_ATTESTATION_FILE",
        "require_vulnerability_attestation_for_release": True,
        "vulnerability_attestation_env": "ADOS_VULNERABILITY_ATTESTATION_FILE",
        "vulnerability_max_severity": "NONE",
        "require_deployment_attestation_for_health": True,
        "deployment_attestation_env": "ADOS_DEPLOYMENT_ATTESTATION_FILE",
        "deployment_environment": "production",
        "allow_hmac_development": True,
        "accepted_control_plane_versions": [],
    },
    "evidence": {
        "required_gates_ttl_seconds": 86400, "release_ttl_seconds": 86400,
        "rollout_health_ttl_seconds": 1800, "recovery_ttl_seconds": 3600,
    },
    "rollout": {"health_required_tags": ["health", "candidate", "production"]},
    "storage": {"mode": "single_node", "backend": "sqlite"},
    "audit": {"require_external_anchor_for_release": True, "anchor_env": "ADOS_AUDIT_ANCHOR_FILE"},
    "strict_project_gates": True,
    "require_hermetic_build": False,
}



def _backup(path: Path) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = path.with_name(path.name + f".bak.{stamp}")
    shutil.copy2(path, backup)
    return backup



def _load_public_key_map(root: Path, paths: tuple[str, ...]) -> dict[str, bytes]:
    keys: dict[str, bytes] = {}
    for rel in paths:
        path = _root_relative(root, rel).resolve()
        try:
            path.relative_to(root.resolve())
        except ValueError as exc:
            raise ValueError(f"trusted public-key path escapes repository: {rel!r}") from exc
        data = read_key(path)
        key = load_public_key(data)
        signer = public_key_fingerprint(key)
        if signer in keys and keys[signer] != data:
            raise ValueError(f"duplicate signer id with different key material: {signer}")
        keys[signer] = data
    return keys


def _private_key_from_env(env_name: str) -> bytes:
    value = os.environ.get(env_name)
    if not value:
        raise ValueError(f"private signing key env {env_name!r} unavailable")
    path = Path(value)
    data = path.read_bytes() if path.exists() else value.encode("utf-8")
    # Parse eagerly so callers fail before doing expensive work.
    from .crypto import load_private_key
    load_private_key(data)
    return data


def _require_runner_attestation(root: Path, project: ProjectConfig, repository: str, candidate: Candidate) -> RunnerAttestation | None:
    if not project.trust.require_runner_attestation_for_certification:
        return None
    keys = _load_public_key_map(root, project.trust.runner_public_key_files)
    if not keys:
        raise RunnerAttestationError("strict certification requires at least one anchored runner public key")
    value = os.environ.get(project.trust.runner_attestation_env)
    if not value:
        raise RunnerAttestationError(
            f"strict certification requires signed runner attestation in {project.trust.runner_attestation_env}"
        )
    path = Path(value).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError:
        pass
    else:
        raise RunnerAttestationError("runner attestation must live outside the candidate repository")
    attestation = RunnerAttestation.from_file(path)
    verify_runner_attestation(attestation, keys=keys, repository=repository, candidate=candidate)
    return attestation


def cmd_runner_attest(args: argparse.Namespace) -> int:
    try:
        candidate = Candidate(repository=args.repository, branch=args.branch, sha=args.sha, tree=args.tree, generation=args.generation)
        private = _private_key_from_env(args.private_key_env)
        attestation = RunnerAttestation.issue(
            repository=args.repository, candidate=candidate, runner_id=args.runner_id,
            nonce=args.nonce, private_key_pem=private, ttl_seconds=args.ttl,
            isolation="disposable", filesystem_policy="ephemeral",
            network_policy=args.network_policy,
        )
        output = Path(args.output).resolve()
        attestation.to_file(output)
    except (ValueError, OSError, RunnerAttestationError) as exc:
        print(json.dumps({"error": str(exc)}, indent=2))
        return 2
    print(json.dumps({
        "attested": True, "output": str(output), "repository": args.repository,
        "candidate": args.sha, "runner_id": args.runner_id, "expires_at": attestation.expires_at,
        "signer_id": attestation.signer_id,
    }, indent=2))
    return 0


def _require_vulnerability_attestation(
    base_root: Path,
    project: ProjectConfig,
    repository: str,
    candidate: Candidate,
    candidate_root: Path,
) -> VulnerabilityAttestation | None:
    if not project.trust.require_vulnerability_attestation_for_release:
        return None
    keys = _load_public_key_map(base_root, project.trust.vulnerability_public_key_files)
    if not keys:
        raise VulnerabilityAttestationError(
            "strict release requires at least one vulnerability-scanner public key trusted by anchored base"
        )
    value = os.environ.get(project.trust.vulnerability_attestation_env)
    if not value:
        raise VulnerabilityAttestationError(
            f"strict release requires signed vulnerability attestation in {project.trust.vulnerability_attestation_env}"
        )
    path = Path(value).resolve()
    try:
        path.relative_to(candidate_root.resolve())
    except ValueError:
        pass
    else:
        raise VulnerabilityAttestationError("vulnerability attestation must live outside the candidate repository")
    attestation = VulnerabilityAttestation.from_file(path)
    verify_vulnerability_attestation(
        attestation, keys=keys, repository=repository, candidate=candidate,
        candidate_root=candidate_root, allowed_max_severity=project.trust.vulnerability_max_severity,
    )
    return attestation


def cmd_vulnerability_attest(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    try:
        candidate = Candidate(
            repository=args.repository, branch=args.branch, sha=args.sha, tree=args.tree, generation=args.generation
        )
        identity = verify_exact_candidate(root, candidate, require_clean=True)
        if identity.status.value != "PASS":
            raise ValueError(f"exact candidate identity verification failed: {identity.reason}")
        output = Path(args.output).resolve()
        try:
            output.relative_to(root)
        except ValueError:
            pass
        else:
            raise ValueError("vulnerability attestation output must live outside the candidate repository")
        private = _private_key_from_env(args.private_key_env)
        with detached_candidate_worktree(root, candidate.sha, materialize_submodules=True, materialize_lfs=True) as snapshot:
            attestation = VulnerabilityAttestation.issue(
                root=snapshot, repository=args.repository, candidate=candidate,
                scanner_id=args.scanner_id, scanner_version=args.scanner_version,
                advisory_source=args.advisory_source, advisory_snapshot=args.advisory_snapshot,
                report_digest=args.report_digest, findings_count=args.findings_count, max_severity=args.max_severity,
                private_key_pem=private, ttl_seconds=args.ttl,
            )
        attestation.to_file(output)
    except (ValueError, OSError, RuntimeError, subprocess.TimeoutExpired, VulnerabilityAttestationError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({
        "attested": True, "output": str(output), "repository": args.repository,
        "candidate": args.sha, "scanner_id": args.scanner_id, "expires_at": attestation.expires_at,
        "signer_id": attestation.signer_id, "attestation_digest": attestation.digest(),
    }, ensure_ascii=False, indent=2))
    return 0


def _require_deployment_attestation(
    base_root: Path,
    project: ProjectConfig,
    repository: str,
    candidate: Candidate,
    *,
    artifact_digest: str,
) -> DeploymentAttestation | None:
    if not project.trust.require_deployment_attestation_for_health:
        return None
    keys = _load_public_key_map(base_root, project.trust.deployment_public_key_files)
    if not keys:
        raise DeploymentAttestationError(
            "production health requires at least one deployment/health public key trusted by anchored base"
        )
    value = os.environ.get(project.trust.deployment_attestation_env)
    if not value:
        raise DeploymentAttestationError(
            f"production health requires signed deployment attestation in {project.trust.deployment_attestation_env}"
        )
    path = Path(value).resolve()
    try:
        path.relative_to(base_root.resolve())
    except ValueError:
        pass
    else:
        raise DeploymentAttestationError("deployment attestation must live outside the repository")
    attestation = DeploymentAttestation.from_file(path)
    verify_deployment_attestation(
        attestation, keys=keys, repository=repository, candidate=candidate,
        artifact_digest=artifact_digest, required_environment=project.trust.deployment_environment,
        required_status="HEALTHY",
    )
    return attestation


def cmd_deployment_attest(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    try:
        candidate = Candidate(
            repository=args.repository, branch=args.branch, sha=args.sha, tree=args.tree, generation=args.generation
        )
        identity = verify_exact_candidate(root, candidate, require_clean=True)
        if identity.status.value != "PASS":
            raise ValueError(f"exact candidate identity verification failed: {identity.reason}")
        output = Path(args.output).resolve()
        try:
            output.relative_to(root)
        except ValueError:
            pass
        else:
            raise ValueError("deployment attestation output must live outside the repository")
        artifact = Path(args.artifact).resolve()
        private = _private_key_from_env(args.private_key_env)
        attestation = DeploymentAttestation.issue(
            repository=args.repository, candidate=candidate, artifact=artifact,
            deployment_id=args.deployment_id, environment=args.environment, target=args.target, status=args.status,
            probe_id=args.probe_id, probe_version=args.probe_version, measurements_hash=args.measurements_hash,
            private_key_pem=private, ttl_seconds=args.ttl,
        )
        attestation.to_file(output)
    except (ValueError, OSError, RuntimeError, DeploymentAttestationError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({
        "attested": True, "output": str(output), "repository": args.repository,
        "candidate": args.sha, "artifact_digest": attestation.artifact_digest,
        "deployment_id": attestation.deployment_id, "status": attestation.status,
        "signer_id": attestation.signer_id, "attestation_digest": attestation.digest(),
    }, ensure_ascii=False, indent=2))
    return 0


def _trusted_keys_at_base(root: Path, project: ProjectConfig, base_sha: str, *, break_glass: bool = False) -> dict[str, bytes]:
    paths = project.trust.break_glass_public_key_files if break_glass else project.trust.evidence_public_key_files
    if not paths:
        return {}
    # Trust roots are read from the already-anchored base, never from candidate
    # bytes. A candidate therefore cannot authorize itself by rotating its key.
    with detached_candidate_worktree(root, base_sha) as base_snapshot:
        return _load_public_key_map(base_snapshot, paths)


def _repository_id_for_init(root: Path, explicit: str | None) -> str:
    if explicit:
        return explicit
    derived = repository_identity_from_remote(root)
    if derived:
        return derived
    # Development-only local identity keeps init usable without inventing a
    # production remote. Release certification refuses local/* identities.
    return f"local/{root.resolve().name}"


def _evidence_ttl(project: ProjectConfig, claim: str, requested: int | None) -> int:
    configured = {
        "required_gates_passed": project.evidence.required_gates_ttl_seconds,
        "release_verified": project.evidence.release_ttl_seconds,
        "rollout_health_verified": project.evidence.rollout_health_ttl_seconds,
        "recovery_verified": project.evidence.recovery_ttl_seconds,
        "rollback_verified": project.evidence.recovery_ttl_seconds,
    }.get(claim, project.evidence.required_gates_ttl_seconds)
    if requested is None:
        return configured
    if requested <= 0 or requested > configured:
        raise ValueError(f"requested evidence TTL must be >0 and <= project policy ({configured}s)")
    return requested

def cmd_init(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    targets = [root / ".ados/constitution.json", root / ".ados/impact.json", root / ".ados/project.json"]
    existing = [p for p in targets if p.exists()]
    if existing and not args.force:
        print(json.dumps({"error": "ADOS config already exists", "paths": [str(p) for p in existing]}, indent=2))
        return 2
    if args.force:
        for p in existing:
            _backup(p)
    write_json(targets[0], DEFAULT_CONSTITUTION)
    profile = ProductProfile(args.profile)
    write_json(targets[1], impact_for_profile(DEFAULT_IMPACT, profile))
    project = json.loads(json.dumps(DEFAULT_PROJECT))
    project["profile"] = args.profile
    project["repository_id"] = _repository_id_for_init(root, args.repository_id)
    if git_remote_exists(root, "origin"):
        project["remote_base"]["mode"] = "required"
        project["remote_base"]["host"] = repository_host_from_remote(root, "origin")
    write_json(targets[2], project)
    commands_path = root / ".ados/commands.json"
    if not commands_path.exists() or args.force:
        if commands_path.exists() and args.force:
            _backup(commands_path)
        write_json(commands_path, {"version": 1, "gates": []})
    adapters_path = root / ".ados/adapters.json"
    if not adapters_path.exists() or args.force:
        if adapters_path.exists() and args.force:
            _backup(adapters_path)
        write_json(adapters_path, {"version": 1, "adapters": []})
    build_path = root / ".ados/build.json"
    if not build_path.exists() or args.force:
        if build_path.exists() and args.force:
            _backup(build_path)
        write_json(build_path, {
            "argv": ["{python}", "-m", "build", "--wheel", "--no-isolation"],
            "artifact_glob": "dist/*",
            "timeout_seconds": 3600,
            "sbom_path": ".ados/sbom.json",
            "toolchain_commands": {"python": ["{python}", "--version"]},
        })
    ignore = root / ".ados/.gitignore"
    ignore.parent.mkdir(parents=True, exist_ok=True)
    if not ignore.exists():
        ignore.write_text("control-plane.db*\n*.sqlite\n*.sqlite-*\n*.db-wal\n*.db-shm\n*.bak.*\n", encoding="utf-8")
    print(json.dumps({
        "initialized": True, "root": str(root), "repository_id": project["repository_id"],
        "release_ready": False,
        "next": "configure real project gates, build manifest, SBOM and an Ed25519 trust key before release certification",
    }, ensure_ascii=False, indent=2))
    return 0



def cmd_keygen(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    private_path = Path(args.private_out).resolve()
    public_path = _root_relative(root, args.public_out).resolve()
    try:
        private_path.relative_to(root)
    except ValueError:
        pass
    else:
        print(json.dumps({"error": "private signing key must be stored outside the repository"}, indent=2))
        return 2
    try:
        public_path.relative_to(root)
    except ValueError:
        print(json.dumps({"error": "public key path must stay inside the repository"}, indent=2))
        return 2
    if (private_path.exists() or public_path.exists()) and not args.force:
        print(json.dumps({"error": "key output exists; use --force only when intentional"}, indent=2))
        return 2
    private_pem, public_pem, signer = generate_keypair()
    private_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.parent.mkdir(parents=True, exist_ok=True)
    private_path.write_bytes(private_pem)
    try:
        os.chmod(private_path, 0o600)
    except OSError:
        pass
    public_path.write_bytes(public_pem)
    print(json.dumps({
        "generated": True, "signer_id": signer,
        "private_key": str(private_path), "public_key": str(public_path),
        "warning": "keep the private key outside Git and outside build artifacts",
    }, indent=2))
    return 0


def _assert_project_repository(root: Path, project: ProjectConfig, repository: str, *, release: bool) -> None:
    if not project.repository_id:
        raise ValueError("protected project has no repository_id")
    if project.repository_id != repository:
        raise ValueError(f"repository mismatch: task={repository!r} protected={project.repository_id!r}")
    derived = repository_identity_from_remote(root, project.remote_base.remote)
    if derived is not None and derived != project.repository_id:
        raise ValueError(f"repository identity mismatch: remote={derived!r} protected={project.repository_id!r}")
    if release and project.repository_id.startswith("local/"):
        raise ValueError("release certification refuses development-only local/* repository identities")


def cmd_build_artifact(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    store = EventStore(_root_relative(root, args.db))
    journal = TaskJournal(store)
    try:
        stored = journal.load(args.task)
        task = stored.task
        if task.state is not TaskState.RELEASING:
            raise ValueError("isolated release build requires task state RELEASING")
        if task.candidate is None or task.base_sha is None or task.base_ref is None:
            raise ValueError("release build requires exact candidate and trusted base")
        identity = verify_exact_candidate(root, task.candidate, require_clean=True)
        if identity.status.value != "PASS":
            raise ValueError(f"exact candidate identity verification failed: {identity.reason}")
        changed_files, deleted_files = derive_candidate_diff(root, task.base_sha, task.candidate.sha)
        private_key = _private_key_from_env(args.private_key_env)
        output = Path(args.output).resolve()
        try:
            output.relative_to(root)
        except ValueError:
            pass
        else:
            raise ValueError("release artifact output must be outside the live repository")

        with detached_candidate_worktree(root, task.base_sha, materialize_submodules=True, materialize_lfs=True) as base_snapshot:
            trusted_project = ProjectConfig.from_file(base_snapshot / ".ados/project.json")
            _assert_project_repository(root, trusted_project, task.repository, release=True)
            _assert_remote_base_truth(root, trusted_project, task.base_ref, task.base_sha, require_for_release=True)
            verification_keys = _load_public_key_map(base_snapshot, trusted_project.trust.evidence_public_key_files)
            runner_verification_keys = _load_public_key_map(base_snapshot, trusted_project.trust.runner_public_key_files)
            if not verification_keys:
                raise ValueError("release build requires at least one evidence public key trusted by anchored base")
            runner_attestation = _require_runner_attestation(base_snapshot, trusted_project, task.repository, task.candidate)
            with detached_candidate_worktree(root, task.candidate.sha, materialize_submodules=True, materialize_lfs=True) as candidate_snapshot:
                candidate_project = ProjectConfig.from_file(candidate_snapshot / ".ados/project.json")
                tcb_paths = _tcb_change_paths(base_snapshot, candidate_snapshot, changed_files, deleted_files)
                approved, _ = _verify_governance_exception(
                    args.governance_exception, base_root=base_snapshot, trusted_project=trusted_project,
                    repository=task.repository, candidate_sha=task.candidate.sha, tcb_paths=tcb_paths,
                )
                if tcb_paths and not approved:
                    raise ValueError(f"release build changes trusted computing base and requires --governance-exception: {list(tcb_paths)}")
                pdigest = certification_policy_digest(base_snapshot, candidate_snapshot, trusted_project, candidate_project)
                # The candidate build recipe is allowed only after independent TCB review;
                # otherwise it is byte-identical/trusted by the baseline path protection.
                build_spec = BuildSpec.from_file(candidate_snapshot / candidate_project.build_manifest)
                artifact, prov_path, prov = run_isolated_build(
                    candidate_snapshot, candidate=task.candidate, repository=task.repository, spec=build_spec,
                    destination=output, private_key_pem=private_key, policy_digest_value=pdigest,
                    runner_attestation=runner_attestation,
                )
                require_hermetic = trusted_project.require_hermetic_build or candidate_project.require_hermetic_build
        verify_artifact_provenance(
            artifact=artifact, provenance_path=prov_path, candidate=task.candidate,
            repository=task.repository, policy_digest_value=pdigest,
            verification_keys=verification_keys, require_hermetic=require_hermetic,
            require_runner_attestation=trusted_project.trust.require_runner_attestation_for_certification,
            runner_verification_keys=runner_verification_keys,
            accepted_control_plane_versions=set(trusted_project.trust.accepted_control_plane_versions) or None,
        )
    except (TaskNotFound, ValueError, OSError, RuntimeError, subprocess.TimeoutExpired, ProvenanceError, FileNotFoundError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({
        "built": True, "artifact": str(artifact), "artifact_digest": prov.artifact_digest,
        "provenance": str(prov_path), "provenance_digest": provenance_digest(prov_path),
        "candidate": task.candidate.sha, "policy_digest": pdigest,
    }, ensure_ascii=False, indent=2))
    return 0


def cmd_audit_anchor(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    store = EventStore(_root_relative(root, args.db))
    project = _project_for_root(root, args.project_config)
    if project is None:
        print(json.dumps({"error": "audit anchor requires project config"}, indent=2))
        return 2
    try:
        keys = _load_public_key_map(root, project.trust.evidence_public_key_files)
        path_value = args.output or os.environ.get(project.audit.anchor_env)
        if not path_value:
            raise ValueError(f"anchor output missing; pass --output or set {project.audit.anchor_env}")
        output = Path(path_value).resolve()
        try:
            output.relative_to(root)
        except ValueError:
            pass
        else:
            raise ValueError("external audit anchor must live outside the repository/control-plane storage")
        if args.verify:
            anchor = AuditAnchor.from_file(output)
            if not verify_anchor_against_store(anchor, store, keys):
                raise AuditAnchorError("external audit anchor does not match current control-plane state")
            print(json.dumps({"verified": True, "anchor": str(output), "signer_id": anchor.signer_id}, indent=2))
            return 0
        private_key = _private_key_from_env(args.private_key_env)
        anchor = create_anchor(store, private_key)
        if not anchor.verify(keys):
            raise AuditAnchorError("new anchor signer is not trusted by protected project policy")
        anchor.write(output)
        print(json.dumps({"anchored": True, "anchor": str(output), "signer_id": anchor.signer_id}, indent=2))
        return 0
    except (ValueError, OSError, AuditAnchorError, FileNotFoundError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 2

def _load_exception(args: argparse.Namespace, root: Path, project: ProjectConfig | None) -> tuple[ControlledException | None, bytes | None, dict[str, bytes]]:
    if not args.exception:
        return None, None, {}
    exception = ControlledException.from_file(args.exception)
    public_keys: dict[str, bytes] = {}
    secret: bytes | None = None
    if exception.irreversible:
        if project is None:
            raise ValueError("irreversible exception requires protected project configuration")
        public_keys = _load_public_key_map(root, project.trust.break_glass_public_key_files)
        if len(public_keys) < 2:
            raise ValueError("irreversible exception requires at least two protected break-glass public keys")
    else:
        env_name = args.break_glass_secret_env
        secret_text = os.environ.get(env_name)
        if not secret_text:
            raise ValueError(f"signed reversible exception supplied but secret env {env_name!r} is unavailable")
        secret = secret_text.encode("utf-8")
        if len(secret) < MIN_BREAK_GLASS_SECRET_BYTES:
            raise ValueError(f"break-glass signing secret must be at least {MIN_BREAK_GLASS_SECRET_BYTES} bytes")
    return exception, secret, public_keys


def cmd_exception_create(args: argparse.Namespace) -> int:
    try:
        approved = tuple(dict.fromkeys(args.approver or ()))
        if not approved:
            raise ValueError("exception requires at least one --approver")
        if args.irreversible and len(approved) < 2:
            raise ValueError("irreversible exception requires at least two independent approvers")
        exc = ControlledException(
            exception_id=args.exception_id,
            rule_id=args.rule_id,
            scope=args.scope,
            approved_by=approved,
            reason=args.reason,
            expires_at=args.expires_at,
            irreversible=bool(args.irreversible),
        )
        # Validate expiry syntax/future without accepting it as signed yet.
        from datetime import datetime, timezone
        expiry = datetime.fromisoformat(exc.expires_at.replace("Z", "+00:00"))
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
        if expiry <= datetime.now(timezone.utc):
            raise ValueError("exception expiry must be in the future")
        exc.to_file(args.output)
    except (ValueError, OSError) as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False, indent=2)); return 2
    print(json.dumps({"created": True, "exception": str(Path(args.output).resolve()), "approved_by": list(approved)}, indent=2)); return 0


def cmd_exception_sign(args: argparse.Namespace) -> int:
    try:
        exc = ControlledException.from_file(args.exception)
        key_data = _private_key_from_env(args.private_key_env)
        from .crypto import load_private_key
        signer_id = public_key_fingerprint(load_private_key(key_data).public_key())
        approver_id = args.approver_id or signer_id
        if approver_id != signer_id:
            raise ValueError(f"approver id must equal signing-key fingerprint {signer_id}")
        if approver_id not in exc.approved_by:
            raise ValueError("signing key fingerprint is not listed in exception approved_by")
        signed = exc.add_approval(approver_id, key_data)
        signed.to_file(args.output or args.exception)
    except (ValueError, OSError, FileNotFoundError) as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False, indent=2)); return 2
    print(json.dumps({"signed": True, "approver_id": approver_id, "output": str(Path(args.output or args.exception).resolve())}, indent=2)); return 0


def cmd_check_action(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    constitution = Constitution.from_file(_root_relative(root, args.constitution))
    project = _project_for_root(root, args.project_config)
    try:
        exception, secret, public_keys = _load_exception(args, root, project)
    except ValueError as exc:
        print(json.dumps({"decision": "DENY", "reason": str(exc)}, indent=2)); return 2
    engine = PolicyEngine(constitution, break_glass_secret=secret, break_glass_public_keys=public_keys)
    req = ActionRequest(
        action=args.action, actor_role=args.role, environment=args.environment, branch=args.branch,
        command=args.command, capability=args.capability, changed_files=tuple(args.file or []),
        deleted_files=args.deleted_files, deleted_lines=args.deleted_lines,
        total_changed_lines=args.total_changed_lines,
    )
    results = engine.evaluate(req, exception=exception)
    final = engine.final_decision(results)
    print(json.dumps({"decision": final.decision.value, "reason": final.reason, "checks": [r.__dict__ | {"decision": r.decision.value} for r in results]}, indent=2))
    return 0 if final.decision.value == "ALLOW" else 2



def _root_relative(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def _load_adapters(specs: list[str]) -> dict[str, Gate]:
    adapters: dict[str, Gate] = {}
    for spec in specs:
        if "=" not in spec or ":" not in spec:
            raise ValueError(f"invalid adapter spec {spec!r}; expected gate=module:attribute")
        gate_name, target = spec.split("=", 1)
        module_name, attr_name = target.split(":", 1)
        module = importlib.import_module(module_name)
        obj = getattr(module, attr_name)
        if inspect.isclass(obj):
            obj = obj()
        elif callable(obj) and not hasattr(obj, "run"):
            obj = obj()
        if not hasattr(obj, "run") or not hasattr(obj, "name"):
            raise TypeError(f"adapter {spec!r} does not expose a Gate-like object")
        if obj.name != gate_name:
            raise ValueError(f"adapter gate name mismatch: requested={gate_name!r} actual={obj.name!r}")
        adapters[gate_name] = obj
    return adapters

def _load_project_runtime(root: Path, args: argparse.Namespace):
    project_config_arg = getattr(args, "project_config", None)
    project_path = _root_relative(root, project_config_arg) if project_config_arg else (root / ".ados/project.json")
    project = ProjectConfig.from_file(project_path) if project_path.exists() else None
    adapters: dict[str, Gate] = {}
    adapter_manifest_arg = getattr(args, "adapter_manifest", None)
    if adapter_manifest_arg:
        manifest_path = _root_relative(root, adapter_manifest_arg)
    elif project is not None:
        manifest_path = root / project.adapter_manifest
    else:
        manifest_path = root / ".ados/adapters.json"
    if manifest_path.exists():
        adapters.update(load_manifest_adapters(root, manifest_path))
    if project is not None:
        command_manifest_path = root / project.command_manifest
    else:
        command_manifest_path = root / ".ados/commands.json"
    if command_manifest_path.exists():
        command_gates = load_command_gates(root, command_manifest_path)
        duplicates = set(adapters).intersection(command_gates)
        if duplicates:
            raise ValueError(f"duplicate gate across adapter/command manifests: {sorted(duplicates)}")
        adapters.update(command_gates)
    direct = getattr(args, "adapter", None) or []
    if direct:
        if not getattr(args, "unsafe_adapter_override", False):
            raise ValueError("direct --adapter loading is disabled by default; use protected --adapter-manifest or explicit --unsafe-adapter-override for exploration")
        adapters.update(_load_adapters(direct))
    return project, adapters


STRICT_GATE_ASSURANCES: dict[str, frozenset[str]] = {
    "architecture": frozenset({"architecture"}),
    "tests": frozenset({"tests"}),
    "full_regression": frozenset({"full_regression"}),
    "dependency_audit": frozenset({"lockfile_integrity", "license_policy"}),
    "release": frozenset({"release_readiness"}),
}

OPERATIONAL_GATE_ASSURANCES: dict[str, frozenset[str]] = {
    "health": frozenset({"production_health"}),
    "recovery": frozenset({"production_recovery"}),
    "rollback": frozenset({"production_rollback"}),
}

def _validate_assurance_contracts(adapters: dict[str, Gate], lane: DevelopmentLane, *, strict: bool) -> None:
    if not strict or lane is DevelopmentLane.DEVELOPMENT:
        return
    required_names = {"architecture", "tests"}
    if lane is DevelopmentLane.RELEASE:
        required_names.update({"full_regression", "dependency_audit", "release"})
    failures: list[str] = []
    for name in sorted(required_names):
        gate = adapters.get(name)
        if not isinstance(gate, CommandGate):
            continue  # missing/non-command is handled by ordinary gate selection/blocking
        missing = STRICT_GATE_ASSURANCES[name] - set(gate.spec.assurances)
        if missing:
            failures.append(f"{name} missing assurances {sorted(missing)}")
    if failures:
        raise ValueError("strict gate assurance contract incomplete: " + "; ".join(failures))


def _run_assessment(
    root: Path,
    impact_path: str,
    task: Task,
    args: argparse.Namespace,
    *,
    policy_root: Path | None = None,
    supplemental_root: Path | None = None,
    governance_approved: bool = False,
    governance_approval_id: str | None = None,
):
    """Assess candidate bytes while deriving authority from an anchored policy root.

    ``root`` is the disposable candidate snapshot on which gates execute.  The impact
    model, project policy and same-name project gate definitions come from
    ``policy_root`` (normally the anchored base commit).  An independently approved
    TCB transition may add *new* gate names from ``supplemental_root``; it may never
    replace an already trusted gate for the current certification.
    """
    authority = (policy_root or root).resolve()
    impact = ImpactModel.from_file(_root_relative(authority, impact_path))
    project, adapters = _load_project_runtime(authority, args)
    candidate_project: ProjectConfig | None = None
    if supplemental_root is not None and supplemental_root.resolve() != authority:
        candidate_args = argparse.Namespace(**vars(args))
        candidate_args.project_config = '.ados/project.json'
        candidate_args.adapter_manifest = None
        candidate_project, candidate_adapters = _load_project_runtime(supplemental_root.resolve(), candidate_args)
        if governance_approved:
            for name, gate in candidate_adapters.items():
                # A two-person TCB approval authorizes the exact candidate policy
                # bytes, including intentional upgrades of an existing gate.
                adapters[name] = gate
    if project is not None and project.repository_id is not None and task.repository != project.repository_id:
        raise ValueError(
            f"task repository {task.repository!r} does not match anchored project repository_id {project.repository_id!r}"
        )
    lane_raw = getattr(args, "lane", None) or task.lane.value
    lane = lane_raw if isinstance(lane_raw, DevelopmentLane) else DevelopmentLane(str(lane_raw).upper())
    _validate_assurance_contracts(adapters, lane, strict=bool(project and project.strict_project_gates))
    always = set(project.always_gates if project else ())
    capabilities = set(project.capabilities if project else ())
    if governance_approved and candidate_project is not None:
        # Candidate policy may strengthen this transition after independent review,
        # but cannot remove baseline gates/capabilities.
        always.update(candidate_project.always_gates)
        capabilities.update(candidate_project.capabilities)
    return Orchestrator(
        impact,
        gates=adapters,
        always_gates=frozenset(always),
        execution_policy=project.gate_execution if project else None,
        capabilities=frozenset(capabilities),
    ).assess(
        root, task, tuple(getattr(args, "file", None) or ()),
        tuple(getattr(args, "deleted_file", None) or ()), lane=lane,
        trusted_policy_root=authority,
        governance_approved=governance_approved,
        governance_approval_id=governance_approval_id,
    )


def cmd_assess(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    task = Task(task_id=args.task, repository=args.repository, goal=args.goal, metadata={"lane": args.lane})
    try:
        assessment = _run_assessment(root, args.impact, task, args)
    except (AdapterManifestError, CommandGateConfigError, ValueError, TypeError, ImportError, AttributeError, FileNotFoundError) as exc:
        print(json.dumps({"error": f"failed to prepare assessment: {exc}"}, ensure_ascii=False, indent=2))
        return 2
    payload = {
        "task": assessment.task.to_dict(),
        "results": [
            {"gate": r.gate, "status": r.status.value, "reason": r.reason, "details": r.details}
            for r in assessment.gate_results
        ],
        "blocking_failures": len(assessment.blocking_failures),
        "unknown_gates": len(assessment.unknowns),
        "release_blockers": len(assessment.release_blockers),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    if assessment.blocking_failures:
        return 2
    if assessment.lane is not DevelopmentLane.DEVELOPMENT and assessment.unknowns and not args.allow_unknown:
        return 3
    return 0



def _candidate_snapshot_arg(root: Path, value: str | None, *, field: str) -> str | None:
    if value is None:
        return None
    path = Path(value)
    absolute = path.resolve() if path.is_absolute() else (root / path).resolve()
    try:
        relative = absolute.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"{field} must be inside the repository for certification") from exc
    if ".." in relative.parts:
        raise ValueError(f"{field} escapes the repository")
    return relative.as_posix()


def _declared_trusted_execution_paths(root: Path) -> frozenset[str]:
    """Return repository files whose bytes define trusted gate/build execution.

    A manifest is not a complete trust boundary when it invokes a mutable script.
    Those scripts therefore participate in TCB-change governance as well.
    """
    root = root.resolve()
    paths: set[str] = set()
    try:
        project = ProjectConfig.from_file(root / ".ados/project.json")
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return frozenset()
    for rel_manifest in (project.command_manifest, project.build_manifest):
        manifest = (root / rel_manifest).resolve(strict=False)
        try:
            manifest.relative_to(root)
        except ValueError:
            continue
        if not manifest.exists() or not manifest.is_file() or manifest.is_symlink():
            continue
        try:
            raw = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if rel_manifest == project.command_manifest:
            entries = raw.get("gates", []) if isinstance(raw, dict) else []
            for entry in entries if isinstance(entries, list) else []:
                if isinstance(entry, dict):
                    for value in entry.get("trusted_files", []):
                        if isinstance(value, str) and value and not Path(value).is_absolute() and ".." not in Path(value).parts:
                            paths.add(Path(value).as_posix())
        elif isinstance(raw, dict):
            for value in raw.get("trusted_files", []):
                if isinstance(value, str) and value and not Path(value).is_absolute() and ".." not in Path(value).parts:
                    paths.add(Path(value).as_posix())
    return frozenset(paths)


def _tcb_change_paths(base_root: Path, candidate_root: Path, changed: tuple[str, ...], deleted: tuple[str, ...]) -> tuple[str, ...]:
    base_const = Constitution.from_file(base_root / ".ados/constitution.json")
    candidate_const = Constitution.from_file(candidate_root / ".ados/constitution.json")
    trusted_exec = _declared_trusted_execution_paths(base_root) | _declared_trusted_execution_paths(candidate_root)
    paths = tuple(dict.fromkeys((*changed, *deleted)))
    return tuple(sorted(
        path for path in paths
        if base_const.is_protected_path(path)
        or candidate_const.is_protected_path(path)
        or path in trusted_exec
        or path.startswith(".github/workflows/")
        or path == "CODEOWNERS"
    ))


def _verify_governance_exception(
    path: str | None,
    *,
    base_root: Path,
    trusted_project: ProjectConfig,
    repository: str,
    candidate_sha: str,
    tcb_paths: tuple[str, ...],
) -> tuple[bool, str | None]:
    if not tcb_paths:
        return False, None
    if not path:
        return False, None
    exception = ControlledException.from_file(path)
    if exception.rule_id != "TRUSTED_COMPUTING_BASE_CHANGE":
        raise ValueError("governance exception must use rule_id TRUSTED_COMPUTING_BASE_CHANGE")
    expected_scope = f"tcb:{repository}:{candidate_sha}"
    if exception.scope != expected_scope:
        raise ValueError(f"governance exception scope mismatch: expected={expected_scope!r}")
    if not exception.irreversible:
        raise ValueError("TCB governance approval must use irreversible=true and independent signatures")
    keys = _load_public_key_map(base_root, trusted_project.trust.break_glass_public_key_files)
    if len(keys) < 2:
        raise ValueError("anchored base policy requires at least two independent break-glass public keys for TCB changes")
    if not exception.is_valid(secret=None, approval_public_keys=keys, require_signature=True):
        raise ValueError("governance exception lacks two valid independent Ed25519 approvals or is expired")
    return True, exception.exception_id



def _run_measured_command_gate(snapshot_root: Path, project: ProjectConfig, task: Task, gate_name: str):
    args = argparse.Namespace(
        project_config=".ados/project.json", adapter_manifest=None,
        adapter=[], unsafe_adapter_override=False,
    )
    _, gates = _load_project_runtime(snapshot_root, args)
    gate = gates.get(gate_name)
    if gate is None:
        raise ValueError(f"measured operational claim requires configured {gate_name!r} command gate")
    if not isinstance(gate, CommandGate):
        raise ValueError(f"operational gate {gate_name!r} must be a command gate; Python adapters are not a production trust boundary")
    required_assurances = OPERATIONAL_GATE_ASSURANCES.get(gate_name, frozenset())
    missing = required_assurances - set(gate.spec.assurances)
    if missing:
        raise ValueError(f"operational gate {gate_name!r} missing assurance contract: {sorted(missing)}")
    return gate.run(GateContext(snapshot_root, task, (), (), DevelopmentLane.RELEASE))

def _assert_certification_remote_truth(root: Path, project: ProjectConfig, base_ref: str, base_sha: str, *, require_for_release: bool) -> None:
    try:
        _assert_remote_base_truth(root, project, base_ref, base_sha, require_for_release=require_for_release)
    except (ValueError, OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
        raise AssessmentNotReleasable(str(exc)) from exc


def cmd_certify(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    store = EventStore(_root_relative(root, args.db))
    journal = TaskJournal(store)
    try:
        stored = journal.load(args.task)
        if stored.version != args.expected_version:
            raise ConcurrencyConflict(f"stale task version: expected={args.expected_version} actual={stored.version}")
        task = stored.task
        claim_states = {
            "required_gates_passed": {TaskState.VALIDATING},
            "release_verified": {TaskState.RELEASING},
            "rollout_health_verified": {TaskState.CANARY, TaskState.PARTIALLY_DEPLOYED, TaskState.DEGRADED},
            "recovery_verified": {TaskState.RECOVERING},
            "rollback_verified": {TaskState.CANARY, TaskState.PARTIALLY_DEPLOYED, TaskState.DEGRADED, TaskState.RECOVERING},
        }
        if task.state not in claim_states[args.claim]:
            allowed = [x.value for x in sorted(claim_states[args.claim], key=lambda x: x.value)]
            raise AssessmentNotReleasable(f"claim {args.claim!r} may only be certified in states {allowed}; current={task.state.value}")
        if task.candidate is None or task.base_sha is None or task.base_ref is None:
            raise ValueError("task requires an exact candidate and trusted base_sha/base_ref")
        if task.blockers:
            raise AssessmentNotReleasable(f"task has durable blockers: {sorted(task.blockers)}")
        if getattr(args, "file", None) or getattr(args, "deleted_file", None):
            raise ValueError("certify derives changed/deleted files from Git base..candidate; manual file lists are forbidden")
        identity = verify_exact_candidate(root, task.candidate, require_clean=True)
        if identity.status.value != "PASS":
            raise ValueError(f"exact candidate identity verification failed: {identity.reason}")
        current_base = resolve_commit(root, task.base_ref)
        if current_base != task.base_sha:
            raise AssessmentNotReleasable(f"base ref moved: expected={task.base_sha} actual={current_base}")
        changed_files, deleted_files = derive_candidate_diff(root, task.base_sha, task.candidate.sha)
        context_hash = task_security_context_hash(task)

        snapshot_impact = _candidate_snapshot_arg(root, args.impact, field="impact config") or ".ados/impact.json"
        snapshot_project_arg = _candidate_snapshot_arg(root, args.project_config, field="project config") if args.project_config else ".ados/project.json"
        with detached_candidate_worktree(root, task.base_sha, materialize_submodules=True, materialize_lfs=True) as base_snapshot:
            trusted_project = ProjectConfig.from_file(base_snapshot / snapshot_project_arg)
            _assert_project_repository(root, trusted_project, task.repository, release=(args.claim != "required_gates_passed"))
            _assert_certification_remote_truth(root, trusted_project, task.base_ref, task.base_sha, require_for_release=(args.claim != "required_gates_passed"))
            verification_keys = _load_public_key_map(base_snapshot, trusted_project.trust.evidence_public_key_files)
            if not verification_keys:
                raise ValueError("certification requires at least one evidence public key trusted by the anchored base")
            runner_attestation = _require_runner_attestation(base_snapshot, trusted_project, task.repository, task.candidate)
            ttl = _evidence_ttl(trusted_project, args.claim, args.ttl)
            private_key = _private_key_from_env(args.private_key_env)

            anchor_path: Path | None = None
            if args.claim == "release_verified" and trusted_project.audit.require_external_anchor_for_release:
                anchor_value = os.environ.get(trusted_project.audit.anchor_env)
                if not anchor_value:
                    raise AuditAnchorError(f"release requires external audit anchor path in {trusted_project.audit.anchor_env}")
                anchor_path = Path(anchor_value).resolve()
                try:
                    anchor_path.relative_to(root)
                except ValueError:
                    pass
                else:
                    raise AuditAnchorError("external audit anchor must live outside the repository")
                if not anchor_path.exists():
                    raise AuditAnchorError("external audit anchor does not exist; run ados audit-anchor before release certification")
                if not verify_anchor_against_store(AuditAnchor.from_file(anchor_path), store, verification_keys):
                    raise AuditAnchorError("external audit anchor does not match current control-plane state")

            with detached_candidate_worktree(root, task.candidate.sha, materialize_submodules=True, materialize_lfs=True) as candidate_snapshot:
                candidate_project = ProjectConfig.from_file(candidate_snapshot / snapshot_project_arg)
                pdigest = certification_policy_digest(base_snapshot, candidate_snapshot, trusted_project, candidate_project)
                vulnerability_attestation = None
                if args.claim == "release_verified":
                    vulnerability_attestation = _require_vulnerability_attestation(
                        base_snapshot, trusted_project, task.repository, task.candidate, candidate_snapshot
                    )
                tcb_paths = _tcb_change_paths(base_snapshot, candidate_snapshot, changed_files, deleted_files)
                governance_approved, governance_id = _verify_governance_exception(
                    args.governance_exception, base_root=base_snapshot, trusted_project=trusted_project,
                    repository=task.repository, candidate_sha=task.candidate.sha, tcb_paths=tcb_paths,
                )
                if args.claim in {"required_gates_passed", "release_verified"}:
                    assessment_args = argparse.Namespace(**vars(args))
                    assessment_args.project_config = snapshot_project_arg
                    assessment_args.adapter_manifest = None
                    assessment_args.lane = DevelopmentLane.MERGE.value if args.claim == "required_gates_passed" else DevelopmentLane.RELEASE.value
                    assessment_args.file = list(changed_files)
                    assessment_args.deleted_file = list(deleted_files)
                    assessment = _run_assessment(
                        candidate_snapshot, snapshot_impact, task, assessment_args,
                        policy_root=base_snapshot, supplemental_root=candidate_snapshot,
                        governance_approved=governance_approved, governance_approval_id=governance_id,
                    )
                    if assessment.release_blockers:
                        raise AssessmentNotReleasable(
                            "assessment has blockers: " + ", ".join(f"{r.gate}={r.status.value}:{r.reason}" for r in assessment.release_blockers)
                        )
                    runner_digest = runner_attestation.digest() if runner_attestation else None
                    vulnerability_digest = vulnerability_attestation.digest() if vulnerability_attestation else None
                    assessment_hash = assessment_results_hash(assessment)
                    bound_inputs = {"assessment": assessment_hash}
                    if runner_digest:
                        bound_inputs["runner_attestation"] = runner_digest
                    if vulnerability_digest:
                        bound_inputs["vulnerability_attestation"] = vulnerability_digest
                    if len(bound_inputs) > 1:
                        material = json.dumps(bound_inputs, sort_keys=True, separators=(",", ":")).encode("utf-8")
                        import hashlib
                        assessment_hash = "sha256:" + hashlib.sha256(material).hexdigest()
                    if args.claim == "required_gates_passed":
                        ev = build_required_gates_evidence(
                            assessment, private_key_pem=private_key, context_hash=context_hash,
                            inputs_hash=assessment_hash, policy_digest=pdigest, ttl_seconds=ttl,
                        )
                    else:
                        release_result = next((r for r in assessment.gate_results if r.gate == "release"), None)
                        if release_result is None or release_result.status.value != "PASS":
                            raise AssessmentNotReleasable("release_verified requires explicit release gate PASS")
                        if not args.artifact or not args.provenance:
                            raise AssessmentNotReleasable("release_verified requires both --artifact and --provenance")
                        artifact_path = Path(args.artifact).resolve() if Path(args.artifact).is_absolute() else (root / args.artifact).resolve()
                        provenance_path = Path(args.provenance).resolve() if Path(args.provenance).is_absolute() else (root / args.provenance).resolve()
                        require_hermetic = trusted_project.require_hermetic_build or candidate_project.require_hermetic_build
                        prov = verify_artifact_provenance(
                            artifact=artifact_path, provenance_path=provenance_path, candidate=task.candidate,
                            repository=task.repository, policy_digest_value=pdigest, verification_keys=verification_keys,
                            require_hermetic=require_hermetic,
                            require_runner_attestation=trusted_project.trust.require_runner_attestation_for_certification,
                            runner_verification_keys=_load_public_key_map(base_snapshot, trusted_project.trust.runner_public_key_files),
                            candidate_root=candidate_snapshot,
                            accepted_control_plane_versions=set(trusted_project.trust.accepted_control_plane_versions) or None,
                        )
                        if args.artifact_digest:
                            expected = validate_artifact_digest(args.artifact_digest)
                            if expected != prov.artifact_digest:
                                raise AssessmentNotReleasable(f"artifact digest mismatch: expected={expected} actual={prov.artifact_digest}")
                        ev = build_release_verified_evidence(
                            repository=task.candidate.repository, sha=task.candidate.sha, tree=task.candidate.tree,
                            generation=task.candidate.generation, private_key_pem=private_key,
                            artifact_digest=prov.artifact_digest, context_hash=context_hash,
                            inputs_hash=assessment_hash, policy_digest=pdigest,
                            provenance_digest=provenance_digest(provenance_path), ttl_seconds=ttl,
                        )
                else:
                    gate_name = {"rollout_health_verified": "health", "recovery_verified": "recovery", "rollback_verified": "rollback"}[args.claim]
                    # Operational evidence uses candidate command definitions only after the
                    # candidate has already entered deployment/recovery states.
                    result = _run_measured_command_gate(candidate_snapshot, candidate_project, task, gate_name)
                    deployment_attestation = None
                    artifact_digest = None
                    if args.claim == "rollout_health_verified":
                        release_ev = require_evidence(
                            store, "release_verified", task.repository, task.candidate.sha,
                            generation=task.candidate.generation, subject_tree=task.candidate.tree,
                            verification_keys=verification_keys, require_asymmetric=True,
                            context_hash=context_hash, policy_digest=pdigest,
                            required_tags={"artifact", "provenance", "release"},
                            accepted_control_plane_versions=set(trusted_project.trust.accepted_control_plane_versions) or None,
                        )
                        if not release_ev.artifact_digest:
                            raise AssessmentNotReleasable("production health requires release evidence with artifact digest")
                        artifact_digest = release_ev.artifact_digest
                        deployment_attestation = _require_deployment_attestation(
                            base_snapshot, trusted_project, task.repository, task.candidate, artifact_digest=artifact_digest
                        )
                    tags = {
                        "rollout_health_verified": tuple(trusted_project.rollout.health_required_tags),
                        "recovery_verified": ("recovery", "candidate", "production"),
                        "rollback_verified": ("rollback", "candidate", "production"),
                    }[args.claim]
                    ev = build_operational_evidence(
                        claim=args.claim, repository=task.candidate.repository, sha=task.candidate.sha,
                        tree=task.candidate.tree, generation=task.candidate.generation, gate=gate_name,
                        gate_status=result.status.value, gate_reason=result.reason, private_key_pem=private_key,
                        context_hash=context_hash, policy_digest=pdigest, tags=tags, ttl_seconds=ttl,
                        external_evidence_digest=deployment_attestation.digest() if deployment_attestation else None,
                        artifact_digest=artifact_digest,
                    )

            if ev.signer_id not in verification_keys:
                raise AssessmentNotReleasable("evidence was signed by a key not trusted by the anchored base")
            final_base = resolve_commit(root, task.base_ref)
            if final_base != task.base_sha:
                raise AssessmentNotReleasable(f"base moved during certification: expected={task.base_sha} actual={final_base}")
            _assert_certification_remote_truth(root, trusted_project, task.base_ref, task.base_sha, require_for_release=(args.claim != "required_gates_passed"))
            current = journal.load(args.task)
            if current.version != stored.version or current.task.candidate != task.candidate:
                raise ConcurrencyConflict("task changed while certification was running")
            if anchor_path is not None and not verify_anchor_against_store(AuditAnchor.from_file(anchor_path), store, verification_keys):
                raise AuditAnchorError("audit anchor became stale during certification")
            _, event_id = store.record_evidence_and_event(
                args.task, ev, event_type="EVIDENCE_CERTIFIED",
                payload={
                    "claim": ev.claim, "subject_sha": ev.subject_sha, "generation": ev.generation,
                    "source": ev.source, "context_hash": ev.context_hash, "inputs_hash": ev.inputs_hash,
                    "artifact_digest": ev.artifact_digest, "policy_digest": ev.policy_digest,
                    "provenance_digest": ev.provenance_digest, "signer_id": ev.signer_id,
                    "control_plane_version": ev.control_plane_version, "governance_approval_id": governance_id,
                    "runner_attestation_digest": runner_attestation.digest() if runner_attestation else None,
                    "vulnerability_attestation_digest": vulnerability_attestation.digest() if vulnerability_attestation else None,
                }, generation=ev.generation, expected_last_id=stored.version,
            )
            if anchor_path is not None:
                refreshed = create_anchor(store, private_key)
                if not refreshed.verify(verification_keys):
                    raise AuditAnchorError("post-certification anchor signer is not trusted")
                refreshed.write(anchor_path)
    except (TaskNotFound, ConcurrencyConflict, AssessmentNotReleasable, EvidenceError, AuditAnchorError,
            AdapterManifestError, CommandGateConfigError, ProvenanceError, VulnerabilityAttestationError, DeploymentAttestationError, ValueError, TypeError,
            ImportError, AttributeError, FileNotFoundError, OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 3 if isinstance(exc, (AssessmentNotReleasable, AuditAnchorError, EvidenceError)) else 2
    print(json.dumps({
        "certified": True, "claim": ev.claim, "task_version": event_id,
        "subject_sha": ev.subject_sha, "signer_id": ev.signer_id,
        "policy_digest": ev.policy_digest, "provenance_digest": ev.provenance_digest,
    }, ensure_ascii=False, indent=2))
    return 0


def _journal(db: str) -> TaskJournal:
    return TaskJournal(EventStore(db))


def _project_for_root(root: Path, project_config: str | None = None) -> ProjectConfig | None:
    path = _root_relative(root, project_config) if project_config else (root / ".ados/project.json")
    return ProjectConfig.from_file(path) if path.exists() else None


def _assert_remote_base_truth(
    root: Path, project: ProjectConfig | None, base_ref: str, expected_sha: str, *, require_for_release: bool = False
) -> None:
    if project is None:
        if require_for_release:
            raise ValueError("release requires .ados/project.json with remote-base policy")
        return
    policy = project.remote_base
    if policy.mode == "disabled":
        if require_for_release:
            raise ValueError("release certification refuses remote_base.mode=disabled")
        return
    if not git_remote_exists(root, policy.remote):
        if policy.mode == "required" or require_for_release:
            raise ValueError(f"required Git remote {policy.remote!r} is not configured")
        return
    remote_ref = canonical_remote_ref(base_ref, policy.ref)
    remote_sha = resolve_remote_ref(root, policy.remote, remote_ref, timeout=policy.timeout_seconds)
    if remote_sha != expected_sha.lower():
        raise ValueError(
            f"remote base moved or local base is stale: {policy.remote}:{remote_ref} "
            f"expected={expected_sha.lower()} actual={remote_sha}"
        )
    derived = repository_identity_from_remote(root, policy.remote)
    if derived and project.repository_id and derived != project.repository_id:
        raise ValueError(f"repository identity mismatch: protected={project.repository_id!r} remote={derived!r}")
    remote_host = repository_host_from_remote(root, policy.remote)
    if remote_host is not None:
        if policy.host is None and require_for_release:
            raise ValueError(
                f"release requires protected remote_base.host pin for network remote {remote_host!r}"
            )
        if policy.host is not None and remote_host != policy.host:
            raise ValueError(f"remote host mismatch: protected={policy.host!r} actual={remote_host!r}")
    elif policy.host is not None:
        raise ValueError(f"protected remote_base.host={policy.host!r} but configured remote has no network host")
    elif require_for_release and not policy.allow_local_filesystem_for_release:
        raise ValueError(
            "release refuses an unpinned local/filesystem Git remote; use a network remote with protected remote_base.host "
            "or an explicitly trusted base policy test/offline exception"
        )


def cmd_task_create(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    try:
        base_ref = args.base_ref or current_branch(root)
        base_sha = resolve_commit(root, base_ref)
        project = _project_for_root(root)
        if project is not None:
            _assert_project_repository(root, project, args.repository, release=False)
            _assert_remote_base_truth(root, project, base_ref, base_sha)
    except (OSError, RuntimeError, ValueError, FileNotFoundError) as exc:
        print(json.dumps({"error": f"cannot anchor task base: {exc}"}, ensure_ascii=False, indent=2))
        return 2
    journal = _journal(str(_root_relative(root, args.db)))
    task = Task(
        task_id=args.task, repository=args.repository, goal=args.goal, base_sha=base_sha, base_ref=base_ref,
        metadata={"lane": DevelopmentLane.DEVELOPMENT.value},
    )
    try:
        stored = journal.create(task)
    except TaskAlreadyExists:
        print(json.dumps({"error": "task already exists", "task": args.task}, indent=2))
        return 2
    print(json.dumps({"version": stored.version, "task": stored.task.to_dict()}, ensure_ascii=False, indent=2))
    return 0


def cmd_task_show(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    journal = _journal(str(_root_relative(root, args.db)))
    try:
        stored = journal.load(args.task)
    except TaskNotFound:
        print(json.dumps({"error": "task not found", "task": args.task}, indent=2))
        return 2
    print(json.dumps({"version": stored.version, "task": stored.task.to_dict()}, ensure_ascii=False, indent=2))
    return 0


def cmd_task_candidate(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    journal = _journal(str(_root_relative(root, args.db)))
    try:
        current = journal.load(args.task)
        current_generation = current.task.candidate.generation if current.task.candidate else 0
        journal.store.require_lease(args.task, "WRITE", args.holder, current_generation)
        stored = journal.set_candidate(
            args.task,
            branch=args.branch,
            sha=args.sha,
            tree=args.tree,
            expected_version=args.expected_version,
        )
        new_generation = stored.task.candidate.generation if stored.task.candidate else 0
        journal.store.acquire_lease(args.task, "WRITE", args.holder, new_generation, args.lease_ttl)
    except (TaskNotFound, ConcurrencyConflict, LeaseConflict, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({"version": stored.version, "task": stored.task.to_dict()}, ensure_ascii=False, indent=2))
    return 0


def cmd_task_reanchor_base(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    journal = _journal(str(_root_relative(root, args.db)))
    try:
        current = journal.load(args.task)
        generation = current.task.candidate.generation if current.task.candidate else 0
        journal.store.require_lease(args.task, "WRITE", args.holder, generation)
        new_base = resolve_commit(root, args.base_ref)
        stored = journal.reanchor_base(
            args.task, base_ref=args.base_ref, base_sha=new_base, expected_version=args.expected_version
        )
        new_generation = stored.task.candidate.generation if stored.task.candidate else 0
        journal.store.acquire_lease(args.task, "WRITE", args.holder, new_generation, args.lease_ttl)
    except (TaskNotFound, ConcurrencyConflict, LeaseConflict, OSError, RuntimeError, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({"version": stored.version, "task": stored.task.to_dict()}, ensure_ascii=False, indent=2))
    return 0


def _trusted_task_policy(root: Path, task: Task) -> tuple[ProjectConfig, dict[str, bytes], str]:
    if task.candidate is None or task.base_sha is None:
        raise ValueError("trusted task policy requires exact candidate and base SHA")
    with detached_candidate_worktree(root, task.base_sha, materialize_submodules=True, materialize_lfs=True) as base_snapshot:
        trusted_project = ProjectConfig.from_file(base_snapshot / ".ados/project.json")
        keys = _load_public_key_map(base_snapshot, trusted_project.trust.evidence_public_key_files)
        with detached_candidate_worktree(root, task.candidate.sha, materialize_submodules=True, materialize_lfs=True) as candidate_snapshot:
            candidate_project = ProjectConfig.from_file(candidate_snapshot / ".ados/project.json")
            digest = certification_policy_digest(base_snapshot, candidate_snapshot, trusted_project, candidate_project)
    return trusted_project, keys, digest


def cmd_task_transition(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    journal = _journal(str(_root_relative(root, args.db)))
    store = journal.store
    target = TaskState(args.to)
    try:
        current = journal.load(args.task)
        task = current.task
        generation = task.candidate.generation if task.candidate else 0
        store.require_lease(args.task, "WRITE", args.holder, generation)
        guarded_targets = {TaskState.READY_TO_RELEASE, TaskState.RELEASING, TaskState.CANARY,
                           TaskState.PARTIALLY_DEPLOYED, TaskState.DONE, TaskState.ROLLED_BACK}
        if task.candidate is not None and task.base_sha is not None:
            trusted_project, keys, pdigest = _trusted_task_policy(root, task)
        else:
            project = _project_for_root(root, getattr(args, "project_config", None))
            if project is None:
                raise ValueError("lifecycle transitions require project config")
            trusted_project, keys, pdigest = project, {}, None
        _assert_project_repository(root, trusted_project, task.repository, release=target in guarded_targets)
        if task.candidate is not None:
            identity = verify_exact_candidate(root, task.candidate, require_clean=True)
            if identity.status.value != "PASS":
                raise ValueError(f"exact candidate identity recheck failed: {identity.reason}")
        guard = EvidenceTransitionGuard(
            store, verification_keys=keys,
            require_asymmetric=trusted_project.trust.require_asymmetric_release_signing,
            policy_digest=pdigest,
            accepted_control_plane_versions=frozenset(trusted_project.trust.accepted_control_plane_versions),
            health_required_tags=frozenset(trusted_project.rollout.health_required_tags),
        )
        if target in guarded_targets:
            if task.candidate is None or task.base_sha is None or task.base_ref is None:
                raise ValueError("guarded lifecycle transition requires exact candidate and trusted base")
            local_base = resolve_commit(root, task.base_ref)
            if local_base != task.base_sha:
                raise ValueError(f"base ref moved after certification: expected={task.base_sha} actual={local_base}")
            _assert_remote_base_truth(root, trusted_project, task.base_ref, task.base_sha, require_for_release=True)
        stored = journal.transition(args.task, target, expected_version=args.expected_version, guard=guard)
    except (TaskNotFound, ConcurrencyConflict, LeaseConflict, InvalidTransition, ValueError, OSError,
            RuntimeError, subprocess.TimeoutExpired, FileNotFoundError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2)); return 2
    print(json.dumps({"version": stored.version, "task": stored.task.to_dict()}, ensure_ascii=False, indent=2)); return 0


def cmd_lease_acquire(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    store = EventStore(_root_relative(root, args.db))
    journal = TaskJournal(store)
    try:
        stored = journal.load(args.task)
        generation = stored.task.candidate.generation if stored.task.candidate else 0
        lease = store.acquire_lease(args.task, args.scope, args.holder, generation, args.ttl)
    except (TaskNotFound, LeaseConflict, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps(lease.__dict__, ensure_ascii=False, indent=2))
    return 0


def cmd_lease_release(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    store = EventStore(_root_relative(root, args.db))
    try:
        store.release_lease(args.task, args.scope, args.holder)
    except LeaseConflict as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({"released": True, "task": args.task, "scope": args.scope}, indent=2))
    return 0


def cmd_journal_verify(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    store = EventStore(_root_relative(root, args.db))
    ok = store.verify_event_chain(args.task)
    print(json.dumps({"task": args.task, "event_chain_valid": ok}, indent=2))
    return 0 if ok else 2

def _control_store(args: argparse.Namespace) -> EventStore:
    root = Path(args.root).resolve()
    return EventStore(_root_relative(root, args.db))


def cmd_flag_show(args: argparse.Namespace) -> int:
    stored = PersistentFeatureFlagStore(_control_store(args)).get(args.name)
    print(json.dumps({
        "name": stored.flag.name, "stage": stored.flag.stage,
        "kill_switch": stored.flag.kill_switch, "version": stored.version,
    }, indent=2))
    return 0


def cmd_flag_advance(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve(); store = _control_store(args)
    flags = PersistentFeatureFlagStore(store); journal = TaskJournal(store)
    try:
        task = journal.load(args.task).task
        if task.candidate is None or task.base_sha is None:
            raise EvidenceError("rollout task has no exact candidate/trusted base")
        project, keys, pdigest = _trusted_task_policy(root, task)
        _assert_project_repository(root, project, task.repository, release=True)
        if not keys:
            raise EvidenceError("rollout requires base-trusted asymmetric evidence keys")
        stored = flags.advance(
            args.name, task=task, verification_keys=keys,
            require_asymmetric=project.trust.require_asymmetric_release_signing,
            required_claim=args.required_claim, health_claim=args.health_claim,
            health_required_tags=set(project.rollout.health_required_tags), policy_digest=pdigest,
            accepted_control_plane_versions=set(project.trust.accepted_control_plane_versions) or None,
            plan=default_rollout(project.profile, project.rollback_safe), profile=project.profile,
            expected_version=args.expected_version,
        )
    except (TaskNotFound, EvidenceError, ConcurrencyConflict, ValueError, OSError, RuntimeError) as exc:
        print(json.dumps({"error": str(exc)}, indent=2)); return 2
    print(json.dumps({"name": stored.flag.name, "stage": stored.flag.stage,
                      "kill_switch": stored.flag.kill_switch, "version": stored.version}, indent=2)); return 0


def cmd_flag_kill(args: argparse.Namespace) -> int:
    flags = PersistentFeatureFlagStore(_control_store(args))
    try:
        stored = flags.set_kill_switch(args.name, args.enabled, expected_version=args.expected_version)
    except ConcurrencyConflict as exc:
        print(json.dumps({"error": str(exc)}, indent=2))
        return 2
    print(json.dumps({
        "name": stored.flag.name, "stage": stored.flag.stage,
        "kill_switch": stored.flag.kill_switch, "version": stored.version,
    }, indent=2))
    return 0


def cmd_flake_record(args: argparse.Namespace) -> int:
    tracker = PersistentFlakeTracker(_control_store(args))
    tracker.record(args.test_id, args.passed)
    payload = {
        "test_id": args.test_id,
        "passed": args.passed,
        "flake_probability": tracker.flake_probability(args.test_id),
        "is_flaky": tracker.is_flaky(args.test_id, threshold=args.threshold),
    }
    print(json.dumps(payload, indent=2))
    return 0


def cmd_repair_record(args: argparse.Namespace) -> int:
    detector = PersistentFailureLoopDetector(
        _control_store(args),
        max_history=args.max_history,
        loop_threshold=args.loop_threshold,
        stop_threshold=args.stop_threshold,
    )
    try:
        decision = detector.add(args.task, args.signature)
    except ValueError as exc:
        print(json.dumps({"error": str(exc)}, indent=2))
        return 2
    print(json.dumps({"task": args.task, "signature": args.signature, "decision": decision}, indent=2))
    return 3 if decision == "AUTONOMY_STOPPED" else 0


def _scheduled_payload(item) -> dict:
    return {
        "task_id": item.task.task_id, "components": sorted(item.task.components),
        "dependencies": sorted(item.task.dependencies), "priority": item.task.priority,
        "execution_kind": item.task.execution_kind.value, "idempotency_key": item.task.idempotency_key,
        "status": item.status.value, "holder": item.holder,
        "lease_expires_at": item.lease_expires_at, "fencing_token": item.fencing_token,
        "attempts": item.attempts, "version": item.version,
    }


def _scheduler_for_args(args: argparse.Namespace) -> PersistentScheduler:
    root = Path(args.root).resolve()
    project = _project_for_root(root, getattr(args, "project_config", None))
    allowed = project.scheduler_resources if project and project.scheduler_resources else None
    return PersistentScheduler(_control_store(args), allowed_components=allowed)


def cmd_schedule_add(args: argparse.Namespace) -> int:
    scheduler = _scheduler_for_args(args)
    try:
        item = scheduler.add(ScheduledTask(
            args.task, set(args.component or ()), set(args.depends_on or ()), args.priority,
            ExecutionKind(args.execution_kind), args.idempotency_key,
        ))
    except (ValueError, ConcurrencyConflict) as exc:
        print(json.dumps({"error": str(exc)}, indent=2)); return 2
    print(json.dumps(_scheduled_payload(item), indent=2)); return 0


def cmd_schedule_list(args: argparse.Namespace) -> int:
    scheduler = _scheduler_for_args(args)
    print(json.dumps({"tasks": [_scheduled_payload(item) for item in scheduler.list()]}, indent=2)); return 0


def cmd_schedule_claim(args: argparse.Namespace) -> int:
    scheduler = _scheduler_for_args(args)
    try:
        items = scheduler.claim_ready(args.holder, limit=args.limit, ttl_seconds=args.ttl)
    except (ValueError, ConcurrencyConflict) as exc:
        print(json.dumps({"error": str(exc)}, indent=2)); return 2
    print(json.dumps({"claimed": [_scheduled_payload(item) for item in items]}, indent=2)); return 0


def cmd_schedule_authorize_effect(args: argparse.Namespace) -> int:
    scheduler = _scheduler_for_args(args)
    try:
        accepted = scheduler.authorize_effect(args.task, args.holder, fencing_token=args.fencing_token, event_id=args.event_id)
    except (KeyError, LeaseConflict, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, indent=2)); return 2
    print(json.dumps({
        "authorized": accepted, "task": args.task, "fencing_token": args.fencing_token,
        "event_id": args.event_id, "duplicate": not accepted,
    }, indent=2))
    return 0 if accepted else 3


def cmd_schedule_complete(args: argparse.Namespace) -> int:
    scheduler = _scheduler_for_args(args)
    try:
        item = scheduler.complete(args.task, args.holder, expected_version=args.expected_version, fencing_token=args.fencing_token)
    except (KeyError, LeaseConflict, ConcurrencyConflict) as exc:
        print(json.dumps({"error": str(exc)}, indent=2)); return 2
    print(json.dumps(_scheduled_payload(item), indent=2)); return 0


def cmd_schedule_abandon(args: argparse.Namespace) -> int:
    scheduler = _scheduler_for_args(args)
    try:
        item = scheduler.abandon(args.task, args.holder, expected_version=args.expected_version, fencing_token=args.fencing_token)
    except (KeyError, LeaseConflict, ConcurrencyConflict) as exc:
        print(json.dumps({"error": str(exc)}, indent=2)); return 2
    print(json.dumps(_scheduled_payload(item), indent=2)); return 0


def cmd_schedule_reconcile(args: argparse.Namespace) -> int:
    scheduler = _scheduler_for_args(args)
    try:
        item = scheduler.reconcile_orphan(args.task, outcome=args.outcome, expected_version=args.expected_version, external_state=args.external_state)
    except (KeyError, LeaseConflict, ConcurrencyConflict, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, indent=2)); return 2
    print(json.dumps(_scheduled_payload(item), indent=2)); return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    checks = run_doctor(Path(args.root))
    payload = {"checks": [c.to_dict() for c in checks], "failures": sum(c.status == "FAIL" for c in checks)}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["failures"] == 0 else 2


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="ados")
    sp = p.add_subparsers(dest="cmd", required=True)

    init = sp.add_parser("init")
    init.add_argument("--root", default=".")
    init.add_argument("--force", action="store_true", help="overwrite config only after creating timestamped backups")
    init.add_argument("--profile", choices=[p.value for p in ProductProfile], default=ProductProfile.BACKEND_SERVICE.value)
    init.add_argument("--repository-id", help="canonical repository identity, e.g. owner/repo; binds future assessments/certification")
    init.set_defaults(func=cmd_init)

    keygen = sp.add_parser("keygen")
    keygen.add_argument("--root", default=".")
    keygen.add_argument("--private-out", required=True, help="private key path outside the repository")
    keygen.add_argument("--public-out", required=True, help="public key path inside the repository")
    keygen.add_argument("--force", action="store_true")
    keygen.set_defaults(func=cmd_keygen)

    runner_attest = sp.add_parser("runner-attest")
    runner_attest.add_argument("--repository", required=True)
    runner_attest.add_argument("--sha", required=True)
    runner_attest.add_argument("--branch", default="attested")
    runner_attest.add_argument("--tree", required=True)
    runner_attest.add_argument("--generation", required=True, type=int)
    runner_attest.add_argument("--runner-id", required=True)
    runner_attest.add_argument("--nonce", required=True)
    runner_attest.add_argument("--ttl", type=int, default=1800)
    runner_attest.add_argument("--network-policy", choices=["denied", "allowlisted", "denied_or_allowlisted"], default="denied_or_allowlisted")
    runner_attest.add_argument("--output", required=True)
    runner_attest.add_argument("--private-key-env", default="ADOS_RUNNER_PRIVATE_KEY")
    runner_attest.set_defaults(func=cmd_runner_attest)

    vuln_attest = sp.add_parser("vulnerability-attest")
    vuln_attest.add_argument("--root", default=".")
    vuln_attest.add_argument("--repository", required=True)
    vuln_attest.add_argument("--sha", required=True)
    vuln_attest.add_argument("--branch", default="attested")
    vuln_attest.add_argument("--tree", required=True)
    vuln_attest.add_argument("--generation", required=True, type=int)
    vuln_attest.add_argument("--scanner-id", required=True)
    vuln_attest.add_argument("--scanner-version", required=True)
    vuln_attest.add_argument("--advisory-source", required=True)
    vuln_attest.add_argument("--advisory-snapshot", required=True, help="sha256 digest of the vulnerability database snapshot")
    vuln_attest.add_argument("--report-digest", required=True, help="sha256 digest of the scanner's full machine-readable report")
    vuln_attest.add_argument("--findings-count", required=True, type=int)
    vuln_attest.add_argument("--max-severity", required=True, choices=["NONE","LOW","MEDIUM","HIGH","CRITICAL"])
    vuln_attest.add_argument("--ttl", type=int, default=3600)
    vuln_attest.add_argument("--output", required=True)
    vuln_attest.add_argument("--private-key-env", default="ADOS_VULNERABILITY_PRIVATE_KEY")
    vuln_attest.set_defaults(func=cmd_vulnerability_attest)

    deploy_attest = sp.add_parser("deployment-attest")
    deploy_attest.add_argument("--root", default=".")
    deploy_attest.add_argument("--repository", required=True)
    deploy_attest.add_argument("--sha", required=True)
    deploy_attest.add_argument("--branch", default="attested")
    deploy_attest.add_argument("--tree", required=True)
    deploy_attest.add_argument("--generation", required=True, type=int)
    deploy_attest.add_argument("--artifact", required=True)
    deploy_attest.add_argument("--deployment-id", required=True)
    deploy_attest.add_argument("--environment", default="production")
    deploy_attest.add_argument("--target", required=True)
    deploy_attest.add_argument("--status", required=True, choices=["HEALTHY","DEGRADED","ROLLED_BACK"])
    deploy_attest.add_argument("--probe-id", required=True)
    deploy_attest.add_argument("--probe-version", required=True)
    deploy_attest.add_argument("--measurements-hash", required=True)
    deploy_attest.add_argument("--ttl", type=int, default=1800)
    deploy_attest.add_argument("--output", required=True)
    deploy_attest.add_argument("--private-key-env", default="ADOS_DEPLOYMENT_PRIVATE_KEY")
    deploy_attest.set_defaults(func=cmd_deployment_attest)

    build_artifact = sp.add_parser("build-artifact")
    build_artifact.add_argument("--root", default=".")
    build_artifact.add_argument("--db", default=".ados/control-plane.db")
    build_artifact.add_argument("--project-config")
    build_artifact.add_argument("--task", required=True)
    build_artifact.add_argument("--output", required=True, help="artifact destination outside live repository")
    build_artifact.add_argument("--private-key-env", default="ADOS_EVIDENCE_PRIVATE_KEY")
    build_artifact.add_argument("--governance-exception", help="two-person signed TCB approval when build policy changed")
    build_artifact.set_defaults(func=cmd_build_artifact)

    audit_anchor = sp.add_parser("audit-anchor")
    audit_anchor.add_argument("--root", default=".")
    audit_anchor.add_argument("--db", default=".ados/control-plane.db")
    audit_anchor.add_argument("--project-config")
    audit_anchor.add_argument("--output")
    audit_anchor.add_argument("--private-key-env", default="ADOS_EVIDENCE_PRIVATE_KEY")
    audit_anchor.add_argument("--verify", action="store_true")
    audit_anchor.set_defaults(func=cmd_audit_anchor)

    doctor = sp.add_parser("doctor")
    doctor.add_argument("--root", default=".")
    doctor.set_defaults(func=cmd_doctor)

    exc_create = sp.add_parser("exception-create")
    exc_create.add_argument("--exception-id", required=True)
    exc_create.add_argument("--rule-id", required=True)
    exc_create.add_argument("--scope", required=True)
    exc_create.add_argument("--reason", required=True)
    exc_create.add_argument("--expires-at", required=True)
    exc_create.add_argument("--approver", action="append", required=True, help="Ed25519 public-key fingerprint; repeat for independent approvers")
    exc_create.add_argument("--irreversible", action=argparse.BooleanOptionalAction, default=True)
    exc_create.add_argument("--output", required=True)
    exc_create.set_defaults(func=cmd_exception_create)

    exc_sign = sp.add_parser("exception-sign")
    exc_sign.add_argument("--exception", required=True)
    exc_sign.add_argument("--approver-id")
    exc_sign.add_argument("--private-key-env", default="ADOS_BREAK_GLASS_PRIVATE_KEY")
    exc_sign.add_argument("--output")
    exc_sign.set_defaults(func=cmd_exception_sign)

    check = sp.add_parser("check-action")
    check.add_argument("--root", default=".")
    check.add_argument("--project-config")
    check.add_argument("--constitution", default=".ados/constitution.json")
    check.add_argument("--action", required=True)
    check.add_argument("--role", default="builder")
    check.add_argument("--environment", default="dev")
    check.add_argument("--branch")
    check.add_argument("--command")
    check.add_argument("--capability", help="typed capability identifier; preferred over raw production shell")
    check.add_argument("--file", action="append")
    check.add_argument("--deleted-files", type=int, default=0)
    check.add_argument("--deleted-lines", type=int, default=0)
    check.add_argument("--total-changed-lines", type=int, default=0)
    check.add_argument("--exception", help="signed controlled-exception JSON")
    check.add_argument("--break-glass-secret-env", default="ADOS_BREAK_GLASS_HMAC_KEY")
    check.set_defaults(func=cmd_check_action)

    assess = sp.add_parser("assess")
    assess.add_argument("--root", default=".")
    assess.add_argument("--impact", default=".ados/impact.json")
    assess.add_argument("--project-config", help="project profile/config; defaults to .ados/project.json when present")
    assess.add_argument("--task", required=True)
    assess.add_argument("--repository", required=True)
    assess.add_argument("--goal", required=True)
    assess.add_argument("--lane", choices=[x.value for x in DevelopmentLane], default=DevelopmentLane.DEVELOPMENT.value)
    assess.add_argument("--file", action="append", default=[])
    assess.add_argument("--deleted-file", action="append", default=[])
    assess.add_argument("--allow-unknown", action="store_true", help="exploration only; release automation should never set this")
    assess.add_argument("--adapter-manifest", help="protected adapter manifest; defaults to .ados/adapters.json when present")
    assess.add_argument("--adapter", action="append", default=[], metavar="GATE=MODULE:ATTRIBUTE", help="UNSAFE exploration override; prefer protected adapter manifest")
    assess.add_argument("--unsafe-adapter-override", action="store_true", help="allow direct module adapter loading for local exploration only")
    assess.set_defaults(func=cmd_assess)

    certify = sp.add_parser("certify")
    certify.add_argument("--root", default=".")
    certify.add_argument("--db", default=".ados/control-plane.db")
    certify.add_argument("--impact", default=".ados/impact.json")
    certify.add_argument("--project-config")
    certify.add_argument("--task", required=True)
    certify.add_argument("--expected-version", required=True, type=int)
    certify.add_argument("--claim", choices=[
        "required_gates_passed", "release_verified", "rollout_health_verified",
        "recovery_verified", "rollback_verified",
    ], default="required_gates_passed")
    certify.add_argument("--file", action="append", default=[], help=argparse.SUPPRESS)
    certify.add_argument("--deleted-file", action="append", default=[], help=argparse.SUPPRESS)
    certify.add_argument("--adapter-manifest")
    certify.add_argument("--private-key-env", default="ADOS_EVIDENCE_PRIVATE_KEY")
    certify.add_argument("--ttl", type=int, default=None, help="optional TTL no greater than protected project policy")
    certify.add_argument("--artifact", help="release artifact built by ados build-artifact")
    certify.add_argument("--provenance", help="signed provenance emitted by ados build-artifact")
    certify.add_argument("--artifact-digest", help="optional expected sha256:<hex>; must match signed provenance and real artifact")
    certify.add_argument("--governance-exception", help="two-person signed TCB approval for protected policy/CI changes")
    certify.set_defaults(func=cmd_certify)

    task_create = sp.add_parser("task-create")
    task_create.add_argument("--root", default=".")
    task_create.add_argument("--base-ref", help="trusted Git ref; defaults to the current symbolic branch (detached HEAD requires explicit ref)")
    task_create.add_argument("--db", default=".ados/control-plane.db")
    task_create.add_argument("--task", required=True)
    task_create.add_argument("--repository", required=True)
    task_create.add_argument("--goal", required=True)
    task_create.set_defaults(func=cmd_task_create)

    task_show = sp.add_parser("task-show")
    task_show.add_argument("--root", default=".")
    task_show.add_argument("--db", default=".ados/control-plane.db")
    task_show.add_argument("--task", required=True)
    task_show.set_defaults(func=cmd_task_show)

    task_candidate = sp.add_parser("task-candidate")
    task_candidate.add_argument("--root", default=".")
    task_candidate.add_argument("--db", default=".ados/control-plane.db")
    task_candidate.add_argument("--task", required=True)
    task_candidate.add_argument("--branch", required=True)
    task_candidate.add_argument("--sha", required=True)
    task_candidate.add_argument("--tree")
    task_candidate.add_argument("--expected-version", required=True, type=int)
    task_candidate.add_argument("--holder", required=True)
    task_candidate.add_argument("--lease-ttl", type=int, default=900)
    task_candidate.set_defaults(func=cmd_task_candidate)

    task_reanchor = sp.add_parser("task-reanchor-base")
    task_reanchor.add_argument("--root", default=".")
    task_reanchor.add_argument("--db", default=".ados/control-plane.db")
    task_reanchor.add_argument("--task", required=True)
    task_reanchor.add_argument("--base-ref", required=True)
    task_reanchor.add_argument("--expected-version", required=True, type=int)
    task_reanchor.add_argument("--holder", required=True)
    task_reanchor.add_argument("--lease-ttl", type=int, default=900)
    task_reanchor.set_defaults(func=cmd_task_reanchor_base)

    task_transition = sp.add_parser("task-transition")
    task_transition.add_argument("--root", default=".")
    task_transition.add_argument("--db", default=".ados/control-plane.db")
    task_transition.add_argument("--task", required=True)
    task_transition.add_argument("--to", required=True, choices=[s.value for s in TaskState])
    task_transition.add_argument("--expected-version", required=True, type=int)
    task_transition.add_argument("--holder", required=True)
    task_transition.add_argument("--project-config")
    task_transition.set_defaults(func=cmd_task_transition)

    lease_acquire = sp.add_parser("lease-acquire")
    lease_acquire.add_argument("--root", default=".")
    lease_acquire.add_argument("--db", default=".ados/control-plane.db")
    lease_acquire.add_argument("--task", required=True)
    lease_acquire.add_argument("--scope", default="WRITE")
    lease_acquire.add_argument("--holder", required=True)
    lease_acquire.add_argument("--ttl", type=int, default=900)
    lease_acquire.set_defaults(func=cmd_lease_acquire)

    lease_release = sp.add_parser("lease-release")
    lease_release.add_argument("--root", default=".")
    lease_release.add_argument("--db", default=".ados/control-plane.db")
    lease_release.add_argument("--task", required=True)
    lease_release.add_argument("--scope", default="WRITE")
    lease_release.add_argument("--holder", required=True)
    lease_release.set_defaults(func=cmd_lease_release)

    journal_verify = sp.add_parser("journal-verify")
    journal_verify.add_argument("--root", default=".")
    journal_verify.add_argument("--db", default=".ados/control-plane.db")
    journal_verify.add_argument("--task", required=True)
    journal_verify.set_defaults(func=cmd_journal_verify)

    flag_show = sp.add_parser("flag-show")
    flag_show.add_argument("--root", default=".")
    flag_show.add_argument("--db", default=".ados/control-plane.db")
    flag_show.add_argument("--name", required=True)
    flag_show.set_defaults(func=cmd_flag_show)

    flag_advance = sp.add_parser("flag-advance")
    flag_advance.add_argument("--root", default=".")
    flag_advance.add_argument("--db", default=".ados/control-plane.db")
    flag_advance.add_argument("--name", required=True)
    flag_advance.add_argument("--expected-version", required=True, type=int)
    flag_advance.add_argument("--task", required=True, help="task whose exact candidate is being rolled out")
    flag_advance.add_argument("--required-claim", default="release_verified")
    flag_advance.add_argument("--health-claim", default="rollout_health_verified")
    flag_advance.add_argument("--project-config")
    flag_advance.set_defaults(func=cmd_flag_advance)

    flag_kill = sp.add_parser("flag-kill")
    flag_kill.add_argument("--root", default=".")
    flag_kill.add_argument("--db", default=".ados/control-plane.db")
    flag_kill.add_argument("--name", required=True)
    flag_kill.add_argument("--expected-version", required=True, type=int)
    flag_kill.add_argument("--enabled", action=argparse.BooleanOptionalAction, default=True)
    flag_kill.set_defaults(func=cmd_flag_kill)

    flake_record = sp.add_parser("flake-record")
    flake_record.add_argument("--root", default=".")
    flake_record.add_argument("--db", default=".ados/control-plane.db")
    flake_record.add_argument("--test-id", required=True)
    flake_record.add_argument("--passed", action=argparse.BooleanOptionalAction, required=True)
    flake_record.add_argument("--threshold", type=float, default=0.25)
    flake_record.set_defaults(func=cmd_flake_record)

    repair_record = sp.add_parser("repair-record")
    repair_record.add_argument("--root", default=".")
    repair_record.add_argument("--db", default=".ados/control-plane.db")
    repair_record.add_argument("--task", required=True)
    repair_record.add_argument("--signature", required=True)
    repair_record.add_argument("--max-history", type=int, default=20)
    repair_record.add_argument("--loop-threshold", type=int, default=3)
    repair_record.add_argument("--stop-threshold", type=int, default=5)
    repair_record.set_defaults(func=cmd_repair_record)

    schedule_add = sp.add_parser("schedule-add")
    schedule_add.add_argument("--root", default=".")
    schedule_add.add_argument("--db", default=".ados/control-plane.db")
    schedule_add.add_argument("--task", required=True)
    schedule_add.add_argument("--component", action="append", default=[])
    schedule_add.add_argument("--depends-on", action="append", default=[])
    schedule_add.add_argument("--priority", type=int, default=0)
    schedule_add.add_argument("--execution-kind", choices=[x.value for x in ExecutionKind], default=ExecutionKind.READ_ONLY.value)
    schedule_add.add_argument("--idempotency-key")
    schedule_add.add_argument("--project-config")
    schedule_add.set_defaults(func=cmd_schedule_add)

    schedule_list = sp.add_parser("schedule-list")
    schedule_list.add_argument("--root", default=".")
    schedule_list.add_argument("--db", default=".ados/control-plane.db")
    schedule_list.add_argument("--project-config")
    schedule_list.set_defaults(func=cmd_schedule_list)

    schedule_claim = sp.add_parser("schedule-claim")
    schedule_claim.add_argument("--root", default=".")
    schedule_claim.add_argument("--db", default=".ados/control-plane.db")
    schedule_claim.add_argument("--holder", required=True)
    schedule_claim.add_argument("--limit", type=int, default=1)
    schedule_claim.add_argument("--ttl", type=int, default=900)
    schedule_claim.add_argument("--project-config")
    schedule_claim.set_defaults(func=cmd_schedule_claim)

    schedule_complete = sp.add_parser("schedule-complete")
    schedule_complete.add_argument("--root", default=".")
    schedule_complete.add_argument("--db", default=".ados/control-plane.db")
    schedule_complete.add_argument("--task", required=True)
    schedule_complete.add_argument("--holder", required=True)
    schedule_complete.add_argument("--expected-version", required=True, type=int)
    schedule_complete.add_argument("--fencing-token", required=True, type=int)
    schedule_complete.add_argument("--project-config")
    schedule_complete.set_defaults(func=cmd_schedule_complete)

    schedule_abandon = sp.add_parser("schedule-abandon")
    schedule_abandon.add_argument("--root", default=".")
    schedule_abandon.add_argument("--db", default=".ados/control-plane.db")
    schedule_abandon.add_argument("--task", required=True)
    schedule_abandon.add_argument("--holder", required=True)
    schedule_abandon.add_argument("--expected-version", required=True, type=int)
    schedule_abandon.add_argument("--fencing-token", required=True, type=int)
    schedule_abandon.add_argument("--project-config")
    schedule_abandon.set_defaults(func=cmd_schedule_abandon)

    schedule_effect = sp.add_parser("schedule-authorize-effect")
    schedule_effect.add_argument("--root", default=".")
    schedule_effect.add_argument("--db", default=".ados/control-plane.db")
    schedule_effect.add_argument("--task", required=True)
    schedule_effect.add_argument("--holder", required=True)
    schedule_effect.add_argument("--fencing-token", required=True, type=int)
    schedule_effect.add_argument("--event-id", required=True)
    schedule_effect.add_argument("--project-config")
    schedule_effect.set_defaults(func=cmd_schedule_authorize_effect)

    schedule_reconcile = sp.add_parser("schedule-reconcile")
    schedule_reconcile.add_argument("--root", default=".")
    schedule_reconcile.add_argument("--db", default=".ados/control-plane.db")
    schedule_reconcile.add_argument("--task", required=True)
    schedule_reconcile.add_argument("--outcome", choices=["retry", "done"], required=True)
    schedule_reconcile.add_argument("--external-state", required=True)
    schedule_reconcile.add_argument("--expected-version", required=True, type=int)
    schedule_reconcile.add_argument("--project-config")
    schedule_reconcile.set_defaults(func=cmd_schedule_reconcile)
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
