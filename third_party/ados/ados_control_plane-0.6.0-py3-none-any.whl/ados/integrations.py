from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from .models import GateResult, GateStatus


class ConnectionState(str, Enum):
    NOT_CONFIGURED = "NOT_CONFIGURED"
    AUTHORIZING = "AUTHORIZING"
    CONNECTED = "CONNECTED"
    VERIFYING = "VERIFYING"
    READY = "READY"
    TOKEN_EXPIRED = "TOKEN_EXPIRED"
    PERMISSION_REVOKED = "PERMISSION_REVOKED"
    WEBHOOK_BROKEN = "WEBHOOK_BROKEN"
    RATE_LIMITED = "RATE_LIMITED"
    PARTIAL = "PARTIAL"
    PROVIDER_DOWN = "PROVIDER_DOWN"
    REAUTH_REQUIRED = "REAUTH_REQUIRED"
    MISCONFIGURED = "MISCONFIGURED"


@dataclass(frozen=True)
class ProviderContract:
    provider: str
    allowed_auth_types: frozenset[str]
    require_identity_verification: bool = True
    require_reconciliation_for_webhook: bool = True
    require_idempotency_for_webhook: bool = True
    require_replay_protection_for_webhook: bool = True
    require_dlq_for_webhook: bool = True
    require_webhook_signature: bool = False
    require_rate_limit_backoff: bool = True
    require_persistent_cursor_for_sync: bool = True
    require_pagination_for_sync: bool = True
    require_serialized_token_refresh_for_oauth: bool = True
    capabilities_by_auth_type: dict[str, frozenset[str]] = field(default_factory=dict)


@dataclass
class ProviderConnection:
    provider: str
    auth_type: str
    state: ConnectionState
    capabilities: set[str] = field(default_factory=set)
    required_capabilities: set[str] = field(default_factory=set)
    identity_verified: bool = False
    expected_account_id: str | None = None
    verified_account_id: str | None = None
    read_probe_ok: bool = False
    write_probe_ok: bool | None = None
    webhook_verified: bool | None = None
    reconciliation_enabled: bool = False
    idempotency_supported: bool = False
    replay_protection_enabled: bool = False
    dlq_configured: bool = False
    signature_verified: bool | None = None
    rate_limit_backoff_enabled: bool = False
    cursor_persisted: bool = False
    pagination_supported: bool = False
    token_refresh_serialized: bool = False
    ordering_strategy: str | None = None


def operational_readiness(conn: ProviderConnection, contract: ProviderContract | None = None) -> GateResult:
    if contract is not None:
        if contract.provider != conn.provider:
            return GateResult("integration", GateStatus.FAIL, f"provider mismatch: contract={contract.provider} connection={conn.provider}")
        if conn.auth_type not in contract.allowed_auth_types:
            return GateResult("integration", GateStatus.FAIL, f"unsupported auth_type={conn.auth_type!r}")
        auth_caps = contract.capabilities_by_auth_type.get(conn.auth_type)
        if auth_caps is not None:
            impossible = conn.required_capabilities - set(auth_caps)
            if impossible:
                return GateResult("integration", GateStatus.FAIL, f"auth_type={conn.auth_type!r} cannot provide required capabilities: {sorted(impossible)}")

    missing = conn.required_capabilities - conn.capabilities
    if missing:
        return GateResult("integration", GateStatus.FAIL, f"missing provider capabilities: {sorted(missing)}")
    if conn.state is not ConnectionState.READY:
        return GateResult("integration", GateStatus.FAIL, f"connection not READY: state={conn.state.value}")
    if (contract is None or contract.require_identity_verification) and not conn.identity_verified:
        return GateResult("integration", GateStatus.FAIL, "provider identity/account not verified")
    if conn.expected_account_id is not None and conn.verified_account_id != conn.expected_account_id:
        return GateResult("integration", GateStatus.FAIL, "connected provider account does not match expected account")
    if not conn.read_probe_ok:
        return GateResult("integration", GateStatus.FAIL, "read probe failed")
    if "write" in conn.required_capabilities and conn.write_probe_ok is not True:
        return GateResult("integration", GateStatus.FAIL, "safe write probe not verified")
    if "webhook" in conn.required_capabilities and conn.webhook_verified is not True:
        return GateResult("integration", GateStatus.FAIL, "webhook not verified")

    has_webhook = "webhook" in conn.capabilities or "webhook" in conn.required_capabilities
    if has_webhook and (contract is None or contract.require_reconciliation_for_webhook) and not conn.reconciliation_enabled:
        return GateResult("integration", GateStatus.FAIL, "webhook integration requires reconciliation path")
    if has_webhook and (contract is None or contract.require_idempotency_for_webhook) and not conn.idempotency_supported:
        return GateResult("integration", GateStatus.FAIL, "webhook integration requires idempotency")
    if has_webhook and (contract is None or contract.require_replay_protection_for_webhook) and not conn.replay_protection_enabled:
        return GateResult("integration", GateStatus.FAIL, "webhook integration requires replay protection")
    if has_webhook and (contract is None or contract.require_dlq_for_webhook) and not conn.dlq_configured:
        return GateResult("integration", GateStatus.FAIL, "webhook integration requires dead-letter handling")
    if has_webhook and contract is not None and contract.require_webhook_signature and conn.signature_verified is not True:
        return GateResult("integration", GateStatus.FAIL, "webhook signature verification not proven")

    if contract is None or contract.require_rate_limit_backoff:
        if not conn.rate_limit_backoff_enabled:
            return GateResult("integration", GateStatus.FAIL, "rate-limit/backoff behavior not verified")

    is_sync = "sync" in conn.capabilities or "sync" in conn.required_capabilities
    if is_sync and (contract is None or contract.require_persistent_cursor_for_sync) and not conn.cursor_persisted:
        return GateResult("integration", GateStatus.FAIL, "sync integration requires persistent reconciliation cursor")
    if is_sync and (contract is None or contract.require_pagination_for_sync) and not conn.pagination_supported:
        return GateResult("integration", GateStatus.FAIL, "sync integration requires pagination coverage")

    if conn.auth_type.lower() in {"oauth", "oauth2", "authorization_code"}:
        if contract is None or contract.require_serialized_token_refresh_for_oauth:
            if not conn.token_refresh_serialized:
                return GateResult("integration", GateStatus.FAIL, "OAuth token refresh race protection not verified")

    if has_webhook and conn.ordering_strategy not in {"provider_sequence", "timestamp_buffer", "commutative", "not_required"}:
        return GateResult("integration", GateStatus.FAIL, "event ordering strategy not declared")

    return GateResult("integration", GateStatus.PASS, "provider operationally usable")
