from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import __version__
from .crypto import sign_ed25519, verify_ed25519
from .models import Candidate
from .runner_attestation import RunnerAttestation, RunnerAttestationError, verify_runner_attestation
from .util import sha256_regular_file


class ProvenanceError(ValueError):
    pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _inside(root: Path, path: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _file_digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _canonical(data: dict[str, Any]) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


@dataclass(frozen=True)
class BuildSpec:
    argv: tuple[str, ...]
    artifact_glob: str
    cwd: str = "."
    timeout_seconds: float = 3600.0
    max_output_bytes: int = 64 * 1024 * 1024
    env: tuple[tuple[str, str], ...] = ()
    container_image_digest: str | None = None
    sbom_path: str = ".ados/sbom.json"
    toolchain_commands: tuple[tuple[str, tuple[str, ...]], ...] = ()
    trusted_files: tuple[tuple[str, str], ...] = ()

    @classmethod
    def from_file(cls, path: str | Path) -> "BuildSpec":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ProvenanceError("build manifest must be a JSON object")
        argv = raw.get("argv")
        if not isinstance(argv, list) or not argv or not all(isinstance(x, str) and x for x in argv):
            raise ProvenanceError("build manifest requires non-empty argv list")
        artifact_glob = raw.get("artifact_glob")
        if not isinstance(artifact_glob, str) or not artifact_glob or Path(artifact_glob).is_absolute() or ".." in Path(artifact_glob).parts:
            raise ProvenanceError("build manifest artifact_glob must be a repository-relative glob")
        cwd = raw.get("cwd", ".")
        if not isinstance(cwd, str) or Path(cwd).is_absolute() or ".." in Path(cwd).parts:
            raise ProvenanceError("build manifest cwd must stay inside repository")
        timeout = float(raw.get("timeout_seconds", 3600.0))
        if timeout <= 0 or timeout > 21_600:
            raise ProvenanceError("build timeout_seconds must be >0 and <=21600")
        max_output = int(raw.get("max_output_bytes", 64 * 1024 * 1024))
        if max_output < 1024 or max_output > 1024 * 1024 * 1024:
            raise ProvenanceError("build max_output_bytes must be between 1KiB and 1GiB")
        env = raw.get("env", {})
        if not isinstance(env, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in env.items()):
            raise ProvenanceError("build env must be a string map")
        sensitive = ("SECRET", "TOKEN", "PASSWORD", "PRIVATE_KEY", "CREDENTIAL")
        if any(any(fragment in k.upper() for fragment in sensitive) for k in env):
            raise ProvenanceError("build manifest may not embed credentials/secrets")
        tools = raw.get("toolchain_commands", {})
        if not isinstance(tools, dict):
            raise ProvenanceError("toolchain_commands must be an object")
        parsed_tools: list[tuple[str, tuple[str, ...]]] = []
        for name, command in tools.items():
            if not isinstance(name, str) or not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
                raise ProvenanceError("toolchain command entries must be name -> argv[]")
            parsed_tools.append((name, tuple(command)))
        trusted_files = raw.get("trusted_files", [])
        if not isinstance(trusted_files, list) or not all(isinstance(x, str) and x for x in trusted_files):
            raise ProvenanceError("build trusted_files must be a string list")
        parsed_trusted: list[tuple[str, str]] = []
        manifest_root = Path(path).resolve().parents[1]
        for rel_name in trusted_files:
            rel_path = Path(rel_name)
            if rel_path.is_absolute() or ".." in rel_path.parts:
                raise ProvenanceError(f"build trusted file escapes repository: {rel_name!r}")
            target = (manifest_root / rel_path).resolve(strict=False)
            if not _inside(manifest_root, target) or not target.exists() or not target.is_file() or target.is_symlink():
                raise ProvenanceError(f"build trusted file is missing/invalid: {rel_name!r}")
            parsed_trusted.append((rel_path.as_posix(), _file_digest(target)))
        image = raw.get("container_image_digest")
        if image is not None and (not isinstance(image, str) or not image.startswith("sha256:") or len(image) != 71):
            raise ProvenanceError("container_image_digest must be canonical sha256:<64hex>")
        return cls(
            argv=tuple(argv), artifact_glob=artifact_glob, cwd=cwd, timeout_seconds=timeout,
            max_output_bytes=max_output, env=tuple(sorted(env.items())), container_image_digest=image,
            sbom_path=str(raw.get("sbom_path", ".ados/sbom.json")),
            toolchain_commands=tuple(sorted(parsed_tools)),
            trusted_files=tuple(sorted(parsed_trusted)),
        )


@dataclass(frozen=True)
class BuildProvenance:
    schema_version: int
    repository: str
    subject_sha: str
    subject_tree: str
    generation: int
    control_plane_version: str
    policy_digest: str
    builder_id: str
    build_argv: tuple[str, ...]
    build_cwd: str
    artifact_name: str
    artifact_digest: str
    artifact_size: int
    sbom_digest: str | None
    lockfile_digests: tuple[tuple[str, str], ...]
    toolchain: tuple[tuple[str, str], ...]
    isolation: str
    hermetic: bool
    container_image_digest: str | None
    started_at: str
    finished_at: str
    runner_attestation_digest: str | None = None
    runner_attestation: dict[str, Any] | None = None
    signature_algorithm: str = "ed25519"
    signer_id: str | None = None
    signature: str | None = None

    def unsigned_payload(self) -> bytes:
        data = asdict(self)
        data.pop("signature", None)
        return _canonical(data)

    def signed(self, private_key_pem: bytes) -> "BuildProvenance":
        prepared = replace(self, signature=None, signature_algorithm="ed25519")
        _, signer_id = sign_ed25519(b"ados-provenance-key-identification", private_key_pem)
        prepared = replace(prepared, signer_id=signer_id)
        sig, actual = sign_ed25519(prepared.unsigned_payload(), private_key_pem)
        if actual != signer_id:
            raise ProvenanceError("provenance signer identity changed")
        return replace(prepared, signature=sig)

    def verify(self, verification_keys: dict[str, bytes]) -> bool:
        if self.signature_algorithm != "ed25519" or not self.signature or not self.signer_id:
            return False
        key = verification_keys.get(self.signer_id)
        return bool(key and verify_ed25519(self.unsigned_payload(), self.signature, key))

    def to_file(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), sort_keys=True, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    @classmethod
    def from_file(cls, path: str | Path) -> "BuildProvenance":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        for field in ("build_argv", "lockfile_digests", "toolchain"):
            if field in raw:
                if field == "build_argv": raw[field] = tuple(raw[field])
                else: raw[field] = tuple(tuple(x) for x in raw[field])
        return cls(**raw)


def provenance_digest(path: Path) -> str:
    return _file_digest(path)


def _expand(argv: tuple[str, ...]) -> list[str]:
    return [sys.executable if item == "{python}" else item for item in argv]


def _toolchain_versions(root: Path, spec: BuildSpec) -> tuple[tuple[str, str], ...]:
    observed: dict[str, str] = {
        "python": platform.python_version(),
        "platform": platform.platform(),
    }
    for name, argv in spec.toolchain_commands:
        try:
            proc = subprocess.run(_expand(argv), cwd=root, env=_safe_env(()), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30, check=False)
            text = (proc.stdout or "").strip().splitlines()
            observed[name] = text[0][:500] if text else f"exit={proc.returncode}"
        except Exception as exc:
            observed[name] = f"unavailable:{type(exc).__name__}"
    return tuple(sorted(observed.items()))


def _lockfiles(root: Path) -> tuple[tuple[str, str], ...]:
    names = ("requirements.lock", "uv.lock", "poetry.lock", "Pipfile.lock", "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "Cargo.lock")
    result = []
    for name in names:
        path = root / name
        if path.exists() and path.is_file() and not path.is_symlink():
            result.append((name, _file_digest(path)))
    return tuple(sorted(result))


def _safe_env(extra: tuple[tuple[str, str], ...], *, isolated_home: str | None = None) -> dict[str, str]:
    allow = {"PATH", "TMPDIR", "TEMP", "TMP", "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "LANG", "LC_ALL", "LC_CTYPE", "TERM"}
    env = {k: v for k, v in os.environ.items() if k.upper() in allow}
    if isolated_home is not None:
        env["HOME"] = isolated_home
        env["USERPROFILE"] = isolated_home
        env["XDG_CONFIG_HOME"] = str(Path(isolated_home) / ".config")
        env["XDG_CACHE_HOME"] = str(Path(isolated_home) / ".cache")
    env.update(dict(extra))
    return env


def _run_build_command(root: Path, spec: BuildSpec) -> tuple[int, str, str]:
    cwd = (root / spec.cwd).resolve()
    if not _inside(root.resolve(), cwd) or not cwd.is_dir():
        raise ProvenanceError("build cwd escaped candidate snapshot")
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="ados-build-home-") as build_home, tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        kwargs: dict[str, Any] = {}
        if os.name != "nt":
            kwargs["start_new_session"] = True
        else:
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        proc = subprocess.Popen(_expand(spec.argv), cwd=cwd, env=_safe_env(spec.env, isolated_home=build_home), stdout=out, stderr=err, shell=False, **kwargs)
        while proc.poll() is None:
            if time.monotonic() - started > spec.timeout_seconds:
                try:
                    if os.name != "nt": os.killpg(proc.pid, 9)
                    else: proc.kill()
                finally:
                    raise ProvenanceError(f"build timed out after {spec.timeout_seconds}s")
            if os.fstat(out.fileno()).st_size + os.fstat(err.fileno()).st_size > spec.max_output_bytes:
                try:
                    if os.name != "nt": os.killpg(proc.pid, 9)
                    else: proc.kill()
                finally:
                    raise ProvenanceError("build output exceeded configured limit")
            time.sleep(0.05)
        rc = proc.wait(timeout=5)
        out.flush(); err.flush(); out.seek(0); err.seek(0)
        out_hash = hashlib.sha256(out.read()).hexdigest()
        err_hash = hashlib.sha256(err.read()).hexdigest()
        return rc, out_hash, err_hash


def run_isolated_build(
    snapshot_root: Path,
    *,
    candidate: Candidate,
    repository: str,
    spec: BuildSpec,
    destination: Path,
    private_key_pem: bytes,
    policy_digest_value: str,
    runner_attestation: RunnerAttestation | None = None,
) -> tuple[Path, Path, BuildProvenance]:
    """Build from an exact disposable candidate snapshot and emit signed provenance."""
    started_at = _now()
    snapshot_root = snapshot_root.resolve()
    for rel_name, expected_digest in spec.trusted_files:
        target = (snapshot_root / rel_name).resolve(strict=False)
        if not _inside(snapshot_root, target) or not target.exists() or not target.is_file() or target.is_symlink():
            raise ProvenanceError(f"trusted build implementation missing/invalid: {rel_name}")
        actual = _file_digest(target)
        if actual != expected_digest:
            raise ProvenanceError(
                f"trusted build implementation changed without governed TCB transition: {rel_name}; "
                f"expected={expected_digest} actual={actual}"
            )
    rc, stdout_hash, stderr_hash = _run_build_command(snapshot_root, spec)
    if rc != 0:
        raise ProvenanceError(f"build command failed rc={rc} stdout_sha256={stdout_hash} stderr_sha256={stderr_hash}")
    matches = [p for p in snapshot_root.glob(spec.artifact_glob) if p.is_file() and not p.is_symlink()]
    if len(matches) != 1:
        raise ProvenanceError(f"artifact_glob must resolve to exactly one regular file; got {len(matches)}")
    artifact = matches[0].resolve()
    if not _inside(snapshot_root.resolve(), artifact):
        raise ProvenanceError("built artifact escaped candidate snapshot")
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(artifact, destination)
    artifact_digest = sha256_regular_file(destination)
    sbom_path = (snapshot_root / spec.sbom_path).resolve(strict=False)
    sbom_digest: str | None = None
    if sbom_path.exists():
        if not _inside(snapshot_root.resolve(), sbom_path) or not sbom_path.is_file() or sbom_path.is_symlink():
            raise ProvenanceError("SBOM path is not a safe regular file in candidate snapshot")
        sbom_digest = _file_digest(sbom_path)
    provenance = BuildProvenance(
        schema_version=1,
        repository=repository,
        subject_sha=candidate.sha,
        subject_tree=candidate.tree or "",
        generation=candidate.generation,
        control_plane_version=__version__,
        policy_digest=policy_digest_value,
        builder_id=os.environ.get("CI_RUNNER_ID") or os.environ.get("HOSTNAME") or platform.node() or "unknown-builder",
        build_argv=spec.argv,
        build_cwd=spec.cwd,
        artifact_name=destination.name,
        artifact_digest=artifact_digest,
        artifact_size=destination.stat().st_size,
        sbom_digest=sbom_digest,
        lockfile_digests=_lockfiles(snapshot_root),
        toolchain=_toolchain_versions(snapshot_root, spec),
        isolation="detached_git_worktree_nonhermetic",
        # A pinned image digest is metadata unless ADOS actually executes inside
        # that image. The reference builder deliberately never over-claims this.
        hermetic=False,
        container_image_digest=spec.container_image_digest,
        started_at=started_at,
        finished_at=_now(),
        runner_attestation_digest=runner_attestation.digest() if runner_attestation else None,
        runner_attestation=asdict(runner_attestation) if runner_attestation else None,
    ).signed(private_key_pem)
    prov_path = destination.with_name(destination.name + ".provenance.json")
    provenance.to_file(prov_path)
    return destination, prov_path, provenance


def verify_artifact_provenance(
    *,
    artifact: Path,
    provenance_path: Path,
    candidate: Candidate,
    repository: str,
    policy_digest_value: str,
    verification_keys: dict[str, bytes],
    require_hermetic: bool = False,
    require_runner_attestation: bool = False,
    runner_verification_keys: dict[str, bytes] | None = None,
    candidate_root: Path | None = None,
    accepted_control_plane_versions: set[str] | frozenset[str] | None = None,
) -> BuildProvenance:
    if not artifact.exists() or not artifact.is_file() or artifact.is_symlink():
        raise ProvenanceError("release artifact must be an existing non-symlink regular file")
    if not provenance_path.exists() or not provenance_path.is_file() or provenance_path.is_symlink():
        raise ProvenanceError("release provenance must be an existing non-symlink regular file")
    prov = BuildProvenance.from_file(provenance_path)
    if not prov.verify(verification_keys):
        raise ProvenanceError("build provenance signature is invalid or signer is not trusted")
    expected = (repository, candidate.sha, candidate.tree or "", candidate.generation)
    actual = (prov.repository, prov.subject_sha, prov.subject_tree, prov.generation)
    if actual != expected:
        raise ProvenanceError(f"provenance candidate mismatch: expected={expected} actual={actual}")
    if prov.policy_digest != policy_digest_value:
        raise ProvenanceError("provenance policy digest does not match current trusted policy")
    digest = sha256_regular_file(artifact)
    if digest != prov.artifact_digest:
        raise ProvenanceError(f"artifact digest does not match build provenance: expected={prov.artifact_digest} actual={digest}")
    if artifact.stat().st_size != prov.artifact_size:
        raise ProvenanceError("artifact size does not match build provenance")
    if accepted_control_plane_versions is not None and prov.control_plane_version not in accepted_control_plane_versions:
        raise ProvenanceError(
            f"build provenance was produced by unaccepted ADOS version {prov.control_plane_version!r}"
        )
    if require_hermetic and not prov.hermetic:
        raise ProvenanceError("release policy requires hermetic/container-pinned build provenance")
    if require_runner_attestation:
        if not prov.runner_attestation_digest or not prov.runner_attestation:
            raise ProvenanceError("release policy requires build provenance bound to a signed disposable-runner attestation")
        if not runner_verification_keys:
            raise ProvenanceError("release policy requires anchored runner verification keys for build provenance")
        try:
            embedded = RunnerAttestation(**prov.runner_attestation)
        except (TypeError, ValueError) as exc:
            raise ProvenanceError("embedded build runner attestation is malformed") from exc
        if embedded.digest() != prov.runner_attestation_digest:
            raise ProvenanceError("embedded build runner attestation digest mismatch")
        try:
            finished = datetime.fromisoformat(prov.finished_at.replace("Z", "+00:00"))
            if finished.tzinfo is None:
                raise ValueError("naive finished_at")
            verify_runner_attestation(
                embedded, keys=runner_verification_keys, repository=repository, candidate=candidate, at_time=finished
            )
        except (RunnerAttestationError, ValueError) as exc:
            raise ProvenanceError(f"embedded build runner attestation is invalid: {exc}") from exc
    if candidate_root is not None:
        candidate_root = candidate_root.resolve()
        actual_lockfiles = _lockfiles(candidate_root)
        if actual_lockfiles != prov.lockfile_digests:
            raise ProvenanceError(
                f"build provenance lockfile inputs do not match exact candidate: expected={actual_lockfiles} actual={prov.lockfile_digests}"
            )
        sbom_path = candidate_root / ".ados/sbom.json"
        actual_sbom = _file_digest(sbom_path) if sbom_path.exists() and sbom_path.is_file() and not sbom_path.is_symlink() else None
        if actual_sbom != prov.sbom_digest:
            raise ProvenanceError(
                f"build provenance SBOM input does not match exact candidate: expected={actual_sbom} actual={prov.sbom_digest}"
            )
    return prov
