from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Mapping

from .exceptions import ControlledException
from .models import ActionDecision, ActionRequest, PolicyResult
from .safety import DeletionBudget, destructive_guard, evaluate_deletion_budget
from .util import load_json


@dataclass
class Constitution:
    protected_branches: set[str]
    protected_paths: tuple[str, ...]
    prohibited_actions: set[str]
    deletion_budget: DeletionBudget

    @classmethod
    def from_file(cls, path: str | Path) -> "Constitution":
        raw = load_json(path)
        return cls(
            protected_branches=set(raw.get("protected_branches", ["main", "master"])),
            protected_paths=tuple(raw.get("protected_paths", [])),
            prohibited_actions=set(raw.get("prohibited_actions", [])),
            deletion_budget=DeletionBudget(**raw.get("deletion_budget", {})),
        )

    def is_protected_path(self, path: str) -> bool:
        return _protected(path, self.protected_paths)


def _normalize_repo_path(path: str) -> str:
    return str(PurePosixPath(path.replace("\\", "/")))


def _protected(path: str, protected_paths: tuple[str, ...]) -> bool:
    p = _normalize_repo_path(path)
    for raw in protected_paths:
        prefix = _normalize_repo_path(raw)
        if raw.endswith(("/", "\\")):
            prefix = prefix.rstrip("/")
            if p == prefix or p.startswith(prefix + "/"):
                return True
        elif p == prefix:
            return True
    return False


class PolicyEngine:
    def __init__(
        self,
        constitution: Constitution,
        break_glass_secret: bytes | None = None,
        break_glass_public_keys: Mapping[str, bytes] | None = None,
    ):
        self.constitution = constitution
        self.break_glass_secret = break_glass_secret
        self.break_glass_public_keys = break_glass_public_keys

    def _exception_allows(self, exception: ControlledException | None, rule_id: str, scope: str) -> bool:
        if exception is None:
            return False
        return (
            exception.rule_id == rule_id
            and exception.scope == scope
            and exception.is_valid(
                secret=self.break_glass_secret,
                approval_public_keys=self.break_glass_public_keys,
            )
        )

    def evaluate(self, req: ActionRequest, exception: ControlledException | None = None) -> list[PolicyResult]:
        results: list[PolicyResult] = []
        if req.action in self.constitution.prohibited_actions:
            if self._exception_allows(exception, "PROHIBITED_ACTION", f"{req.environment}:{req.action}"):
                results.append(PolicyResult(ActionDecision.ALLOW, "independently signed break-glass exception accepted", "PROHIBITED_ACTION"))
            else:
                results.append(PolicyResult(ActionDecision.DENY, f"action {req.action!r} is prohibited", "PROHIBITED_ACTION"))

        if req.branch and req.branch in self.constitution.protected_branches:
            if req.action in {"force_push", "delete_branch", "force_push_main"}:
                results.append(PolicyResult(ActionDecision.DENY, f"destructive direct mutation of protected branch {req.branch!r} is prohibited", "PROTECTED_BRANCH"))
            elif req.action in {"push", "write_branch", "patch_branch"}:
                if self._exception_allows(exception, "PROTECTED_BRANCH_WRITE", f"{req.environment}:{req.branch}"):
                    results.append(PolicyResult(ActionDecision.ALLOW, "signed protected-branch exception accepted", "PROTECTED_BRANCH_WRITE"))
                else:
                    results.append(PolicyResult(ActionDecision.REQUIRE_APPROVAL, f"direct write to protected branch {req.branch!r} requires controlled approval", "PROTECTED_BRANCH_WRITE"))

        protected_hits = [p for p in req.changed_files if _protected(p, self.constitution.protected_paths)]
        if protected_hits:
            if self._exception_allows(exception, "TRUSTED_COMPUTING_BASE_CHANGE", f"{req.environment}:protected_paths"):
                results.append(PolicyResult(ActionDecision.ALLOW, "signed TCB exception accepted", "TRUSTED_COMPUTING_BASE_CHANGE"))
            else:
                # This is a review signal, not a permanent self-bootstrap deadlock.
                results.append(PolicyResult(ActionDecision.REQUIRE_APPROVAL, f"trusted computing-base paths changed: {protected_hits}", "TRUSTED_COMPUTING_BASE_CHANGE"))

        results.append(destructive_guard(req))
        results.append(evaluate_deletion_budget(req, self.constitution.deletion_budget))
        return results

    @staticmethod
    def final_decision(results: list[PolicyResult]) -> PolicyResult:
        for result in results:
            if result.decision is ActionDecision.DENY:
                return result
        for result in results:
            if result.decision is ActionDecision.REQUIRE_APPROVAL:
                return result
        return PolicyResult(ActionDecision.ALLOW, "all policies allow action")
