from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .gate_executor import GateExecutionPolicy, execute_gates_isolated
from .gates import Gate, GateContext, RESERVED_CORE_GATES, default_gate_registry
from .adapter_manifest import PinnedAdapterGate
from .impact import ImpactModel
from .models import DevelopmentLane, GateResult, GateStatus, Task
from .risk import classify_risk


CAPABILITY_GATES: dict[str, set[str]] = {
    "ui": {"wiring", "ux", "accessibility", "user_journey"},
    "external_integrations": {"contracts", "integration", "wiring"},
    "multi_tenant": {"tenant_isolation"},
    "document_generation": {"golden", "user_journey"},
    "runtime_library": {"contracts", "compatibility"},
    "payments": {"security", "contracts", "integration"},
    "persistent_data": {"data_migration", "security"},
}

# Assurance labels are governance-reviewed contracts for strict lanes. They do not
# magically prove scanner semantics; instead they make the claimed measurement
# explicit and bind it to the protected command implementation/trusted files.
# A release dependency audit is intentionally stronger than a merge test.
STRICT_GATE_ASSURANCES: dict[str, frozenset[str]] = {
    "architecture": frozenset({"architecture"}),
    "tests": frozenset({"tests"}),
    "full_regression": frozenset({"full_regression"}),
    "dependency_audit": frozenset({"lockfile_integrity", "license_policy"}),
    "release": frozenset({"release_readiness"}),
    "security": frozenset({"security"}),
    "red_team": frozenset({"red_team"}),
    "contracts": frozenset({"contracts"}),
    "compatibility": frozenset({"compatibility"}),
    "integration": frozenset({"integration"}),
    "wiring": frozenset({"wiring"}),
    "ux": frozenset({"ux"}),
    "accessibility": frozenset({"accessibility"}),
    "user_journey": frozenset({"user_journey"}),
    "golden": frozenset({"golden"}),
    "tenant_isolation": frozenset({"tenant_isolation"}),
    "data_migration": frozenset({"data_migration"}),
}


@dataclass
class Assessment:
    task: Task
    gate_results: list[GateResult]
    lane: DevelopmentLane = DevelopmentLane.DEVELOPMENT

    @property
    def blocking_failures(self) -> list[GateResult]:
        return [r for r in self.gate_results if r.status is GateStatus.FAIL]

    @property
    def unknowns(self) -> list[GateResult]:
        return [r for r in self.gate_results if r.status is GateStatus.UNKNOWN]

    @property
    def release_blockers(self) -> list[GateResult]:
        # Development is intentionally advisory except for hard core failures. The
        # merge/release lanes fail closed on UNKNOWN project semantics.
        if self.lane is DevelopmentLane.DEVELOPMENT:
            hard_core = {"source", "safety", "governance", "supply_chain"}
            return [r for r in self.gate_results if r.status is GateStatus.FAIL and r.gate in hard_core]
        return [r for r in self.gate_results if r.status in {GateStatus.FAIL, GateStatus.UNKNOWN}]


class Orchestrator:
    def __init__(
        self,
        impact_model: ImpactModel,
        gates: dict[str, Gate] | None = None,
        *,
        always_gates: set[str] | frozenset[str] = frozenset(),
        execution_policy: GateExecutionPolicy | None = None,
        capabilities: set[str] | frozenset[str] = frozenset(),
    ):
        self.impact_model = impact_model
        self.always_gates = set(always_gates)
        self.execution_policy = execution_policy
        self.capabilities = set(capabilities)
        self.gates = default_gate_registry()
        if gates:
            forbidden = RESERVED_CORE_GATES.intersection(gates)
            if forbidden:
                raise ValueError(f"project adapters cannot override reserved core gates: {sorted(forbidden)}")
            self.gates.update(gates)

    def register_gate(self, gate: Gate) -> None:
        if gate.name in RESERVED_CORE_GATES:
            raise ValueError(f"project adapter cannot override reserved core gate {gate.name!r}")
        self.gates[gate.name] = gate

    def assess(
        self,
        root: Path,
        task: Task,
        changed_files: tuple[str, ...],
        deleted_files: tuple[str, ...] = (),
        *,
        lane: DevelopmentLane | None = None,
        trusted_policy_root: Path | None = None,
        governance_approved: bool = False,
        governance_approval_id: str | None = None,
    ) -> Assessment:
        lane = lane or task.lane
        impacted_files = tuple(dict.fromkeys((*changed_files, *deleted_files)))
        risk, reasons = classify_risk(impacted_files, overrides=self.impact_model.risk_overrides)
        task.risk = risk
        task.affected_components = self.impact_model.affected_components(impacted_files)
        task.required_gates = self.impact_model.required_gates(impacted_files, risk, lane) | self.always_gates
        if lane is not DevelopmentLane.DEVELOPMENT:
            for capability in self.capabilities:
                task.required_gates.update(CAPABILITY_GATES.get(capability, ()))
        task.metadata["risk_reasons"] = reasons
        task.metadata["impact_unmatched_files"] = sorted(self.impact_model.unmatched_files(impacted_files))
        task.metadata["assessment_lane"] = lane.value

        ctx = GateContext(
            root=root, task=task, changed_files=changed_files, deleted_files=deleted_files, lane=lane,
            trusted_policy_root=trusted_policy_root, governance_approved=governance_approved,
            governance_approval_id=governance_approval_id,
        )
        results: list[GateResult] = []
        runnable: list[Gate] = []
        for name in sorted(task.required_gates):
            gate = self.gates.get(name)
            if gate is None:
                results.append(GateResult(name, GateStatus.UNKNOWN, "gate not registered"))
            elif lane is DevelopmentLane.RELEASE and isinstance(gate, PinnedAdapterGate) and not gate.allow_in_release:
                results.append(GateResult(
                    name, GateStatus.UNKNOWN,
                    "repository Python adapter is identity-pinned but not security-sandboxed; release requires a command gate or explicit protected allow_in_release approval",
                    {"adapter_capabilities": list(gate.capabilities)},
                ))
            else:
                if lane is not DevelopmentLane.DEVELOPMENT:
                    from .command_gates import CommandGate
                    if isinstance(gate, CommandGate):
                        required_assurances = STRICT_GATE_ASSURANCES.get(name, frozenset())
                        missing = required_assurances - set(gate.spec.assurances)
                        if missing:
                            results.append(GateResult(
                                name, GateStatus.FAIL,
                                f"strict lane gate is missing governance-reviewed assurance contracts: {sorted(missing)}",
                                {"declared_assurances": list(gate.spec.assurances), "required_assurances": sorted(required_assurances)},
                            ))
                            continue
                runnable.append(gate)
        if self.execution_policy is None:
            for gate in runnable:
                try:
                    result = gate.run(ctx)
                    if not isinstance(result, GateResult):
                        raise TypeError(f"gate returned {type(result).__name__}, expected GateResult")
                    if result.gate != gate.name:
                        raise ValueError(f"gate result identity mismatch: expected={gate.name!r} actual={result.gate!r}")
                except BaseException as exc:
                    result = GateResult(gate.name, GateStatus.FAIL, f"gate crashed: {type(exc).__name__}: {exc}")
                results.append(result)
        else:
            results.extend(execute_gates_isolated(runnable, ctx, self.execution_policy))
        results.sort(key=lambda r: r.gate)
        return Assessment(task=task, gate_results=results, lane=lane)
