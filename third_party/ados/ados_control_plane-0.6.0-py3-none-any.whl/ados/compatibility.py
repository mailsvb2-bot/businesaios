from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations, product
from typing import Any

from .models import GateResult, GateStatus


@dataclass(frozen=True)
class BlockContract:
    source: str
    target: str
    requires: frozenset[str]
    provides: frozenset[str]


def check_block_contract(
    contract: BlockContract,
    source_capabilities: set[str],
    target_requirements: set[str] | None = None,
    *,
    observation_ids: set[str] | None = None,
    require_observed: bool = False,
) -> GateResult:
    if require_observed and not observation_ids:
        return GateResult("block_compatibility", GateStatus.UNKNOWN, "strict compatibility requires measured observation evidence")
    missing = set(contract.requires) - set(source_capabilities)
    if missing:
        return GateResult("block_compatibility", GateStatus.FAIL, f"missing required capabilities: {sorted(missing)}")
    if target_requirements:
        missing_provides = set(target_requirements) - set(contract.provides)
        if missing_provides:
            return GateResult("block_compatibility", GateStatus.FAIL, f"contract does not provide: {sorted(missing_provides)}")
    return GateResult("block_compatibility", GateStatus.PASS, f"{contract.source}->{contract.target} compatible", {"observation_ids": sorted(observation_ids or ())})


def _requirement(case: dict[int, int], strength: int) -> set[tuple[tuple[int, int], ...]]:
    return {
        tuple((i, case[i]) for i in combo)
        for combo in combinations(sorted(case), strength)
    }


def covering_cases(
    dimensions: dict[str, list[Any]],
    *,
    strength: int = 2,
    max_requirements: int = 100_000,
    max_cases: int = 10_000,
) -> list[dict[str, Any]]:
    """Deterministic bounded t-wise covering array generator.

    Pairwise remains cheap, while safety-critical projects can request 3-wise or
    stronger coverage. The generator refuses pathological matrices rather than
    silently falling back to weaker coverage.
    """
    keys = list(dimensions)
    if not keys: return []
    values = [dimensions[k] for k in keys]
    if any(not v for v in values): raise ValueError("each dimension must contain at least one value")
    if strength < 1 or strength > len(keys): raise ValueError("strength must be between 1 and number of dimensions")
    requirements: set[tuple[tuple[int, int], ...]] = set()
    for combo in combinations(range(len(keys)), strength):
        count = 1
        for i in combo: count *= len(values[i])
        if len(requirements) + count > max_requirements:
            raise ValueError(f"t-wise requirement count exceeds max_requirements={max_requirements}; partition matrix or use specialized adapter")
        for selected in product(*(range(len(values[i])) for i in combo)):
            requirements.add(tuple(zip(combo, selected)))
    uncovered = set(requirements); selected_cases: list[dict[str, Any]] = []
    while uncovered:
        if len(selected_cases) >= max_cases: raise ValueError(f"covering case count exceeded max_cases={max_cases}")
        seed = min(uncovered)
        assignment: dict[int, int] = dict(seed)
        for k in range(len(keys)):
            if k in assignment: continue
            best_value = 0; best_score = -1
            for vk in range(len(values[k])):
                trial = dict(assignment); trial[k] = vk
                score = len(_requirement(trial, strength) & uncovered) if len(trial) >= strength else 0
                if score > best_score: best_score = score; best_value = vk
            assignment[k] = best_value
        uncovered.difference_update(_requirement(assignment, strength))
        selected_cases.append({keys[i]: values[i][v] for i, v in sorted(assignment.items())})
    return selected_cases


def pairwise_cases(dimensions: dict[str, list[Any]], max_pair_requirements: int = 100_000, max_cases: int = 10_000) -> list[dict[str, Any]]:
    return covering_cases(dimensions, strength=2 if len(dimensions) >= 2 else 1, max_requirements=max_pair_requirements, max_cases=max_cases)


@dataclass(frozen=True)
class CompositionContract:
    composition_id: str
    blocks: tuple[str, ...]
    required_invariants: frozenset[str]


def check_composition(contract: CompositionContract, observed_invariants: set[str], *, observation_ids: set[str] | None = None, require_observed: bool = False) -> GateResult:
    if require_observed and not observation_ids:
        return GateResult("composition_compatibility", GateStatus.UNKNOWN, "strict composition compatibility requires measured evidence")
    missing = set(contract.required_invariants) - set(observed_invariants)
    if missing:
        return GateResult("composition_compatibility", GateStatus.FAIL, f"composition={contract.composition_id} missing invariants: {sorted(missing)}", {"blocks": list(contract.blocks)})
    return GateResult("composition_compatibility", GateStatus.PASS, f"composition={contract.composition_id} compatible", {"blocks": list(contract.blocks), "observation_ids": sorted(observation_ids or ())})


@dataclass(frozen=True)
class ConsumerContract:
    provider: str
    consumer: str
    min_protocol: int
    max_protocol_exclusive: int
    required_capabilities: frozenset[str]
    expected_schema_hash: str | None = None


def check_consumer_contract(
    contract: ConsumerContract,
    *, provider_protocol: int, provider_capabilities: set[str], provider_schema_hash: str | None = None,
    observation_ids: set[str] | None = None, require_observed: bool = False,
) -> GateResult:
    if require_observed and not observation_ids:
        return GateResult("consumer_contract", GateStatus.UNKNOWN, "strict consumer contract requires measured provider evidence")
    if not (contract.min_protocol <= provider_protocol < contract.max_protocol_exclusive):
        return GateResult("consumer_contract", GateStatus.FAIL, f"{contract.consumer} requires {contract.provider} protocol >= {contract.min_protocol} and < {contract.max_protocol_exclusive}; got {provider_protocol}")
    missing = set(contract.required_capabilities) - set(provider_capabilities)
    if missing: return GateResult("consumer_contract", GateStatus.FAIL, f"provider missing consumer-required capabilities: {sorted(missing)}")
    if contract.expected_schema_hash is not None and provider_schema_hash != contract.expected_schema_hash:
        return GateResult("consumer_contract", GateStatus.FAIL, "provider schema hash does not match consumer contract")
    return GateResult("consumer_contract", GateStatus.PASS, f"{contract.provider}->{contract.consumer} contract compatible", {"observation_ids": sorted(observation_ids or ())})
