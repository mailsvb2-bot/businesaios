from __future__ import annotations

import base64
import hashlib
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


class SignatureError(ValueError):
    pass


def public_key_fingerprint(public_key: Ed25519PublicKey) -> str:
    raw = public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return "ed25519:" + hashlib.sha256(raw).hexdigest()[:32]


def load_private_key(data: bytes) -> Ed25519PrivateKey:
    try:
        key = serialization.load_pem_private_key(data, password=None)
    except Exception as exc:
        raise SignatureError(f"invalid Ed25519 private key: {exc}") from exc
    if not isinstance(key, Ed25519PrivateKey):
        raise SignatureError("private key is not Ed25519")
    return key


def load_public_key(data: bytes) -> Ed25519PublicKey:
    try:
        key = serialization.load_pem_public_key(data)
    except Exception as exc:
        raise SignatureError(f"invalid Ed25519 public key: {exc}") from exc
    if not isinstance(key, Ed25519PublicKey):
        raise SignatureError("public key is not Ed25519")
    return key


def generate_keypair() -> tuple[bytes, bytes, str]:
    private = Ed25519PrivateKey.generate()
    public = private.public_key()
    private_pem = private.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    public_pem = public.public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem, public_key_fingerprint(public)


def sign_ed25519(payload: bytes, private_key_pem: bytes) -> tuple[str, str]:
    key = load_private_key(private_key_pem)
    signature = key.sign(payload)
    return base64.b64encode(signature).decode("ascii"), public_key_fingerprint(key.public_key())


def verify_ed25519(payload: bytes, signature_b64: str, public_key_pem: bytes) -> bool:
    try:
        signature = base64.b64decode(signature_b64, validate=True)
        key = load_public_key(public_key_pem)
        key.verify(signature, payload)
        return True
    except Exception:
        return False


def read_key(path: str | Path) -> bytes:
    return Path(path).read_bytes()
