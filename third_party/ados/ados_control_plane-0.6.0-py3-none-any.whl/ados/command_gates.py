from __future__ import annotations

import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from .gates import Gate, GateContext, RESERVED_CORE_GATES
from .models import GateResult, GateStatus


class CommandGateConfigError(ValueError):
    pass


_SAFE_INHERITED_ENV = {
    "PATH", "TMPDIR", "TEMP", "TMP",
    "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT",
    "LANG", "LC_ALL", "LC_CTYPE", "TERM",
}
_SENSITIVE_ENV_FRAGMENTS = ("SECRET", "TOKEN", "PASSWORD", "PASSWD", "API_KEY", "APIKEY", "PRIVATE_KEY", "CREDENTIAL")


def _inside(root: Path, candidate: Path) -> bool:
    try:
        candidate.relative_to(root)
        return True
    except ValueError:
        return False


def _safe_static_env(extra: dict[str, str], *, isolated_home: str | None = None) -> dict[str, str]:
    for key, value in extra.items():
        upper = key.upper()
        if any(fragment in upper for fragment in _SENSITIVE_ENV_FRAGMENTS):
            raise CommandGateConfigError(f"command gate may not define sensitive environment key {key!r}")
        if not isinstance(value, str):
            raise CommandGateConfigError(f"environment value for {key!r} must be a string")
    env = {key: value for key, value in os.environ.items() if key.upper() in _SAFE_INHERITED_ENV}
    if isolated_home is not None:
        env["HOME"] = isolated_home
        env["USERPROFILE"] = isolated_home
        env["XDG_CONFIG_HOME"] = str(Path(isolated_home) / ".config")
        env["XDG_CACHE_HOME"] = str(Path(isolated_home) / ".cache")
    env.update(extra)
    return env


def _expand_argv(argv: tuple[str, ...]) -> list[str]:
    return [sys.executable if item == "{python}" else item for item in argv]


def _kill_process_tree(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            # taskkill terminates the process tree. Fall back to kill if unavailable.
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        else:
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    try:
        proc.wait(timeout=5)
    except Exception:
        pass


@dataclass(frozen=True)
class CommandGateSpec:
    gate: str
    argv: tuple[str, ...]
    cwd: str = "."
    timeout_seconds: float = 120.0
    max_output_bytes: int = 16 * 1024 * 1024
    env: tuple[tuple[str, str], ...] = ()
    capabilities: tuple[str, ...] = ("read_repo", "execute")
    assurances: tuple[str, ...] = ()
    trusted_files: tuple[tuple[str, str], ...] = ()

    @classmethod
    def from_dict(cls, raw: dict) -> "CommandGateSpec":
        gate = raw.get("gate")
        argv = raw.get("argv")
        if not isinstance(gate, str) or not gate:
            raise CommandGateConfigError("command gate requires non-empty 'gate'")
        if gate in RESERVED_CORE_GATES:
            raise CommandGateConfigError(f"command gate cannot override reserved core gate {gate!r}")
        if not isinstance(argv, list) or not argv or not all(isinstance(x, str) and x for x in argv):
            raise CommandGateConfigError(f"command gate {gate!r} requires non-empty string argv list")
        cwd = raw.get("cwd", ".")
        if not isinstance(cwd, str) or not cwd:
            raise CommandGateConfigError(f"command gate {gate!r} has invalid cwd")
        timeout = float(raw.get("timeout_seconds", 120.0))
        if timeout <= 0 or timeout > 21_600:
            raise CommandGateConfigError(f"command gate {gate!r} timeout_seconds must be >0 and <=21600")
        max_output = int(raw.get("max_output_bytes", 16 * 1024 * 1024))
        if max_output < 1024 or max_output > 512 * 1024 * 1024:
            raise CommandGateConfigError(f"command gate {gate!r} max_output_bytes must be between 1KiB and 512MiB")
        env = raw.get("env", {})
        if not isinstance(env, dict):
            raise CommandGateConfigError(f"command gate {gate!r} env must be an object")
        _safe_static_env({str(k): v for k, v in env.items()})
        capabilities = raw.get("capabilities", ["read_repo", "execute"])
        if not isinstance(capabilities, list) or not all(isinstance(x, str) and x for x in capabilities):
            raise CommandGateConfigError(f"command gate {gate!r} capabilities must be a string list")
        assurances = raw.get("assurances", [])
        if not isinstance(assurances, list) or not all(isinstance(x, str) and x for x in assurances):
            raise CommandGateConfigError(f"command gate {gate!r} assurances must be a string list")
        trusted_files = raw.get("trusted_files", [])
        if not isinstance(trusted_files, list) or not all(isinstance(x, str) and x for x in trusted_files):
            raise CommandGateConfigError(f"command gate {gate!r} trusted_files must be a string list")
        normalized_trusted: list[tuple[str, str]] = []
        for rel_name in trusted_files:
            rel_path = Path(rel_name)
            if rel_path.is_absolute() or ".." in rel_path.parts:
                raise CommandGateConfigError(f"command gate {gate!r} trusted file escapes repository: {rel_name!r}")
            normalized_trusted.append((rel_path.as_posix(), ""))
        return cls(
            gate=gate,
            argv=tuple(argv),
            cwd=cwd,
            timeout_seconds=timeout,
            max_output_bytes=max_output,
            env=tuple(sorted((str(k), v) for k, v in env.items())),
            capabilities=tuple(sorted(set(capabilities))),
            assurances=tuple(sorted(set(assurances))),
            trusted_files=tuple(normalized_trusted),
        )


@dataclass(frozen=True)
class CommandGate:
    spec: CommandGateSpec

    @property
    def name(self) -> str:
        return self.spec.gate

    @property
    def timeout_seconds(self) -> float:
        # Outer gate executor needs enough time for this command plus cleanup.
        return self.spec.timeout_seconds + 10.0

    def run(self, ctx: GateContext) -> GateResult:
        root = ctx.root.resolve()
        for rel_name, expected_digest in self.spec.trusted_files:
            target = (root / rel_name).resolve(strict=False)
            if not _inside(root, target) or not target.exists() or not target.is_file() or target.is_symlink():
                return GateResult(self.name, GateStatus.FAIL, f"trusted gate implementation missing/invalid: {rel_name}")
            actual = "sha256:" + hashlib.sha256(target.read_bytes()).hexdigest()
            if expected_digest and actual != expected_digest:
                return GateResult(
                    self.name, GateStatus.FAIL,
                    f"trusted gate implementation changed without governed TCB transition: {rel_name}",
                    {"path": rel_name, "expected_sha256": expected_digest, "actual_sha256": actual},
                )
        rel = Path(self.spec.cwd)
        if rel.is_absolute() or ".." in rel.parts:
            return GateResult(self.name, GateStatus.FAIL, "command gate cwd escapes repository")
        cwd = (root / rel).resolve(strict=False)
        if not _inside(root, cwd):
            return GateResult(self.name, GateStatus.FAIL, "command gate cwd resolves outside repository")
        if not cwd.exists() or not cwd.is_dir():
            return GateResult(self.name, GateStatus.FAIL, f"command gate cwd missing or not directory: {self.spec.cwd}")
        argv = _expand_argv(self.spec.argv)
        creationflags = 0
        popen_kwargs: dict[str, object] = {}
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        else:
            popen_kwargs["start_new_session"] = True
        started = time.monotonic()
        with tempfile.TemporaryDirectory(prefix="ados-gate-home-") as gate_home, tempfile.TemporaryFile() as stdout_fh, tempfile.TemporaryFile() as stderr_fh:
            try:
                proc = subprocess.Popen(
                    argv,
                    cwd=cwd,
                    env=_safe_static_env(dict(self.spec.env), isolated_home=gate_home),
                    shell=False,
                    stdout=stdout_fh,
                    stderr=stderr_fh,
                    creationflags=creationflags,
                    **popen_kwargs,
                )
            except (OSError, ValueError) as exc:
                return GateResult(self.name, GateStatus.FAIL, f"command failed to start: {type(exc).__name__}: {exc}")

            output_overflow = False
            while proc.poll() is None:
                elapsed = time.monotonic() - started
                if elapsed > self.spec.timeout_seconds:
                    _kill_process_tree(proc)
                    return GateResult(self.name, GateStatus.FAIL, f"command timed out after {self.spec.timeout_seconds:.3f}s")
                try:
                    if os.fstat(stdout_fh.fileno()).st_size + os.fstat(stderr_fh.fileno()).st_size > self.spec.max_output_bytes:
                        output_overflow = True
                        _kill_process_tree(proc)
                        break
                except OSError:
                    pass
                time.sleep(0.02)

            if output_overflow:
                return GateResult(self.name, GateStatus.FAIL, f"command output exceeded max_output_bytes={self.spec.max_output_bytes}")
            return_code = proc.wait(timeout=5)
            stdout_fh.flush(); stderr_fh.flush()
            stdout_size = os.fstat(stdout_fh.fileno()).st_size
            stderr_size = os.fstat(stderr_fh.fileno()).st_size
            stdout_fh.seek(0); stderr_fh.seek(0)
            stdout_hash = hashlib.sha256()
            stderr_hash = hashlib.sha256()
            for fh, hasher in ((stdout_fh, stdout_hash), (stderr_fh, stderr_hash)):
                for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                    hasher.update(chunk)
            details = {
                "exit_code": return_code,
                "stdout_bytes": stdout_size,
                "stderr_bytes": stderr_size,
                "stdout_sha256": stdout_hash.hexdigest(),
                "stderr_sha256": stderr_hash.hexdigest(),
                "duration_seconds": round(time.monotonic() - started, 6),
                "capabilities": list(self.spec.capabilities),
                "assurances": list(self.spec.assurances),
            }
            if return_code == 0:
                return GateResult(self.name, GateStatus.PASS, "command gate passed", details)
            return GateResult(self.name, GateStatus.FAIL, f"command gate exited with code {return_code}", details)


def load_command_gates(root: Path, manifest_path: Path) -> dict[str, Gate]:
    root = root.resolve()
    manifest_path = manifest_path.resolve()
    if not _inside(root, manifest_path):
        raise CommandGateConfigError("command gate manifest must be inside repository root")
    raw = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise CommandGateConfigError("command gate manifest must be a JSON object")
    items = raw.get("gates", [])
    if not isinstance(items, list):
        raise CommandGateConfigError("command gate manifest 'gates' must be a list")
    loaded: dict[str, Gate] = {}
    for item in items:
        if not isinstance(item, dict):
            raise CommandGateConfigError("command gate entries must be JSON objects")
        spec = CommandGateSpec.from_dict(item)
        hydrated: list[tuple[str, str]] = []
        for rel_name, _ in spec.trusted_files:
            target = (root / rel_name).resolve(strict=False)
            if not _inside(root, target) or not target.exists() or not target.is_file() or target.is_symlink():
                raise CommandGateConfigError(f"command gate {spec.gate!r} trusted file is missing/invalid: {rel_name!r}")
            hydrated.append((rel_name, "sha256:" + hashlib.sha256(target.read_bytes()).hexdigest()))
        trusted_names = {name for name, _ in hydrated}
        referenced_repo_files: set[str] = set()
        for token in spec.argv:
            if token == "{python}" or token.startswith("-"):
                continue
            rel_token = Path(token)
            if rel_token.is_absolute() or ".." in rel_token.parts:
                continue
            target = (root / rel_token).resolve(strict=False)
            if _inside(root, target) and target.exists() and target.is_file() and not target.is_symlink():
                referenced_repo_files.add(rel_token.as_posix())
        untrusted = sorted(referenced_repo_files - trusted_names)
        if untrusted:
            raise CommandGateConfigError(
                f"command gate {spec.gate!r} executes repository files that are not trusted_files: {untrusted}"
            )
        if hydrated:
            from dataclasses import replace
            spec = replace(spec, trusted_files=tuple(hydrated))
        if spec.gate in loaded:
            raise CommandGateConfigError(f"duplicate command gate {spec.gate!r}")
        loaded[spec.gate] = CommandGate(spec)
    return loaded
