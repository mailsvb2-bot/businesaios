from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

from .gate_executor import GateExecutionPolicy
from .rollout import ProductProfile
from .util import load_json


@dataclass(frozen=True)
class RemoteBaseTruthPolicy:
    mode: str = "auto"  # auto|required|disabled
    remote: str = "origin"
    ref: str | None = None
    host: str | None = None
    allow_local_filesystem_for_release: bool = False
    timeout_seconds: float = 15.0

    @property
    def enabled(self) -> bool:
        return self.mode != "disabled"

    def __post_init__(self):
        if self.mode not in {"auto", "required", "disabled"}:
            raise ValueError("remote_base.mode must be auto, required, or disabled")
        if not self.remote or self.remote.startswith("-"):
            raise ValueError("remote_base.remote must be a non-option Git remote or URL")
        if self.ref is not None and (not self.ref or self.ref.startswith("-")):
            raise ValueError("remote_base.ref must be a non-option Git ref")
        if self.host is not None:
            normalized = self.host.strip().lower()
            if not normalized or "/" in normalized or ":" in normalized or normalized.startswith("-"):
                raise ValueError("remote_base.host must be a bare network hostname such as github.com")
            object.__setattr__(self, "host", normalized)
        if self.timeout_seconds <= 0 or self.timeout_seconds > 300:
            raise ValueError("remote_base.timeout_seconds must be > 0 and <= 300")


@dataclass(frozen=True)
class TrustPolicy:
    require_asymmetric_release_signing: bool = True
    evidence_public_key_files: tuple[str, ...] = ()
    break_glass_public_key_files: tuple[str, ...] = ()
    runner_public_key_files: tuple[str, ...] = ()
    vulnerability_public_key_files: tuple[str, ...] = ()
    deployment_public_key_files: tuple[str, ...] = ()
    require_runner_attestation_for_certification: bool = True
    runner_attestation_env: str = "ADOS_RUNNER_ATTESTATION_FILE"
    require_vulnerability_attestation_for_release: bool = True
    vulnerability_attestation_env: str = "ADOS_VULNERABILITY_ATTESTATION_FILE"
    vulnerability_max_severity: str = "NONE"
    require_deployment_attestation_for_health: bool = True
    deployment_attestation_env: str = "ADOS_DEPLOYMENT_ATTESTATION_FILE"
    deployment_environment: str = "production"
    allow_hmac_development: bool = True
    accepted_control_plane_versions: tuple[str, ...] = ()


@dataclass(frozen=True)
class EvidencePolicy:
    # Immutable candidate/build evidence is intentionally long lived enough for
    # queues and human approvals. Mutable production health remains short lived.
    required_gates_ttl_seconds: int = 86_400
    release_ttl_seconds: int = 86_400
    rollout_health_ttl_seconds: int = 1_800
    recovery_ttl_seconds: int = 3_600

    def __post_init__(self):
        for name, value in self.__dict__.items():
            if value <= 0 or value > 86_400:
                raise ValueError(f"evidence.{name} must be >0 and <=86400")


@dataclass(frozen=True)
class RolloutPolicy:
    health_required_tags: tuple[str, ...] = ("health", "candidate", "production")


@dataclass(frozen=True)
class StoragePolicy:
    mode: str = "single_node"  # single_node|distributed
    backend: str = "sqlite"  # sqlite|external

    def __post_init__(self):
        if self.mode not in {"single_node", "distributed"}:
            raise ValueError("storage.mode must be single_node or distributed")
        if self.backend not in {"sqlite", "external"}:
            raise ValueError("storage.backend must be sqlite or external")
        if self.mode == "distributed":
            raise ValueError(
                "the reference kernel refuses distributed mode until an external transactional store with fencing is configured by a supported backend; SQLite is single-node only"
            )



@dataclass(frozen=True)
class AuditPolicy:
    require_external_anchor_for_release: bool = True
    anchor_env: str = "ADOS_AUDIT_ANCHOR_FILE"

@dataclass(frozen=True)
class ProjectConfig:
    profile: ProductProfile
    repository_id: str | None = None
    capabilities: frozenset[str] = frozenset()
    scheduler_resources: frozenset[str] = frozenset()
    always_gates: frozenset[str] = frozenset()
    control_role: str = "controller_auditor"
    adapter_manifest: str = ".ados/adapters.json"
    command_manifest: str = ".ados/commands.json"
    build_manifest: str = ".ados/build.json"
    gate_execution: GateExecutionPolicy = GateExecutionPolicy()
    rollback_safe: bool = False
    remote_base: RemoteBaseTruthPolicy = RemoteBaseTruthPolicy()
    trust: TrustPolicy = TrustPolicy()
    evidence: EvidencePolicy = EvidencePolicy()
    rollout: RolloutPolicy = RolloutPolicy()
    storage: StoragePolicy = StoragePolicy()
    audit: AuditPolicy = AuditPolicy()
    strict_project_gates: bool = True
    require_hermetic_build: bool = False

    @classmethod
    def from_file(cls, path: str | Path) -> "ProjectConfig":
        raw = load_json(path)
        execution = raw.get("gate_execution", {})
        remote = raw.get("remote_base", {})
        trust = raw.get("trust", {})
        evidence = raw.get("evidence", {})
        rollout = raw.get("rollout", {})
        storage = raw.get("storage", {})
        audit = raw.get("audit", {})
        if "mode" in remote:
            remote_mode = str(remote.get("mode", "auto"))
        elif "enabled" in remote:
            remote_mode = "required" if bool(remote.get("enabled")) else "disabled"
        else:
            remote_mode = "auto"
        return cls(
            profile=ProductProfile(raw["profile"]),
            repository_id=raw.get("repository_id"),
            capabilities=frozenset(str(x) for x in raw.get("capabilities", ())),
            scheduler_resources=frozenset(str(x) for x in raw.get("scheduler_resources", ())),
            always_gates=frozenset(raw.get("always_gates", ())),
            control_role=str(raw.get("control_role", "controller_auditor")),
            adapter_manifest=raw.get("adapter_manifest", ".ados/adapters.json"),
            command_manifest=raw.get("command_manifest", ".ados/commands.json"),
            build_manifest=raw.get("build_manifest", ".ados/build.json"),
            gate_execution=GateExecutionPolicy(
                max_workers=int(execution.get("max_workers", 4)),
                timeout_seconds=float(execution.get("timeout_seconds", 1800.0)),
                start_method=execution.get("start_method", "spawn"),
                hard_timeout_seconds=float(execution.get("hard_timeout_seconds", 21_600.0)),
            ),
            rollback_safe=bool(raw.get("rollback_safe", False)),
            remote_base=RemoteBaseTruthPolicy(
                mode=remote_mode,
                remote=str(remote.get("remote", "origin")),
                ref=remote.get("ref"),
                host=remote.get("host"),
                allow_local_filesystem_for_release=bool(remote.get("allow_local_filesystem_for_release", False)),
                timeout_seconds=float(remote.get("timeout_seconds", 15.0)),
            ),
            trust=TrustPolicy(
                require_asymmetric_release_signing=bool(trust.get("require_asymmetric_release_signing", True)),
                evidence_public_key_files=tuple(str(x) for x in trust.get("evidence_public_key_files", ())),
                break_glass_public_key_files=tuple(str(x) for x in trust.get("break_glass_public_key_files", ())),
                runner_public_key_files=tuple(str(x) for x in trust.get("runner_public_key_files", ())),
                vulnerability_public_key_files=tuple(str(x) for x in trust.get("vulnerability_public_key_files", ())),
                deployment_public_key_files=tuple(str(x) for x in trust.get("deployment_public_key_files", ())),
                require_runner_attestation_for_certification=bool(trust.get("require_runner_attestation_for_certification", True)),
                runner_attestation_env=str(trust.get("runner_attestation_env", "ADOS_RUNNER_ATTESTATION_FILE")),
                require_vulnerability_attestation_for_release=bool(trust.get("require_vulnerability_attestation_for_release", True)),
                vulnerability_attestation_env=str(trust.get("vulnerability_attestation_env", "ADOS_VULNERABILITY_ATTESTATION_FILE")),
                vulnerability_max_severity=str(trust.get("vulnerability_max_severity", "NONE")).upper(),
                require_deployment_attestation_for_health=bool(trust.get("require_deployment_attestation_for_health", True)),
                deployment_attestation_env=str(trust.get("deployment_attestation_env", "ADOS_DEPLOYMENT_ATTESTATION_FILE")),
                deployment_environment=str(trust.get("deployment_environment", "production")),
                allow_hmac_development=bool(trust.get("allow_hmac_development", True)),
                accepted_control_plane_versions=tuple(str(x) for x in trust.get("accepted_control_plane_versions", ())),
            ),
            evidence=EvidencePolicy(
                required_gates_ttl_seconds=int(evidence.get("required_gates_ttl_seconds", 86_400)),
                release_ttl_seconds=int(evidence.get("release_ttl_seconds", 86_400)),
                rollout_health_ttl_seconds=int(evidence.get("rollout_health_ttl_seconds", 1_800)),
                recovery_ttl_seconds=int(evidence.get("recovery_ttl_seconds", 3_600)),
            ),
            rollout=RolloutPolicy(
                health_required_tags=tuple(str(x) for x in rollout.get("health_required_tags", ("health", "candidate", "production"))),
            ),
            storage=StoragePolicy(
                mode=str(storage.get("mode", "single_node")),
                backend=str(storage.get("backend", "sqlite")),
            ),
            audit=AuditPolicy(
                require_external_anchor_for_release=bool(audit.get("require_external_anchor_for_release", True)),
                anchor_env=str(audit.get("anchor_env", "ADOS_AUDIT_ANCHOR_FILE")),
            ),
            strict_project_gates=bool(raw.get("strict_project_gates", True)),
            require_hermetic_build=bool(raw.get("require_hermetic_build", False)),
        )

    def __post_init__(self):
        if self.control_role != "controller_auditor":
            raise ValueError("ADOS reference kernel is a controller/auditor, not an autonomous product-planning brain")
        if self.repository_id is not None and (not self.repository_id.strip() or self.repository_id.startswith("/")):
            raise ValueError("repository_id must be a non-empty logical repository identity")
        if self.trust.vulnerability_max_severity not in {"NONE", "LOW", "MEDIUM", "HIGH", "CRITICAL"}:
            raise ValueError("trust.vulnerability_max_severity must be NONE|LOW|MEDIUM|HIGH|CRITICAL")
        if not self.trust.deployment_environment.strip():
            raise ValueError("trust.deployment_environment must be non-empty")


def policy_digest(root: Path, project: ProjectConfig | None = None) -> str:
    """Digest the trusted computing-base policy/config that influences certification."""
    root = root.resolve()
    rels = [
        ".ados/constitution.json",
        ".ados/impact.json",
        ".ados/project.json",
    ]
    if project is not None:
        rels.extend([project.adapter_manifest, project.command_manifest, project.build_manifest, ".ados/sbom.json"])
        rels.extend(project.trust.evidence_public_key_files)
        rels.extend(project.trust.break_glass_public_key_files)
        rels.extend(project.trust.runner_public_key_files)
        rels.extend(project.trust.vulnerability_public_key_files)
        rels.extend(project.trust.deployment_public_key_files)
    items: list[dict[str, str]] = []
    for rel in sorted(dict.fromkeys(rels)):
        p = (root / rel).resolve(strict=False)
        try:
            p.relative_to(root)
        except ValueError:
            raise ValueError(f"policy path escapes repository: {rel}")
        if not p.exists():
            items.append({"path": rel, "sha256": "MISSING"})
            continue
        if not p.is_file() or p.is_symlink():
            items.append({"path": rel, "sha256": "INVALID"})
            continue
        items.append({"path": rel, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
    material = json.dumps(items, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(material).hexdigest()


def certification_policy_digest(
    trusted_root: Path,
    candidate_root: Path,
    trusted_project: ProjectConfig,
    candidate_project: ProjectConfig,
) -> str:
    """Bind certification to both the currently trusted and proposed policy.

    Current work is judged by the already-anchored base policy.  Candidate TCB
    bytes are also bound so an approved policy transition cannot be swapped after
    review and so the resulting artifact can identify the exact future policy.
    """
    payload = {
        "trusted_policy": policy_digest(trusted_root, trusted_project),
        "candidate_policy": policy_digest(candidate_root, candidate_project),
    }
    material = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(material).hexdigest()
