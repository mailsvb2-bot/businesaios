from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import re

from .evidence import sign_evidence, sign_evidence_ed25519, task_security_context_hash
from .event_store import EventStore
from .models import Evidence
from .orchestrator import Assessment


class AssessmentNotReleasable(ValueError):
    pass


_SHA256_DIGEST_RE = re.compile(r"^sha256:[0-9a-f]{64}$")


def validate_artifact_digest(value: str) -> str:
    normalized = value.strip().lower()
    if not _SHA256_DIGEST_RE.fullmatch(normalized):
        raise AssessmentNotReleasable("artifact digest must use canonical sha256:<64 lowercase hex> format")
    return normalized


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def assessment_results_hash(assessment: Assessment) -> str:
    payload = [{"gate": r.gate, "status": r.status.value, "reason": r.reason, "details": r.details}
               for r in sorted(assessment.gate_results, key=lambda r: r.gate)]
    material = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
    return "sha256:" + hashlib.sha256(material).hexdigest()


def _validate_ttl(ttl_seconds: int | None) -> None:
    if ttl_seconds is None: return
    if ttl_seconds <= 0: raise AssessmentNotReleasable("evidence ttl_seconds must be > 0")
    if ttl_seconds > 86_400: raise AssessmentNotReleasable("evidence ttl_seconds may not exceed 86400 seconds")


def _sign(ev: Evidence, *, signing_secret: bytes | None, private_key_pem: bytes | None) -> Evidence:
    if private_key_pem is not None:
        return sign_evidence_ed25519(ev, private_key_pem)
    if signing_secret is not None:
        return sign_evidence(ev, signing_secret)
    raise AssessmentNotReleasable("evidence signer unavailable")


def build_required_gates_evidence(
    assessment: Assessment, *, signing_secret: bytes | None = None, private_key_pem: bytes | None = None,
    context_hash: str | None = None, inputs_hash: str | None = None, policy_digest: str | None = None,
    ttl_seconds: int | None = 3600,
) -> Evidence:
    if assessment.release_blockers:
        raise AssessmentNotReleasable("cannot certify assessment with blockers: " + ", ".join(f"{r.gate}={r.status.value}" for r in assessment.release_blockers))
    if assessment.task.blockers:
        raise AssessmentNotReleasable("cannot certify task with durable blockers: " + ", ".join(sorted(assessment.task.blockers)))
    candidate = assessment.task.candidate
    if candidate is None: raise AssessmentNotReleasable("task has no exact candidate")
    _validate_ttl(ttl_seconds)
    context_hash = context_hash or task_security_context_hash(assessment.task)
    inputs_hash = inputs_hash or assessment_results_hash(assessment)
    ev = Evidence(
        claim="required_gates_passed", repository=candidate.repository, subject_sha=candidate.sha,
        subject_tree=candidate.tree, generation=candidate.generation, source="ados_control_plane", conclusion="pass",
        verified_at=_now(), context_hash=context_hash, inputs_hash=inputs_hash,
        tags=tuple(sorted(r.gate for r in assessment.gate_results if r.status.value == "PASS")),
        ttl_seconds=ttl_seconds, policy_digest=policy_digest,
    )
    return _sign(ev, signing_secret=signing_secret, private_key_pem=private_key_pem)


def record_required_gates_evidence(store: EventStore, assessment: Assessment, **kwargs) -> Evidence:
    signed = build_required_gates_evidence(assessment, **kwargs); store.record_evidence(signed); return signed


def build_release_verified_evidence(
    *, repository: str, sha: str, tree: str | None, generation: int,
    signing_secret: bytes | None = None, private_key_pem: bytes | None = None,
    artifact_digest: str, context_hash: str | None = None, inputs_hash: str | None = None,
    policy_digest: str | None = None, provenance_digest: str | None = None,
    ttl_seconds: int | None = 3600,
) -> Evidence:
    _validate_ttl(ttl_seconds); artifact_digest = validate_artifact_digest(artifact_digest)
    if not provenance_digest:
        raise AssessmentNotReleasable("release_verified requires signed build provenance digest")
    ev = Evidence(
        claim="release_verified", repository=repository, subject_sha=sha, subject_tree=tree, generation=generation,
        source="ados_control_plane", conclusion="pass", verified_at=_now(), artifact_digest=artifact_digest,
        context_hash=context_hash, inputs_hash=inputs_hash, ttl_seconds=ttl_seconds,
        policy_digest=policy_digest, provenance_digest=provenance_digest,
        tags=("artifact", "provenance", "release"),
    )
    return _sign(ev, signing_secret=signing_secret, private_key_pem=private_key_pem)



def build_operational_evidence(
    *, claim: str, repository: str, sha: str, tree: str | None, generation: int,
    gate: str, gate_status: str, gate_reason: str, private_key_pem: bytes,
    context_hash: str, policy_digest: str, tags: tuple[str, ...], ttl_seconds: int,
    external_evidence_digest: str | None = None, artifact_digest: str | None = None,
) -> Evidence:
    _validate_ttl(ttl_seconds)
    if gate_status != "PASS":
        raise AssessmentNotReleasable(f"{claim} requires measured {gate} PASS, got {gate_status}: {gate_reason}")
    payload = {
        "gate": gate, "status": gate_status, "reason": gate_reason,
        "external_evidence_digest": external_evidence_digest, "artifact_digest": artifact_digest,
    }
    inputs_hash = "sha256:" + hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()
    ev = Evidence(
        claim=claim, repository=repository, subject_sha=sha, subject_tree=tree, generation=generation,
        source="ados_control_plane", conclusion="pass", verified_at=_now(), context_hash=context_hash,
        inputs_hash=inputs_hash, tags=tuple(sorted(set(tags) | {gate, "measured"})),
        ttl_seconds=ttl_seconds, policy_digest=policy_digest, artifact_digest=artifact_digest,
    )
    return sign_evidence_ed25519(ev, private_key_pem)

def record_release_verified(store: EventStore, **kwargs) -> Evidence:
    signed = build_release_verified_evidence(**kwargs); store.record_evidence(signed); return signed
