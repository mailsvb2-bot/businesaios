from __future__ import annotations

from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path
from typing import Iterable

from .models import DevelopmentLane, RiskLevel
from .risk import RiskRule
from .util import load_json


DEFAULT_GATES_BY_RISK = {
    RiskLevel.LOW: {"source", "safety"},
    RiskLevel.MEDIUM: {"source", "safety", "architecture", "tests"},
    RiskLevel.HIGH: {"source", "safety", "architecture", "tests", "security"},
    RiskLevel.CRITICAL: {"source", "safety", "architecture", "tests", "security", "red_team"},
}


@dataclass
class ImpactModel:
    component_patterns: dict[str, list[str]]
    dependencies: dict[str, list[str]]
    component_gates: dict[str, list[str]]
    risk_overrides: tuple[RiskRule, ...] = ()

    @classmethod
    def from_file(cls, path: str | Path) -> "ImpactModel":
        raw = load_json(path)
        overrides: list[RiskRule] = []
        for item in raw.get("risk_overrides", []):
            if not isinstance(item, dict) or not item.get("pattern") or not item.get("reason"):
                raise ValueError("risk_overrides entries require pattern, level, and reason")
            overrides.append(RiskRule(
                str(item["pattern"]), RiskLevel(str(item["level"]).upper()), str(item["reason"]),
                bool(item.get("allow_downgrade", False)),
            ))
        return cls(
            component_patterns=raw.get("component_patterns", {}),
            dependencies=raw.get("dependencies", {}),
            component_gates=raw.get("component_gates", {}),
            risk_overrides=tuple(overrides),
        )

    def direct_components(self, files: Iterable[str]) -> set[str]:
        changed = list(files)
        direct: set[str] = set()
        for component, patterns in self.component_patterns.items():
            if any(any(fnmatch(path, pattern) for pattern in patterns) for path in changed):
                direct.add(component)
        return direct

    def unmatched_files(self, files: Iterable[str]) -> set[str]:
        changed = set(files)
        matched: set[str] = set()
        for patterns in self.component_patterns.values():
            for path in changed:
                if any(fnmatch(path, pattern) for pattern in patterns):
                    matched.add(path)
        # Documentation and ADOS policy are handled by generic/core gates and do
        # not force a full product regression merely because the component graph
        # is intentionally product-focused.
        return {
            p for p in changed - matched
            if not p.endswith((".md", ".txt")) and not p.startswith(".ados/") and not p.startswith(".github/")
        }

    def affected_components(self, files: Iterable[str]) -> set[str]:
        direct = self.direct_components(files)
        affected = set(direct)
        changed_flag = True
        while changed_flag:
            changed_flag = False
            for consumer, deps in self.dependencies.items():
                if any(dep in affected for dep in deps) and consumer not in affected:
                    affected.add(consumer)
                    changed_flag = True
        return affected

    def required_gates(self, files: Iterable[str], risk: RiskLevel, lane: DevelopmentLane = DevelopmentLane.RELEASE) -> set[str]:
        files = tuple(files)
        affected = self.affected_components(files)
        if lane is DevelopmentLane.DEVELOPMENT:
            gates = {"source", "safety"}
            if any(p.startswith(".github/workflows/") for p in files):
                gates.add("supply_chain")
            if any(p.startswith(".ados/") or p.startswith(".github/workflows/") or p == "CODEOWNERS" for p in files):
                gates.add("governance")
            return gates

        gates = set(DEFAULT_GATES_BY_RISK[risk])
        for component in affected:
            gates.update(self.component_gates.get(component, []))
        if self.unmatched_files(files):
            # An incomplete impact graph is never allowed to optimize away the full
            # project regression in merge/release lanes.
            gates.add("full_regression")
        if any(p.startswith(".ados/") or p.startswith(".github/workflows/") or p == "CODEOWNERS" for p in files):
            gates.add("governance")
        if any(
            p.startswith(".github/workflows/")
            or p.endswith(("lock", ".lock"))
            or p in {"pyproject.toml", "package.json", "Cargo.toml", "requirements.txt", "requirements.lock"}
            for p in files
        ):
            gates.add("supply_chain")
        if lane is DevelopmentLane.RELEASE:
            # Release is intentionally exhaustive: impact optimization may add
            # targeted checks, but it may never optimize away the canonical
            # full regression or dependency/supply-chain verification.
            gates.update({"release", "supply_chain", "full_regression", "dependency_audit"})
        return gates
