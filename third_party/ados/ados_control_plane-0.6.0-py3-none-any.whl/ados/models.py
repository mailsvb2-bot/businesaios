from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Iterable


class TaskState(str, Enum):
    READY = "READY"
    WORKING = "WORKING"
    VALIDATING = "VALIDATING"
    BLOCKED = "BLOCKED"
    READY_TO_RELEASE = "READY_TO_RELEASE"
    RELEASING = "RELEASING"
    CANARY = "CANARY"
    PARTIALLY_DEPLOYED = "PARTIALLY_DEPLOYED"
    DEGRADED = "DEGRADED"
    RECOVERING = "RECOVERING"
    ROLLED_BACK = "ROLLED_BACK"
    ABORTED = "ABORTED"
    SUPERSEDED = "SUPERSEDED"
    DONE = "DONE"


class DevelopmentLane(str, Enum):
    """How aggressively ADOS is allowed to block work.

    DEVELOPMENT is intentionally fast/advisory: semantic UNKNOWN gates are reported
    but do not stop iteration. MERGE is strict for project tests/contracts. RELEASE is
    the strongest lane and requires complete project evidence/provenance.
    """

    DEVELOPMENT = "DEVELOPMENT"
    MERGE = "MERGE"
    RELEASE = "RELEASE"


class ClaimKind(str, Enum):
    OBSERVED = "OBSERVED"
    DERIVED = "DERIVED"
    ASSUMED = "ASSUMED"
    UNKNOWN = "UNKNOWN"


class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class GateStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    SKIP = "SKIP"
    UNKNOWN = "UNKNOWN"


class ActionDecision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    REQUIRE_APPROVAL = "REQUIRE_APPROVAL"


class ExecutionKind(str, Enum):
    READ_ONLY = "READ_ONLY"
    IDEMPOTENT = "IDEMPOTENT"
    SIDE_EFFECTING = "SIDE_EFFECTING"


@dataclass(frozen=True)
class Candidate:
    repository: str
    branch: str
    sha: str
    tree: str | None = None
    generation: int = 1


@dataclass(frozen=True)
class Evidence:
    claim: str
    repository: str
    subject_sha: str
    source: str
    conclusion: str
    verified_at: str
    subject_tree: str | None = None
    generation: int | None = None
    run_id: str | None = None
    artifact_digest: str | None = None
    context_hash: str | None = None
    inputs_hash: str | None = None
    tags: tuple[str, ...] = ()
    ttl_seconds: int | None = None
    signature: str | None = None
    signature_algorithm: str = "hmac-sha256"
    signer_id: str | None = None
    control_plane_version: str | None = None
    policy_digest: str | None = None
    provenance_digest: str | None = None


@dataclass(frozen=True)
class Claim:
    text: str
    kind: ClaimKind
    evidence_claim: str | None = None


@dataclass
class Task:
    task_id: str
    repository: str
    goal: str
    base_sha: str | None = None
    base_ref: str | None = None
    state: TaskState = TaskState.READY
    candidate: Candidate | None = None
    risk: RiskLevel = RiskLevel.MEDIUM
    affected_components: set[str] = field(default_factory=set)
    required_gates: set[str] = field(default_factory=set)
    blockers: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def lane(self) -> DevelopmentLane:
        raw = self.metadata.get("lane", DevelopmentLane.DEVELOPMENT.value)
        try:
            return DevelopmentLane(str(raw).upper())
        except ValueError:
            return DevelopmentLane.DEVELOPMENT

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["state"] = self.state.value
        data["risk"] = self.risk.value
        data["affected_components"] = sorted(self.affected_components)
        data["required_gates"] = sorted(self.required_gates)
        data["lane"] = self.lane.value
        return data


@dataclass(frozen=True)
class Lease:
    task_id: str
    scope: str
    holder: str
    generation: int
    expires_at: str
    fencing_token: int = 0


@dataclass(frozen=True)
class GateResult:
    gate: str
    status: GateStatus
    reason: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ActionRequest:
    action: str
    actor_role: str
    environment: str = "dev"
    branch: str | None = None
    command: str | None = None
    capability: str | None = None
    changed_files: tuple[str, ...] = ()
    deleted_files: int = 0
    deleted_lines: int = 0
    total_changed_lines: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PolicyResult:
    decision: ActionDecision
    reason: str
    rule_id: str | None = None


def enum_values(items: Iterable[Enum]) -> list[str]:
    return [x.value for x in items]
