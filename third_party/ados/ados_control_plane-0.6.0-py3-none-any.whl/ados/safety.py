from __future__ import annotations

import re
from dataclasses import dataclass

from .models import ActionDecision, ActionRequest, PolicyResult


# Regexes remain defense-in-depth diagnostics only. Production mutation should use
# typed capabilities; raw production shell is denied below because regexes can
# never enumerate every destructive spelling/wrapper.
DESTRUCTIVE_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("shell_rm_recursive_force", re.compile(r"(?:^|\s)rm\s+(?=[^\n]*(?:-\S*r\S*|-\S*R\S*|--recursive))(?=[^\n]*(?:-\S*f\S*|--force))[^\n]*", re.I)),
    ("find_delete", re.compile(r"\bfind\b[^\n]*\s-delete\b", re.I)),
    ("windows_rmdir_recursive", re.compile(r"\b(?:rmdir|rd)\b[^\n]*/s\b", re.I)),
    ("powershell_remove_recursive", re.compile(r"\bRemove-Item\b[^\n]*(?:-Recurse)[^\n]*(?:-Force)|\bRemove-Item\b[^\n]*(?:-Force)[^\n]*(?:-Recurse)", re.I)),
    ("git_force_push", re.compile(r"\bgit\s+push\b[^\n]*(--force(?:-with-lease)?|-f)\b", re.I)),
    ("git_clean", re.compile(r"\bgit\s+clean\b[^\n]*(?:-[a-z]*f[a-z]*x|-[a-z]*x[a-z]*f|--force)[^\n]*", re.I)),
    ("git_reset_hard", re.compile(r"\bgit\s+reset\s+--hard\b", re.I)),
    ("git_delete_branch", re.compile(r"\bgit\s+branch\s+-D\b", re.I)),
    ("git_delete_ref", re.compile(r"\bgit\s+update-ref\s+-d\b", re.I)),
    ("github_repo_delete", re.compile(r"\bgh\s+repo\s+delete\b", re.I)),
    ("drop_database", re.compile(r"\bDROP\s+DATABASE\b", re.I)),
    ("drop_schema", re.compile(r"\bDROP\s+SCHEMA\b", re.I)),
    ("drop_table", re.compile(r"\bDROP\s+TABLE\b", re.I)),
    ("truncate", re.compile(r"\bTRUNCATE(?:\s+TABLE)?\b", re.I)),
    ("delete_without_where", re.compile(r"\bDELETE\s+FROM\s+[\w.]+\s*(?:;|$)", re.I)),
    ("delete_tautology", re.compile(r"\bDELETE\s+FROM\s+[\w.]+\s+WHERE\s+(?:1\s*=\s*1|TRUE)\b", re.I)),
    ("terraform_destroy", re.compile(r"\bterraform\s+destroy\b", re.I)),
    ("kubectl_delete_namespace", re.compile(r"\bkubectl\s+delete\s+(?:namespace|ns)\b", re.I)),
    ("kubectl_delete_all", re.compile(r"\bkubectl\s+delete\b[^\n]*--all\b", re.I)),
    ("docker_system_prune", re.compile(r"\bdocker\s+system\s+prune\b", re.I)),
    ("docker_volume_prune", re.compile(r"\bdocker\s+volume\s+prune\b", re.I)),
    ("aws_recursive_delete", re.compile(r"\baws\s+s3\s+rm\b[^\n]*--recursive\b", re.I)),
    ("gcloud_recursive_delete", re.compile(r"\bgcloud\s+(?:storage|alpha\s+storage)\s+rm\b[^\n]*--recursive\b", re.I)),
    ("azure_delete_batch", re.compile(r"\baz\s+storage\s+blob\s+delete-batch\b", re.I)),
)

READ_ONLY_PRODUCTION_CAPABILITIES = {
    "health.read", "logs.read", "metrics.read", "deployment.status", "db.schema.read", "git.read",
}
MUTATING_PRODUCTION_CAPABILITIES = {
    "deployment.apply", "deployment.rollback", "feature_flag.write", "db.migrate", "message.send", "resource.delete",
}


@dataclass(frozen=True)
class DeletionBudget:
    max_files_deleted: int = 5
    max_deleted_line_ratio: float = 0.20


def inspect_destructive_command(command: str | None) -> list[str]:
    if not command: return []
    return [rule for rule, pattern in DESTRUCTIVE_PATTERNS if pattern.search(command)]


def evaluate_deletion_budget(req: ActionRequest, budget: DeletionBudget) -> PolicyResult:
    if req.deleted_files < 0 or req.deleted_lines < 0 or req.total_changed_lines < 0:
        return PolicyResult(ActionDecision.DENY, "negative deletion counters are invalid", "INVALID_DELETION_COUNTERS")
    if req.deleted_files > budget.max_files_deleted:
        return PolicyResult(ActionDecision.REQUIRE_APPROVAL, f"large cleanup/refactor signal: deleted_files={req.deleted_files} exceeds review threshold={budget.max_files_deleted}", "DELETION_FILE_BUDGET")
    if req.total_changed_lines > 0:
        ratio = req.deleted_lines / req.total_changed_lines
        if ratio > budget.max_deleted_line_ratio:
            return PolicyResult(ActionDecision.REQUIRE_APPROVAL, f"large cleanup/refactor signal: deleted_line_ratio={ratio:.2%} exceeds threshold={budget.max_deleted_line_ratio:.2%}", "DELETION_LINE_BUDGET")
    elif req.deleted_lines > 0:
        return PolicyResult(ActionDecision.REQUIRE_APPROVAL, "deleted lines reported without total_changed_lines", "INCOMPLETE_DELETION_ACCOUNTING")
    return PolicyResult(ActionDecision.ALLOW, "deletion review threshold satisfied")


def destructive_guard(req: ActionRequest) -> PolicyResult:
    env = req.environment.lower()
    if env in {"prod", "production"}:
        if req.action == "shell":
            return PolicyResult(ActionDecision.DENY, "raw production shell is prohibited; use a typed capability", "PRODUCTION_SHELL_DENY")
        if req.capability:
            if req.capability in READ_ONLY_PRODUCTION_CAPABILITIES:
                return PolicyResult(ActionDecision.ALLOW, f"typed read-only production capability {req.capability} allowed")
            if req.capability in MUTATING_PRODUCTION_CAPABILITIES:
                return PolicyResult(ActionDecision.REQUIRE_APPROVAL, f"mutating production capability {req.capability} requires explicit authorization/fencing", "PRODUCTION_MUTATION_CAPABILITY")
            return PolicyResult(ActionDecision.DENY, f"unknown production capability {req.capability!r} fails closed", "UNKNOWN_PRODUCTION_CAPABILITY")
    hits = inspect_destructive_command(req.command)
    if hits:
        return PolicyResult(ActionDecision.REQUIRE_APPROVAL, f"destructive development action requires controlled exception: {', '.join(hits)}", "DESTRUCTIVE_ACTION_APPROVAL")
    return PolicyResult(ActionDecision.ALLOW, "no uncontrolled destructive capability detected")
