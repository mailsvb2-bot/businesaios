from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .crypto import sign_ed25519, verify_ed25519
from .models import Candidate


class RunnerAttestationError(ValueError):
    pass


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise RunnerAttestationError("runner attestation timestamps must be timezone-aware")
    return parsed.astimezone(timezone.utc)


def _canonical(data: dict[str, Any]) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


@dataclass(frozen=True)
class RunnerAttestation:
    schema_version: int
    repository: str
    subject_sha: str
    subject_tree: str
    runner_id: str
    isolation: str
    filesystem_policy: str
    network_policy: str
    issued_at: str
    expires_at: str
    nonce: str
    signer_id: str | None = None
    signature: str | None = None

    def unsigned_payload(self) -> bytes:
        data = asdict(self)
        data.pop("signature", None)
        return _canonical(data)

    def digest(self) -> str:
        return "sha256:" + hashlib.sha256(_canonical(asdict(self))).hexdigest()

    def signed(self, private_key_pem: bytes) -> "RunnerAttestation":
        prepared = replace(self, signer_id=None, signature=None)
        _, signer_id = sign_ed25519(b"ados-runner-attestation-key", private_key_pem)
        prepared = replace(prepared, signer_id=signer_id)
        signature, actual = sign_ed25519(prepared.unsigned_payload(), private_key_pem)
        if actual != signer_id:
            raise RunnerAttestationError("runner attestation signer identity changed")
        return replace(prepared, signature=signature)

    def verify(self, keys: dict[str, bytes]) -> bool:
        if not self.signature or not self.signer_id:
            return False
        key = keys.get(self.signer_id)
        return bool(key and verify_ed25519(self.unsigned_payload(), self.signature, key))

    def to_file(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), sort_keys=True, indent=2) + "\n", encoding="utf-8")

    @classmethod
    def issue(
        cls, *, repository: str, candidate: Candidate, runner_id: str,
        nonce: str, private_key_pem: bytes, ttl_seconds: int = 1800,
        isolation: str = "disposable", filesystem_policy: str = "ephemeral",
        network_policy: str = "denied_or_allowlisted",
    ) -> "RunnerAttestation":
        if not 60 <= ttl_seconds <= 3600:
            raise RunnerAttestationError("runner attestation ttl_seconds must be between 60 and 3600")
        if isolation != "disposable":
            raise RunnerAttestationError("strict runner attestation requires isolation='disposable'")
        if filesystem_policy != "ephemeral":
            raise RunnerAttestationError("strict runner attestation requires filesystem_policy='ephemeral'")
        if network_policy not in {"denied", "allowlisted", "denied_or_allowlisted"}:
            raise RunnerAttestationError("invalid runner network policy")
        if not runner_id or not nonce:
            raise RunnerAttestationError("runner_id and nonce are required")
        now = _now()
        return cls(
            schema_version=1, repository=repository, subject_sha=candidate.sha,
            subject_tree=candidate.tree or "", runner_id=runner_id,
            isolation=isolation, filesystem_policy=filesystem_policy,
            network_policy=network_policy, issued_at=_iso(now),
            expires_at=_iso(now + timedelta(seconds=ttl_seconds)), nonce=nonce,
        ).signed(private_key_pem)

    @classmethod
    def from_file(cls, path: str | Path) -> "RunnerAttestation":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise RunnerAttestationError("runner attestation must be an object")
        return cls(**raw)


def verify_runner_attestation(
    attestation: RunnerAttestation, *, keys: dict[str, bytes], repository: str,
    candidate: Candidate, max_clock_skew_seconds: int = 300,
    at_time: datetime | None = None,
) -> None:
    if attestation.schema_version != 1:
        raise RunnerAttestationError("unsupported runner attestation schema")
    if not attestation.verify(keys):
        raise RunnerAttestationError("runner attestation signature is invalid or signer is not trusted")
    if attestation.repository != repository:
        raise RunnerAttestationError("runner attestation repository mismatch")
    if (attestation.subject_sha, attestation.subject_tree) != (candidate.sha, candidate.tree or ""):
        raise RunnerAttestationError("runner attestation candidate mismatch")
    if attestation.isolation != "disposable" or attestation.filesystem_policy != "ephemeral":
        raise RunnerAttestationError("runner attestation does not promise disposable ephemeral isolation")
    if attestation.network_policy not in {"denied", "allowlisted", "denied_or_allowlisted"}:
        raise RunnerAttestationError("runner attestation network policy is not acceptable")
    now = _now(); observed = (at_time or now).astimezone(timezone.utc)
    issued = _parse(attestation.issued_at); expires = _parse(attestation.expires_at)
    if expires <= issued or (expires - issued).total_seconds() > 3600:
        raise RunnerAttestationError("runner attestation lifetime is invalid")
    if issued > observed + timedelta(seconds=max_clock_skew_seconds):
        raise RunnerAttestationError("runner attestation is from the future")
    if expires <= observed:
        raise RunnerAttestationError("runner attestation expired at the attested operation time")
    if at_time is None and expires <= now:
        raise RunnerAttestationError("runner attestation expired")
