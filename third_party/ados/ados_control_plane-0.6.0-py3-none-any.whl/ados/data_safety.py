from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any

from .models import ActionDecision, PolicyResult


class DataClass(IntEnum):
    PUBLIC = 0
    INTERNAL = 1
    CONFIDENTIAL = 2
    PII = 3
    SECRET = 4
    HIGHLY_SENSITIVE = 5


@dataclass(frozen=True)
class DataPolicy:
    max_class_for_cloud_agent: DataClass = DataClass.CONFIDENTIAL
    production_data_in_sandbox: bool = False
    require_redaction_from: DataClass = DataClass.PII


def may_send_to_cloud(data_class: DataClass, policy: DataPolicy) -> PolicyResult:
    if data_class > policy.max_class_for_cloud_agent:
        return PolicyResult(ActionDecision.DENY, f"{data_class.name} exceeds cloud-agent allowance", "DATA_EGRESS_CLASSIFICATION")
    return PolicyResult(ActionDecision.ALLOW, "data class permitted")


def may_use_in_agent_sandbox(data_class: DataClass, is_production_data: bool, policy: DataPolicy) -> PolicyResult:
    if is_production_data and not policy.production_data_in_sandbox:
        return PolicyResult(ActionDecision.DENY, "production data forbidden in agent sandbox; use synthetic/anonymized data", "NO_PRODUCTION_DATA_IN_SANDBOX")
    if data_class >= DataClass.PII:
        return PolicyResult(ActionDecision.REQUIRE_APPROVAL, "sensitive data requires anonymization/redaction policy", "SENSITIVE_DATA_SANDBOX")
    return PolicyResult(ActionDecision.ALLOW, "sandbox data allowed")


SENSITIVE_LOG_KEYS = {
    "authorization", "cookie", "password", "token", "secret", "api_key", "apikey",
    "medical_data", "medicaldata", "ssn", "access_token", "refresh_token", "client_secret",
}


def _sensitive_key(key: str) -> bool:
    normalized = key.lower().replace("-", "_").replace(" ", "_")
    collapsed = normalized.replace("_", "")
    return (
        normalized in SENSITIVE_LOG_KEYS
        or collapsed in SENSITIVE_LOG_KEYS
        or any(piece in normalized for piece in ("password", "token", "secret", "authorization", "cookie"))
    )


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: ("[REDACTED]" if _sensitive_key(str(k)) else _redact(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_redact(v) for v in value)
    return value


def redact_record(record: dict[str, object]) -> dict[str, object]:
    return _redact(record)
