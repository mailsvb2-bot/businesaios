from __future__ import annotations

from copy import deepcopy
from typing import Any

from .rollout import ProductProfile


PROFILE_COMPONENTS: dict[ProductProfile, dict[str, dict[str, list[str]]]] = {
    ProductProfile.WEB_SAAS: {
        "patterns": {
            "tenant": ["**/tenant/**", "**/tenancy/**", "**/workspace/**", "**/workspaces/**"],
        },
        "gates": {
            "tenant": ["tenant_isolation"],
        },
    },
    ProductProfile.DESKTOP: {
        "patterns": {
            "installer": ["**/installer/**", "**/*.nsi", "**/tauri.conf.json", "**/updater/**"],
        },
        "gates": {
            "installer": ["release", "user_journey"],
        },
    },
    ProductProfile.RUNTIME_LIBRARY: {
        "patterns": {
            "protocol": ["**/proto/**", "**/*.proto", "**/grpc/**", "**/contracts/**"],
        },
        "gates": {
            "protocol": ["contracts", "compatibility"],
        },
    },
    ProductProfile.BOT: {
        "patterns": {
            "messaging": ["**/bot/**", "**/handlers/**", "**/webhook/**", "**/messaging/**"],
        },
        "gates": {
            "messaging": ["integration", "user_journey"],
        },
    },
    ProductProfile.DOCUMENT_ENGINE: {
        "patterns": {
            "documents": ["**/templates/**", "**/documents/**", "**/*.docx", "**/diary/**", "**/diaries/**"],
        },
        "gates": {
            "documents": ["golden", "user_journey"],
        },
    },
    ProductProfile.BACKEND_SERVICE: {"patterns": {}, "gates": {}},
}


def impact_for_profile(base: dict[str, Any], profile: ProductProfile) -> dict[str, Any]:
    result = deepcopy(base)
    pack = PROFILE_COMPONENTS[profile]
    result.setdefault("component_patterns", {}).update(deepcopy(pack["patterns"]))
    result.setdefault("component_gates", {}).update(deepcopy(pack["gates"]))
    return result
