from __future__ import annotations

import json
from datetime import timedelta
from dataclasses import dataclass, field
from enum import Enum

from .event_store import ConcurrencyConflict, EventStore, LeaseConflict, _iso, _parse, _utcnow
from .models import ExecutionKind


@dataclass
class ScheduledTask:
    task_id: str
    components: set[str]
    dependencies: set[str] = field(default_factory=set)
    priority: int = 0
    execution_kind: ExecutionKind = ExecutionKind.READ_ONLY
    idempotency_key: str | None = None


def conflicts(a: ScheduledTask, b: ScheduledTask) -> bool:
    # An omitted component set must never accidentally grant parallel writes.
    if not a.components or not b.components:
        return a.execution_kind is not ExecutionKind.READ_ONLY or b.execution_kind is not ExecutionKind.READ_ONLY
    return bool(a.components & b.components)


def ready_tasks(tasks: list[ScheduledTask], done: set[str], running: list[ScheduledTask], limit: int = 4) -> list[ScheduledTask]:
    candidates = [t for t in tasks if t.dependencies <= done and t.task_id not in done]
    candidates.sort(key=lambda t: (-t.priority, t.task_id))
    selected: list[ScheduledTask] = []
    for task in candidates:
        if any(r.task_id == task.task_id for r in running):
            continue
        if any(conflicts(task, r) for r in running + selected):
            continue
        selected.append(task)
        if len(selected) >= limit:
            break
    return selected


class ScheduleStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    ORPHANED = "ORPHANED"
    DONE = "DONE"


@dataclass(frozen=True)
class StoredScheduledTask:
    task: ScheduledTask
    status: ScheduleStatus
    holder: str | None
    lease_expires_at: str | None
    version: int
    fencing_token: int = 0
    attempts: int = 0
    created_at: str | None = None


def _dependency_cycle(tasks: list[ScheduledTask]) -> list[str] | None:
    graph = {t.task_id: set(t.dependencies) for t in tasks}
    visiting: set[str] = set(); visited: set[str] = set(); path: list[str] = []
    def visit(node: str) -> list[str] | None:
        if node in visited: return None
        if node in visiting:
            try: idx = path.index(node)
            except ValueError: idx = 0
            return path[idx:] + [node]
        visiting.add(node); path.append(node)
        for dep in sorted(graph.get(node, ())):
            if dep not in graph: continue
            cycle = visit(dep)
            if cycle: return cycle
        path.pop(); visiting.remove(node); visited.add(node); return None
    for node in sorted(graph):
        cycle = visit(node)
        if cycle: return cycle
    return None


def _linked_journal_state(cx, task_id: str) -> str | None:
    row = cx.execute(
        """SELECT event_type,payload_json FROM task_events
           WHERE task_id=? AND event_type IN ('TASK_CREATED','STATE_TRANSITIONED')
           ORDER BY id DESC LIMIT 1""", (task_id,)
    ).fetchone()
    if row is None: return None
    payload = json.loads(row["payload_json"])
    return str(payload["to"] if row["event_type"] == "STATE_TRANSITIONED" else payload.get("state", "READY"))


class PersistentScheduler:
    """Durable scheduler with fencing and side-effect-aware lease recovery.

    READ_ONLY and explicitly IDEMPOTENT work may be retried after expiry. A
    SIDE_EFFECTING task becomes ORPHANED instead: an external reconciliation step
    must decide whether the effect committed before any retry is possible.
    """
    def __init__(self, store: EventStore, *, allowed_components: set[str] | frozenset[str] | None = None):
        self.store = store
        self.allowed_components = None if allowed_components is None else set(allowed_components)

    @staticmethod
    def _from_row(row) -> StoredScheduledTask:
        return StoredScheduledTask(
            ScheduledTask(
                row["task_id"], set(json.loads(row["components_json"])), set(json.loads(row["dependencies_json"])),
                int(row["priority"]), ExecutionKind(row["execution_kind"]), row["idempotency_key"],
            ),
            ScheduleStatus(row["status"]), row["holder"], row["lease_expires_at"], int(row["version"]),
            int(row["fencing_token"]), int(row["attempts"]), row["created_at"],
        )

    def get(self, task_id: str) -> StoredScheduledTask | None:
        with self.store.session() as cx:
            row = cx.execute("SELECT * FROM scheduled_tasks WHERE task_id=?", (task_id,)).fetchone()
        return None if row is None else self._from_row(row)

    def add(self, task: ScheduledTask) -> StoredScheduledTask:
        if not task.task_id: raise ValueError("task_id is required")
        if task.task_id in task.dependencies: raise ValueError("task cannot depend on itself")
        if task.priority < -100 or task.priority > 100: raise ValueError("priority must be between -100 and 100")
        if task.execution_kind is not ExecutionKind.READ_ONLY and not task.components:
            raise ValueError("write-capable scheduled tasks require explicit conflict components")
        if self.allowed_components is not None:
            unknown = task.components - self.allowed_components
            if unknown:
                raise ValueError(f"scheduled task uses unknown conflict components: {sorted(unknown)}")
        if task.execution_kind is not ExecutionKind.READ_ONLY and not task.idempotency_key:
            raise ValueError("write-capable scheduled tasks require an idempotency_key")
        now = _iso(_utcnow())
        components = json.dumps(sorted(task.components), separators=(",", ":")); dependencies = json.dumps(sorted(task.dependencies), separators=(",", ":"))
        with self.store.session() as cx:
            cx.execute("BEGIN IMMEDIATE")
            row = cx.execute("SELECT * FROM scheduled_tasks WHERE task_id=?", (task.task_id,)).fetchone()
            if row is not None:
                existing = self._from_row(row)
                if existing.task == task: return existing
                raise ConcurrencyConflict(f"scheduled task {task.task_id!r} already exists with a different specification")
            candidate_graph = [self._from_row(r).task for r in cx.execute("SELECT * FROM scheduled_tasks").fetchall()] + [task]
            cycle = _dependency_cycle(candidate_graph)
            if cycle: raise ValueError(f"scheduler dependency cycle: {' -> '.join(cycle)}")
            cx.execute(
                """INSERT INTO scheduled_tasks(
                       task_id,components_json,dependencies_json,priority,execution_kind,idempotency_key,status,holder,
                       lease_expires_at,fencing_token,attempts,version,created_at,updated_at
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (task.task_id, components, dependencies, task.priority, task.execution_kind.value, task.idempotency_key,
                 ScheduleStatus.PENDING.value, None, None, 0, 0, 1, now, now),
            )
            self.store.append_control_event(f"scheduler:{task.task_id}", "SCHEDULED_TASK_ADDED", {
                "task_id": task.task_id, "components": sorted(task.components), "dependencies": sorted(task.dependencies),
                "priority": task.priority, "execution_kind": task.execution_kind.value, "idempotency_key": task.idempotency_key, "version": 1,
            }, connection=cx)
        stored = self.get(task.task_id); assert stored is not None; return stored

    def list(self) -> list[StoredScheduledTask]:
        with self.store.session() as cx: rows = cx.execute("SELECT * FROM scheduled_tasks ORDER BY priority DESC, task_id").fetchall()
        return [self._from_row(row) for row in rows]

    def _recover_expired(self, cx, now) -> None:
        rows = cx.execute("SELECT * FROM scheduled_tasks WHERE status=?", (ScheduleStatus.RUNNING.value,)).fetchall()
        now_iso = _iso(now)
        for row in rows:
            expiry = row["lease_expires_at"]
            if expiry and _parse(expiry) > now: continue
            current = self._from_row(row)
            if current.task.execution_kind is ExecutionKind.SIDE_EFFECTING:
                new_status = ScheduleStatus.ORPHANED
                event = "SCHEDULE_SIDE_EFFECT_ORPHANED"
            else:
                new_status = ScheduleStatus.PENDING
                event = "SCHEDULE_CLAIM_EXPIRED"
            cx.execute(
                """UPDATE scheduled_tasks SET status=?,holder=NULL,lease_expires_at=NULL,version=?,updated_at=?
                   WHERE task_id=? AND version=?""",
                (new_status.value, current.version + 1, now_iso, current.task.task_id, current.version),
            )
            self.store.append_control_event(f"scheduler:{current.task.task_id}", event, {
                "task_id": current.task.task_id, "version": current.version + 1, "fencing_token": current.fencing_token,
            }, connection=cx)

    @staticmethod
    def _effective_priority(item: StoredScheduledTask, now) -> int:
        if not item.created_at: return item.task.priority
        age_minutes = max(0, int((now - _parse(item.created_at)).total_seconds() // 60))
        return item.task.priority + min(age_minutes, 1000)

    def claim_ready(self, holder: str, *, limit: int = 1, ttl_seconds: int = 900) -> list[StoredScheduledTask]:
        if not holder: raise ValueError("holder is required")
        if limit <= 0: raise ValueError("limit must be > 0")
        if ttl_seconds <= 0 or ttl_seconds > 86_400: raise ValueError("ttl_seconds must be > 0 and <= 86400")
        self.store.assert_clock_sane()
        now = _utcnow(); expires = _iso(now + timedelta(seconds=ttl_seconds)); now_iso = _iso(now); selected_ids: list[str] = []
        with self.store.session() as cx:
            cx.execute("BEGIN IMMEDIATE"); self._recover_expired(cx, now)
            stored = [self._from_row(row) for row in cx.execute("SELECT * FROM scheduled_tasks").fetchall()]
            done = {x.task.task_id for x in stored if x.status is ScheduleStatus.DONE}
            running = [x.task for x in stored if x.status is ScheduleStatus.RUNNING]
            pending = [x for x in stored if x.status is ScheduleStatus.PENDING and x.task.dependencies <= done]
            pending.sort(key=lambda x: (-self._effective_priority(x, now), x.created_at or "", x.task.task_id))
            selected_tasks: list[StoredScheduledTask] = []
            for row in pending:
                if any(conflicts(row.task, r) for r in running + [x.task for x in selected_tasks]): continue
                selected_tasks.append(row)
                if len(selected_tasks) >= limit: break
            for row in selected_tasks:
                fence = row.fencing_token + 1
                cur = cx.execute(
                    """UPDATE scheduled_tasks SET status=?,holder=?,lease_expires_at=?,fencing_token=?,attempts=?,version=?,updated_at=?
                       WHERE task_id=? AND status=? AND version=?""",
                    (ScheduleStatus.RUNNING.value, holder, expires, fence, row.attempts + 1, row.version + 1, now_iso,
                     row.task.task_id, ScheduleStatus.PENDING.value, row.version),
                )
                if cur.rowcount != 1: raise ConcurrencyConflict(f"scheduled task {row.task.task_id!r} changed during claim")
                self.store.append_control_event(f"scheduler:{row.task.task_id}", "SCHEDULE_TASK_CLAIMED", {
                    "task_id": row.task.task_id, "holder": holder, "lease_expires_at": expires, "fencing_token": fence,
                    "attempt": row.attempts + 1, "version": row.version + 1,
                }, connection=cx); selected_ids.append(row.task.task_id)
        return [item for task_id in selected_ids if (item := self.get(task_id)) is not None]

    def validate_fence(self, task_id: str, holder: str, fencing_token: int) -> StoredScheduledTask:
        current = self.get(task_id)
        if current is None: raise KeyError(task_id)
        if current.status is not ScheduleStatus.RUNNING or current.holder != holder:
            raise LeaseConflict(f"scheduled task {task_id!r} is not actively held by {holder!r}")
        if current.fencing_token != fencing_token:
            raise LeaseConflict(f"stale fencing token for {task_id!r}: supplied={fencing_token} current={current.fencing_token}")
        if not current.lease_expires_at or _parse(current.lease_expires_at) <= _utcnow():
            raise LeaseConflict(f"scheduled task {task_id!r} claim expired")
        return current

    def authorize_effect(self, task_id: str, holder: str, *, fencing_token: int, event_id: str) -> bool:
        current = self.validate_fence(task_id, holder, fencing_token)
        if current.task.execution_kind is ExecutionKind.READ_ONLY:
            raise LeaseConflict("read-only scheduled task may not authorize an external side effect")
        expected_event = current.task.idempotency_key
        if not expected_event or event_id != expected_event:
            raise LeaseConflict(f"external effect event_id must equal scheduled idempotency_key {expected_event!r}")
        # Authorization is idempotent within a fencing generation, but it must not
        # consume the business idempotency key forever before the external effect
        # actually happens. A crash after authorization but before the provider call
        # may be reconciled and retried under a new fence; the provider still sees the
        # same stable idempotency_key and is responsible for deduplicating the effect.
        namespace = f"scheduler-effect:{task_id}:fence:{fencing_token}"
        self.store.accept_idempotent_event(namespace, event_id)
        return True

    def complete(self, task_id: str, holder: str, *, expected_version: int, fencing_token: int | None = None) -> StoredScheduledTask:
        now = _utcnow(); self.store.assert_clock_sane()
        with self.store.session() as cx:
            cx.execute("BEGIN IMMEDIATE"); row = cx.execute("SELECT * FROM scheduled_tasks WHERE task_id=?", (task_id,)).fetchone()
            if row is None: raise KeyError(task_id)
            current = self._from_row(row)
            if current.version != expected_version: raise ConcurrencyConflict(f"scheduled task {task_id!r} stale version: expected={expected_version}, actual={current.version}")
            if current.status is not ScheduleStatus.RUNNING or current.holder != holder: raise LeaseConflict(f"scheduled task {task_id!r} is not actively held by {holder!r}")
            if fencing_token is None or fencing_token != current.fencing_token: raise LeaseConflict(f"completion requires current fencing_token={current.fencing_token}")
            if not current.lease_expires_at or _parse(current.lease_expires_at) <= now: raise LeaseConflict(f"scheduled task {task_id!r} claim expired")
            journal_state = _linked_journal_state(cx, task_id)
            if journal_state is not None and journal_state != "DONE":
                raise LeaseConflict(f"scheduled task {task_id!r} is linked to TaskJournal state {journal_state!r}; scheduler completion requires authoritative task state DONE")
            cx.execute("""UPDATE scheduled_tasks SET status=?,holder=NULL,lease_expires_at=NULL,version=?,updated_at=? WHERE task_id=? AND version=?""",
                       (ScheduleStatus.DONE.value, current.version + 1, _iso(now), task_id, current.version))
            self.store.append_control_event(f"scheduler:{task_id}", "SCHEDULE_TASK_COMPLETED", {
                "task_id": task_id, "holder": holder, "fencing_token": current.fencing_token, "version": current.version + 1,
            }, connection=cx)
        result = self.get(task_id); assert result is not None; return result

    def reconcile_orphan(self, task_id: str, *, outcome: str, expected_version: int, external_state: str) -> StoredScheduledTask:
        if outcome not in {"retry", "done"}: raise ValueError("outcome must be retry or done")
        if not external_state or not external_state.strip():
            raise ValueError("orphan reconciliation requires a non-empty external_state observation")
        with self.store.session() as cx:
            cx.execute("BEGIN IMMEDIATE"); row = cx.execute("SELECT * FROM scheduled_tasks WHERE task_id=?", (task_id,)).fetchone()
            if row is None: raise KeyError(task_id)
            current = self._from_row(row)
            if current.version != expected_version: raise ConcurrencyConflict(f"scheduled task {task_id!r} stale version")
            if current.status is not ScheduleStatus.ORPHANED: raise LeaseConflict("only ORPHANED side-effect tasks may be reconciled")
            status = ScheduleStatus.PENDING if outcome == "retry" else ScheduleStatus.DONE
            if status is ScheduleStatus.DONE:
                journal_state = _linked_journal_state(cx, task_id)
                if journal_state is not None and journal_state != "DONE":
                    raise LeaseConflict(f"orphan reconciliation cannot mark linked task DONE while TaskJournal state is {journal_state!r}")
            cx.execute("UPDATE scheduled_tasks SET status=?,version=?,updated_at=? WHERE task_id=? AND version=?",
                       (status.value, current.version + 1, _iso(_utcnow()), task_id, current.version))
            self.store.append_control_event(f"scheduler:{task_id}", "SCHEDULE_ORPHAN_RECONCILED", {
                "task_id": task_id, "outcome": outcome, "external_state": external_state, "version": current.version + 1,
            }, connection=cx)
        result = self.get(task_id); assert result is not None; return result

    def abandon(self, task_id: str, holder: str, *, expected_version: int, fencing_token: int | None = None) -> StoredScheduledTask:
        with self.store.session() as cx:
            cx.execute("BEGIN IMMEDIATE"); row = cx.execute("SELECT * FROM scheduled_tasks WHERE task_id=?", (task_id,)).fetchone()
            if row is None: raise KeyError(task_id)
            current = self._from_row(row)
            if current.version != expected_version: raise ConcurrencyConflict(f"scheduled task {task_id!r} stale version: expected={expected_version}, actual={current.version}")
            if current.status is not ScheduleStatus.RUNNING or current.holder != holder: raise LeaseConflict(f"scheduled task {task_id!r} is not held by {holder!r}")
            if fencing_token is None or fencing_token != current.fencing_token: raise LeaseConflict(f"abandon requires current fencing_token={current.fencing_token}")
            if current.task.execution_kind is ExecutionKind.SIDE_EFFECTING:
                target = ScheduleStatus.ORPHANED
            else:
                target = ScheduleStatus.PENDING
            cx.execute("UPDATE scheduled_tasks SET status=?,holder=NULL,lease_expires_at=NULL,version=?,updated_at=? WHERE task_id=? AND version=?",
                       (target.value, current.version + 1, _iso(_utcnow()), task_id, current.version))
            self.store.append_control_event(f"scheduler:{task_id}", "SCHEDULE_TASK_ABANDONED", {
                "task_id": task_id, "holder": holder, "fencing_token": current.fencing_token, "target": target.value, "version": current.version + 1,
            }, connection=cx)
        result = self.get(task_id); assert result is not None; return result
