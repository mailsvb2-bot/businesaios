from __future__ import annotations

from dataclasses import dataclass

from .models import GateResult, GateStatus


@dataclass(frozen=True)
class TenantAccessAttempt:
    actor_tenant: str
    resource_tenant: str
    operation: str


def tenant_isolation_gate(attempt: TenantAccessAttempt) -> GateResult:
    if attempt.actor_tenant != attempt.resource_tenant:
        return GateResult("tenant_isolation", GateStatus.FAIL, f"cross-tenant {attempt.operation} denied")
    return GateResult("tenant_isolation", GateStatus.PASS, "tenant boundary preserved")
