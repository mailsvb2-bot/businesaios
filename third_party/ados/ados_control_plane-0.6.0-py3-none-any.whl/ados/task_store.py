from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .event_store import ConcurrencyConflict, EventStore
from .models import Candidate, RiskLevel, Task, TaskState
from .state_machine import TransitionGuard, transition


class TaskNotFound(KeyError):
    pass


class TaskAlreadyExists(ValueError):
    pass


@dataclass(frozen=True)
class StoredTask:
    task: Task
    version: int


class TaskJournal:
    """Persistent task state reconstructed from append-only events.

    The journal deliberately stores only process state. Repository code, requirements,
    and mutable GitHub facts remain external canonical sources.
    """

    def __init__(self, store: EventStore):
        self.store = store

    def create(self, task: Task) -> StoredTask:
        if self.store.last_event_id(task.task_id):
            raise TaskAlreadyExists(task.task_id)
        event_id = self.store.append_event(
            task.task_id,
            "TASK_CREATED",
            {
                "repository": task.repository,
                "goal": task.goal,
                "base_sha": task.base_sha,
                "base_ref": task.base_ref,
                "state": task.state.value,
                "risk": task.risk.value,
                "metadata": task.metadata,
            },
            generation=task.candidate.generation if task.candidate else None,
            expected_last_id=0,
        )
        if task.candidate is not None:
            event_id = self.store.append_event(
                task.task_id,
                "CANDIDATE_SET",
                {"candidate": task.candidate.__dict__},
                generation=task.candidate.generation,
                expected_last_id=event_id,
            )
        return StoredTask(self.load(task.task_id).task, event_id)

    def load(self, task_id: str) -> StoredTask:
        events = self.store.events(task_id)
        if not events:
            raise TaskNotFound(task_id)
        task: Task | None = None
        for event in events:
            kind = event["event_type"]
            payload = event["payload"]
            if kind == "TASK_CREATED":
                task = Task(
                    task_id=task_id,
                    repository=payload["repository"],
                    goal=payload["goal"],
                    base_sha=payload.get("base_sha"),
                    base_ref=payload.get("base_ref"),
                    state=TaskState(payload.get("state", TaskState.READY.value)),
                    risk=RiskLevel(payload.get("risk", RiskLevel.MEDIUM.value)),
                    metadata=dict(payload.get("metadata", {})),
                )
            elif task is None:
                raise ValueError(f"task {task_id!r} journal starts with {kind!r}, expected TASK_CREATED")
            elif kind == "CANDIDATE_SET":
                c = payload["candidate"]
                task.candidate = Candidate(
                    repository=c["repository"],
                    branch=c["branch"],
                    sha=c["sha"],
                    tree=c.get("tree"),
                    generation=int(c["generation"]),
                )
            elif kind == "BASE_REANCHORED":
                task.base_sha = payload["base_sha"]
                task.base_ref = payload["base_ref"]
            elif kind == "STATE_TRANSITIONED":
                task.state = TaskState(payload["to"])
            elif kind == "BLOCKER_ADDED":
                blocker = payload["blocker"]
                if blocker not in task.blockers:
                    task.blockers.append(blocker)
            elif kind == "BLOCKER_CLEARED":
                blocker = payload["blocker"]
                task.blockers = [x for x in task.blockers if x != blocker]
            elif kind == "TASK_METADATA_PATCHED":
                task.metadata.update(payload.get("patch", {}))
        assert task is not None
        return StoredTask(task, int(events[-1]["id"]))

    def set_candidate(
        self,
        task_id: str,
        *,
        branch: str,
        sha: str,
        tree: str | None = None,
        expected_version: int,
    ) -> StoredTask:
        current = self.load(task_id)
        if current.version != expected_version:
            raise ConcurrencyConflict(f"task {task_id!r} stale version: expected={expected_version}, actual={current.version}")
        previous = current.task.candidate
        if previous is not None and previous.sha == sha and previous.branch == branch and previous.tree == tree:
            return current
        generation = 1 if previous is None else previous.generation + 1
        candidate = Candidate(current.task.repository, branch, sha, tree, generation)
        event_id = self.store.append_event(
            task_id,
            "CANDIDATE_SET",
            {"candidate": candidate.__dict__},
            generation=generation,
            expected_last_id=expected_version,
        )
        return StoredTask(self.load(task_id).task, event_id)

    def reanchor_base(
        self,
        task_id: str,
        *,
        base_ref: str,
        base_sha: str,
        expected_version: int,
    ) -> StoredTask:
        current = self.load(task_id)
        if current.version != expected_version:
            raise ConcurrencyConflict(f"task {task_id!r} stale version: expected={expected_version}, actual={current.version}")
        if current.task.state in {TaskState.READY_TO_RELEASE, TaskState.RELEASING, TaskState.DONE}:
            raise ValueError(f"cannot re-anchor base while task is {current.task.state.value}; move it back to WORKING first")
        if current.task.base_sha == base_sha and current.task.base_ref == base_ref:
            return current
        event_id = self.store.append_event(
            task_id,
            "BASE_REANCHORED",
            {"base_ref": base_ref, "base_sha": base_sha},
            generation=current.task.candidate.generation if current.task.candidate else None,
            expected_last_id=expected_version,
        )
        # Base identity is an input to validation. Bump candidate generation even
        # if candidate bytes are unchanged so old signed evidence cannot authorize
        # a release after a base re-anchor.
        if current.task.candidate is not None:
            old = current.task.candidate
            candidate = Candidate(old.repository, old.branch, old.sha, old.tree, old.generation + 1)
            event_id = self.store.append_event(
                task_id,
                "CANDIDATE_SET",
                {"candidate": candidate.__dict__},
                generation=candidate.generation,
                expected_last_id=event_id,
            )
        return StoredTask(self.load(task_id).task, event_id)

    def transition(
        self,
        task_id: str,
        target: TaskState,
        *,
        expected_version: int,
        guard: TransitionGuard | None = None,
    ) -> StoredTask:
        current = self.load(task_id)
        if current.version != expected_version:
            raise ConcurrencyConflict(f"task {task_id!r} stale version: expected={expected_version}, actual={current.version}")
        old = current.task.state
        transition(current.task, target, guard=guard)
        generation = current.task.candidate.generation if current.task.candidate else None
        event_id = self.store.append_event(
            task_id,
            "STATE_TRANSITIONED",
            {"from": old.value, "to": target.value},
            generation=generation,
            expected_last_id=expected_version,
        )
        return StoredTask(self.load(task_id).task, event_id)

    def add_blocker(self, task_id: str, blocker: str, *, expected_version: int) -> StoredTask:
        current = self.load(task_id)
        if current.version != expected_version:
            raise ConcurrencyConflict(f"task {task_id!r} stale version: expected={expected_version}, actual={current.version}")
        event_id = self.store.append_event(
            task_id,
            "BLOCKER_ADDED",
            {"blocker": blocker},
            generation=current.task.candidate.generation if current.task.candidate else None,
            expected_last_id=expected_version,
        )
        return StoredTask(self.load(task_id).task, event_id)

    def clear_blocker(self, task_id: str, blocker: str, *, expected_version: int) -> StoredTask:
        current = self.load(task_id)
        if current.version != expected_version:
            raise ConcurrencyConflict(f"task {task_id!r} stale version: expected={expected_version}, actual={current.version}")
        event_id = self.store.append_event(
            task_id,
            "BLOCKER_CLEARED",
            {"blocker": blocker},
            generation=current.task.candidate.generation if current.task.candidate else None,
            expected_last_id=expected_version,
        )
        return StoredTask(self.load(task_id).task, event_id)

    def patch_metadata(self, task_id: str, patch: dict[str, Any], *, expected_version: int) -> StoredTask:
        current = self.load(task_id)
        if current.version != expected_version:
            raise ConcurrencyConflict(f"task {task_id!r} stale version: expected={expected_version}, actual={current.version}")
        event_id = self.store.append_event(
            task_id,
            "TASK_METADATA_PATCHED",
            {"patch": patch},
            generation=current.task.candidate.generation if current.task.candidate else None,
            expected_last_id=expected_version,
        )
        return StoredTask(self.load(task_id).task, event_id)
