from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
from contextlib import contextmanager
from pathlib import Path

from .models import Candidate, GateResult, GateStatus


HEX40 = re.compile(r"^[0-9a-f]{40}$")


def _git(root: Path, *args: str, timeout: float = 15.0) -> str:
    proc = subprocess.run(
        ["git", *args],
        cwd=root,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or f"git {' '.join(args)} failed with rc={proc.returncode}")
    return proc.stdout.strip()


def verify_exact_candidate(root: Path, candidate: Candidate, *, require_clean: bool = True) -> GateResult:
    root = root.resolve()
    if not HEX40.fullmatch(candidate.sha.lower()):
        return GateResult("candidate_identity", GateStatus.FAIL, "candidate SHA must be full 40-hex commit identity")
    if candidate.tree is None or not HEX40.fullmatch(candidate.tree.lower()):
        return GateResult("candidate_identity", GateStatus.FAIL, "candidate tree must be full 40-hex tree identity")
    try:
        head = _git(root, "rev-parse", "HEAD").lower()
        tree = _git(root, "rev-parse", "HEAD^{tree}").lower()
        status = _git(root, "status", "--porcelain=v1", "--untracked-files=all")
    except (OSError, subprocess.TimeoutExpired, RuntimeError) as exc:
        return GateResult("candidate_identity", GateStatus.FAIL, f"cannot verify exact Git candidate: {type(exc).__name__}: {exc}")
    if head != candidate.sha.lower():
        return GateResult("candidate_identity", GateStatus.FAIL, f"working copy HEAD mismatch: expected={candidate.sha} actual={head}")
    if tree != candidate.tree.lower():
        return GateResult("candidate_identity", GateStatus.FAIL, f"working copy tree mismatch: expected={candidate.tree} actual={tree}")
    if require_clean and status:
        return GateResult("candidate_identity", GateStatus.FAIL, "working tree is not clean; exact-candidate certification refused", {"status": status.splitlines()[:50]})
    return GateResult("candidate_identity", GateStatus.PASS, "exact Git candidate identity verified", {"sha": head, "tree": tree})


def resolve_commit(root: Path, ref: str) -> str:
    """Resolve a trusted local Git ref to an immutable full commit SHA."""
    root = root.resolve()
    value = _git(root, "rev-parse", "--verify", f"{ref}^{{commit}}").lower()
    if not HEX40.fullmatch(value):
        raise RuntimeError(f"Git ref {ref!r} did not resolve to a full commit SHA")
    return value


def resolve_remote_ref(root: Path, remote: str, ref: str, *, timeout: float = 15.0) -> str:
    """Resolve an exact remote ref without mutating local refs.

    This uses read-only ``git ls-remote`` so release truth can be checked against
    the remote repository without trusting a potentially stale local tracking ref.
    """
    if not remote or remote.startswith("-"):
        raise ValueError("remote must be a non-option Git remote or URL")
    if not ref or ref.startswith("-"):
        raise ValueError("ref must be a non-option exact Git ref")
    proc = subprocess.run(
        ["git", "ls-remote", "--exit-code", remote, ref],
        cwd=root.resolve(),
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or f"git ls-remote {remote} {ref} failed with rc={proc.returncode}")
    matches: list[str] = []
    for line in proc.stdout.splitlines():
        parts = line.split("\t", 1)
        if len(parts) != 2 or parts[1] != ref:
            continue
        sha = parts[0].lower()
        if HEX40.fullmatch(sha):
            matches.append(sha)
    matches = list(dict.fromkeys(matches))
    if len(matches) != 1:
        raise RuntimeError(f"remote ref {remote}:{ref} did not resolve to exactly one full commit SHA")
    return matches[0]


def canonical_remote_ref(local_base_ref: str, configured_ref: str | None = None) -> str:
    if configured_ref:
        return configured_ref
    if local_base_ref.startswith("refs/heads/"):
        return local_base_ref
    if local_base_ref.startswith("refs/"):
        raise ValueError("non-branch local base ref requires explicit remote_base.ref")
    return f"refs/heads/{local_base_ref}"


def derive_candidate_diff(root: Path, base_sha: str, candidate_sha: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Derive changed/deleted paths from Git; callers must not self-report release diff.

    Renames are intentionally treated as delete+add (`--no-renames`) so both the old
    and new paths participate in risk/impact analysis.
    """
    root = root.resolve()
    if not HEX40.fullmatch(base_sha.lower()) or not HEX40.fullmatch(candidate_sha.lower()):
        raise ValueError("base and candidate must be full 40-hex Git commit identities")
    ancestor = subprocess.run(
        ["git", "merge-base", "--is-ancestor", base_sha, candidate_sha],
        cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15.0,
    )
    if ancestor.returncode != 0:
        detail = ancestor.stderr.strip() or "base is not an ancestor of candidate"
        raise RuntimeError(detail)

    def names(diff_filter: str) -> tuple[str, ...]:
        proc = subprocess.run(
            ["git", "diff", "--name-only", "-z", "--no-renames", f"--diff-filter={diff_filter}", base_sha, candidate_sha, "--"],
            cwd=root, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30.0,
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.decode("utf-8", "replace").strip() or "git diff failed")
        raw = proc.stdout.split(b"\0")
        result: list[str] = []
        for item in raw:
            if not item:
                continue
            result.append(item.decode("utf-8", "surrogateescape"))
        return tuple(dict.fromkeys(result))

    # A/C/M/T/U/X/B are paths present/changed in the candidate. Deletions are fed
    # separately so SourceGate does not require them to exist on disk.
    changed = names("ACMTUXB")
    deleted = names("D")
    return changed, deleted


def current_branch(root: Path) -> str:
    """Return the current symbolic branch; detached HEAD requires explicit base ref."""
    value = _git(root.resolve(), "symbolic-ref", "--quiet", "--short", "HEAD")
    if not value:
        raise RuntimeError("detached HEAD: provide --base-ref explicitly")
    return value


@contextmanager
def detached_candidate_worktree(
    root: Path,
    candidate_sha: str,
    *,
    materialize_submodules: bool = True,
    materialize_lfs: bool = True,
):
    """Yield an isolated detached checkout of an immutable candidate commit.

    Submodules and Git LFS objects are materialized when the candidate uses them;
    certification must not silently validate a partial checkout. Build/codegen is
    allowed to dirty this disposable snapshot without contaminating the operator's
    working tree.
    """
    root = root.resolve()
    if not HEX40.fullmatch(candidate_sha.lower()):
        raise ValueError("candidate SHA must be full 40-hex commit identity")
    parent = Path(tempfile.mkdtemp(prefix="ados-cert-snapshot-"))
    snapshot = parent / "worktree"
    added = False
    try:
        _git(root, "worktree", "add", "--detach", "--force", str(snapshot), candidate_sha, timeout=60.0)
        added = True
        head = _git(snapshot, "rev-parse", "HEAD").lower()
        if head != candidate_sha.lower():
            raise RuntimeError(f"detached certification snapshot mismatch: expected={candidate_sha} actual={head}")
        if materialize_submodules and (snapshot / ".gitmodules").exists():
            _git(snapshot, "submodule", "sync", "--recursive", timeout=60.0)
            _git(snapshot, "submodule", "update", "--init", "--recursive", "--checkout", timeout=300.0)
            status = _git(snapshot, "submodule", "status", "--recursive", timeout=60.0)
            bad = [line for line in status.splitlines() if line.startswith(("-", "+", "U"))]
            if bad:
                raise RuntimeError(f"submodule materialization is not exact: {bad[:10]}")
        if materialize_lfs:
            attrs = snapshot / ".gitattributes"
            uses_lfs = attrs.exists() and "filter=lfs" in attrs.read_text(encoding="utf-8", errors="ignore")
            if uses_lfs:
                try:
                    _git(snapshot, "lfs", "version", timeout=15.0)
                    _git(snapshot, "lfs", "pull", timeout=300.0)
                    _git(snapshot, "lfs", "checkout", timeout=300.0)
                except Exception as exc:
                    raise RuntimeError(f"candidate uses Git LFS but LFS objects could not be materialized: {exc}") from exc
        yield snapshot
    finally:
        if added:
            try:
                _git(root, "worktree", "remove", "--force", str(snapshot), timeout=60.0)
            except Exception:
                # Cleanup is best-effort here; the certification caller still fails
                # closed on any exception raised from the body. Prune stale metadata.
                try:
                    shutil.rmtree(snapshot, ignore_errors=True)
                    _git(root, "worktree", "prune", timeout=30.0)
                except Exception:
                    pass
        shutil.rmtree(parent, ignore_errors=True)


def repository_remote_identity(root: Path, remote: str = "origin") -> tuple[str | None, str] | None:
    """Return ``(network_host, owner/repo path)`` for a configured remote.

    The logical repository identity deliberately excludes transport/host so tasks
    use stable ``owner/repo`` identities across SSH/HTTPS.  The host is returned
    separately and may be pinned by protected remote-base policy to prevent an
    attacker from redirecting ``origin`` to a different Git service with the same
    path. Local filesystem remotes have no network host and are returned as None.
    """
    try:
        url = _git(root.resolve(), "remote", "get-url", remote)
    except Exception:
        return None
    value = url.strip()
    if not value:
        return None
    host: str | None
    path: str
    # SCP-like git@github.com:owner/repo.git. Do not classify Windows drive
    # letters (C:\...) as network remotes.
    if "://" not in value and ":" in value and not re.match(r"^[A-Za-z]:[\\/]", value):
        hostpart, path = value.split(":", 1)
        host = hostpart.split("@")[-1].lower() or None
    elif "://" in value:
        from urllib.parse import urlparse
        parsed = urlparse(value)
        host = (parsed.hostname or "").lower() or None
        path = parsed.path.lstrip("/")
    else:
        return None
    if path.endswith(".git"):
        path = path[:-4]
    path = path.strip("/")
    if not host or "/" not in path:
        return None
    return host, path


def repository_identity_from_remote(root: Path, remote: str = "origin") -> str | None:
    identity = repository_remote_identity(root, remote)
    return None if identity is None else identity[1]


def repository_host_from_remote(root: Path, remote: str = "origin") -> str | None:
    identity = repository_remote_identity(root, remote)
    return None if identity is None else identity[0]


def git_remote_exists(root: Path, remote: str = "origin") -> bool:
    try:
        names = _git(root.resolve(), "remote").splitlines()
    except Exception:
        return False
    return remote in names
