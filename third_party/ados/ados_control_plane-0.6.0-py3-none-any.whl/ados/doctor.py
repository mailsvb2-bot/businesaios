from __future__ import annotations

import os
import sqlite3
import tempfile
from dataclasses import dataclass, asdict
from pathlib import Path

from .adapter_manifest import AdapterManifestError, load_manifest_adapters
from .command_gates import CommandGateConfigError, load_command_gates
from .event_store import EventStore
from .git_identity import _git
from .impact import ImpactModel
from .policy import Constitution
from .project_config import ProjectConfig
from .orchestrator import STRICT_GATE_ASSURANCES
from .provenance import BuildSpec
from .crypto import load_public_key, public_key_fingerprint
from .git_identity import git_remote_exists, repository_host_from_remote, repository_identity_from_remote


@dataclass(frozen=True)
class DoctorCheck:
    name: str
    status: str
    detail: str

    def to_dict(self):
        return asdict(self)


def _config_check(name: str, path: Path, loader) -> DoctorCheck:
    if not path.exists():
        return DoctorCheck(name, "FAIL", f"missing {path}")
    try:
        loader(path)
    except Exception as exc:
        return DoctorCheck(name, "FAIL", f"{type(exc).__name__}: {exc}")
    return DoctorCheck(name, "PASS", str(path))


def _durability_check(directory: Path) -> DoctorCheck:
    directory.mkdir(parents=True, exist_ok=True)
    fd = None
    tmp = None
    try:
        fd, tmp = tempfile.mkstemp(prefix=".ados-doctor-", dir=str(directory))
        with os.fdopen(fd, "wb") as fh:
            fd = None
            fh.write(b"durability-probe")
            fh.flush()
            os.fsync(fh.fileno())
        os.unlink(tmp)
        tmp = None
        return DoctorCheck("filesystem_durability", "PASS", f"fsync works in {directory}")
    except OSError as exc:
        return DoctorCheck("filesystem_durability", "FAIL", f"fsync failed in {directory}: {exc}")
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
        if tmp is not None:
            try:
                os.unlink(tmp)
            except OSError:
                pass


def _sqlite_check(directory: Path) -> DoctorCheck:
    path = directory / ".ados-doctor.sqlite"
    try:
        store = EventStore(path)
        store.append_event("DOCTOR", "PROBE", {"ok": True}, expected_last_id=0)
        if not store.verify_event_chain("DOCTOR"):
            return DoctorCheck("sqlite_control_plane", "FAIL", "SQLite event-chain probe failed")
        return DoctorCheck("sqlite_control_plane", "PASS", "SQLite/WAL/event-chain probe passed")
    except (sqlite3.Error, OSError, RuntimeError) as exc:
        return DoctorCheck("sqlite_control_plane", "FAIL", f"{type(exc).__name__}: {exc}")
    finally:
        for suffix in ("", "-wal", "-shm"):
            try:
                (Path(str(path) + suffix)).unlink()
            except OSError:
                pass


def _project_manifest_check(root: Path, constitution: Constitution, label: str, rel_path: str, loader) -> DoctorCheck:
    rel = Path(rel_path)
    if rel.is_absolute() or ".." in rel.parts:
        return DoctorCheck(label, "FAIL", f"configured manifest path escapes repository: {rel_path!r}")
    path = (root / rel).resolve(strict=False)
    try:
        path.relative_to(root)
    except ValueError:
        return DoctorCheck(label, "FAIL", f"configured manifest resolves outside repository: {rel_path!r}")
    normalized = rel.as_posix()
    if not constitution.is_protected_path(normalized):
        return DoctorCheck(label, "FAIL", f"configured manifest is not protected by constitution: {normalized}")
    if not path.exists():
        return DoctorCheck(label, "SKIP", f"configured manifest not present: {normalized}")
    try:
        loaded = loader(root, path)
    except Exception as exc:
        return DoctorCheck(label, "FAIL", f"{type(exc).__name__}: {exc}")
    return DoctorCheck(label, "PASS", f"verified gates={sorted(loaded)} path={normalized}")



def _trust_check(root: Path, project: ProjectConfig) -> DoctorCheck:
    if not project.trust.evidence_public_key_files:
        return DoctorCheck("evidence_trust", "WARN", "no asymmetric evidence public keys configured; release is intentionally unavailable")
    ids: list[str] = []
    try:
        for rel in project.trust.evidence_public_key_files:
            path = (root / rel).resolve()
            path.relative_to(root)
            key = load_public_key(path.read_bytes())
            ids.append(public_key_fingerprint(key))
    except Exception as exc:
        return DoctorCheck("evidence_trust", "FAIL", f"{type(exc).__name__}: {exc}")
    return DoctorCheck("evidence_trust", "PASS", f"trusted asymmetric signers={ids}")


def _runner_trust_check(root: Path, project: ProjectConfig) -> DoctorCheck:
    if not project.trust.require_runner_attestation_for_certification:
        return DoctorCheck("runner_trust", "WARN", "strict certification runner attestation is disabled; release execution is not independently attested")
    if not project.trust.runner_public_key_files:
        return DoctorCheck("runner_trust", "WARN", "runner attestation is required but no runner public keys are configured; certification is intentionally unavailable")
    ids: list[str] = []
    try:
        for rel in project.trust.runner_public_key_files:
            path = (root / rel).resolve()
            path.relative_to(root)
            key = load_public_key(path.read_bytes())
            ids.append(public_key_fingerprint(key))
    except Exception as exc:
        return DoctorCheck("runner_trust", "FAIL", f"{type(exc).__name__}: {exc}")
    return DoctorCheck("runner_trust", "PASS", f"trusted disposable-runner signers={ids}")


def _vulnerability_trust_check(root: Path, project: ProjectConfig) -> DoctorCheck:
    if not project.trust.require_vulnerability_attestation_for_release:
        return DoctorCheck(
            "vulnerability_trust", "WARN",
            "release vulnerability attestation is disabled; strict dependency intelligence is not independently attested",
        )
    if not project.trust.vulnerability_public_key_files:
        return DoctorCheck(
            "vulnerability_trust", "WARN",
            "vulnerability attestation is required but no scanner public keys are configured; release is intentionally unavailable",
        )
    ids: list[str] = []
    try:
        for rel in project.trust.vulnerability_public_key_files:
            path = (root / rel).resolve()
            path.relative_to(root)
            key = load_public_key(path.read_bytes())
            ids.append(public_key_fingerprint(key))
    except Exception as exc:
        return DoctorCheck("vulnerability_trust", "FAIL", f"{type(exc).__name__}: {exc}")
    return DoctorCheck(
        "vulnerability_trust", "PASS",
        f"trusted vulnerability-scanner signers={ids}; max_severity={project.trust.vulnerability_max_severity}",
    )


def _deployment_trust_check(root: Path, project: ProjectConfig) -> DoctorCheck:
    if not project.trust.require_deployment_attestation_for_health:
        return DoctorCheck(
            "deployment_trust", "WARN",
            "deployment attestation is disabled; production health is not bound to the certified artifact",
        )
    if not project.trust.deployment_public_key_files:
        return DoctorCheck(
            "deployment_trust", "WARN",
            "production health requires deployment attestation but no deployment public keys are configured",
        )
    ids: list[str] = []
    try:
        for rel in project.trust.deployment_public_key_files:
            path = (root / rel).resolve()
            path.relative_to(root)
            key = load_public_key(path.read_bytes())
            ids.append(public_key_fingerprint(key))
    except Exception as exc:
        return DoctorCheck("deployment_trust", "FAIL", f"{type(exc).__name__}: {exc}")
    return DoctorCheck(
        "deployment_trust", "PASS",
        f"trusted deployment/health signers={ids}; environment={project.trust.deployment_environment!r}",
    )


def _repository_identity_check(root: Path, project: ProjectConfig) -> DoctorCheck:
    if not project.repository_id:
        return DoctorCheck("repository_identity", "WARN", "repository_id is missing; development is allowed but release certification is unavailable")
    if project.repository_id.startswith("local/"):
        return DoctorCheck("repository_identity", "WARN", f"development-only identity {project.repository_id!r}; release requires a canonical remote identity")
    if not git_remote_exists(root, project.remote_base.remote):
        return DoctorCheck("repository_identity", "WARN", f"remote {project.remote_base.remote!r} not configured; release remote truth cannot be verified")
    remote_host = repository_host_from_remote(root, project.remote_base.remote)
    derived = repository_identity_from_remote(root, project.remote_base.remote)
    # A filesystem/bare remote has no independently verifiable network identity.
    # It is acceptable only when the anchored project policy explicitly opts in
    # to the test/offline exception; in that mode the protected repository_id is
    # authoritative and doctor must not contradict the release verifier.
    if remote_host is None and project.remote_base.allow_local_filesystem_for_release:
        return DoctorCheck(
            "repository_identity", "WARN",
            "trusted base explicitly allows local/filesystem remotes for release; "
            "logical repository identity cannot be independently derived and this mode is intended only for test/offline environments",
        )
    if derived != project.repository_id:
        return DoctorCheck("repository_identity", "FAIL", f"protected={project.repository_id!r} remote={derived!r}")
    if remote_host is not None and project.remote_base.host is None:
        return DoctorCheck(
            "repository_identity", "WARN",
            f"repository path verified as {derived!r}, but network host {remote_host!r} is not pinned in remote_base.host; release is unavailable",
        )
    if project.remote_base.host is not None and remote_host != project.remote_base.host:
        return DoctorCheck("repository_identity", "FAIL", f"protected host={project.remote_base.host!r} remote host={remote_host!r}")
    if remote_host is None:
        return DoctorCheck(
            "repository_identity", "WARN",
            "configured remote has no verifiable network host; production release is unavailable",
        )
    detail = derived or project.repository_id
    if remote_host:
        detail += f" via {remote_host}"
    return DoctorCheck("repository_identity", "PASS", detail)


def _build_manifest_check(root: Path, project: ProjectConfig) -> DoctorCheck:
    path = root / project.build_manifest
    if not path.exists():
        return DoctorCheck("build_manifest", "WARN", f"missing {project.build_manifest}; release artifact provenance unavailable")
    try:
        spec = BuildSpec.from_file(path)
    except Exception as exc:
        return DoctorCheck("build_manifest", "FAIL", f"{type(exc).__name__}: {exc}")
    if project.require_hermetic_build:
        return DoctorCheck("build_manifest", "WARN", "project requires hermetic build; reference local builder never over-claims hermeticity and needs an external supported hermetic builder")
    return DoctorCheck("build_manifest", "PASS", f"artifact_glob={spec.artifact_glob!r} timeout={spec.timeout_seconds}s")


def _gate_coverage_check(root: Path, project: ProjectConfig) -> DoctorCheck:
    manifest = root / project.command_manifest
    if not manifest.exists():
        return DoctorCheck("release_gate_coverage", "WARN", f"release not ready; command manifest missing: {project.command_manifest}")
    try:
        gates = load_command_gates(root, manifest)
    except Exception as exc:
        return DoctorCheck("release_gate_coverage", "FAIL", f"{type(exc).__name__}: {exc}")
    required = {"architecture", "tests", "full_regression", "dependency_audit", "release"}
    capability_map = {
        "ui": {"wiring", "ux", "accessibility", "user_journey"},
        "external_integrations": {"contracts", "integration", "wiring"},
        "multi_tenant": {"tenant_isolation"},
        "document_generation": {"golden", "user_journey"},
        "runtime_library": {"contracts", "compatibility"},
        "payments": {"security", "contracts", "integration"},
        "persistent_data": {"data_migration", "security"},
    }
    for capability in project.capabilities:
        required.update(capability_map.get(capability, ()))
    missing = sorted(required - set(gates))
    if missing:
        return DoctorCheck("release_gate_coverage", "WARN", f"release not ready; configure measured command gates: {missing}")
    assurance_failures: dict[str, list[str]] = {}
    for name in sorted(required):
        gate = gates.get(name)
        required_assurances = STRICT_GATE_ASSURANCES.get(name, frozenset())
        declared = set(getattr(getattr(gate, "spec", None), "assurances", ()))
        missing_assurances = sorted(required_assurances - declared)
        if missing_assurances:
            assurance_failures[name] = missing_assurances
    if assurance_failures:
        return DoctorCheck(
            "release_gate_coverage", "WARN",
            f"release not ready; gate assurance contracts missing: {assurance_failures}",
        )
    return DoctorCheck("release_gate_coverage", "PASS", f"measured project gates={sorted(gates)}")


def _supply_chain_readiness(root: Path) -> DoctorCheck:
    failures: list[str] = []
    if (root / "pyproject.toml").exists() and not any((root / x).exists() for x in ("uv.lock", "poetry.lock", "Pipfile.lock", "requirements.lock")):
        failures.append("Python lockfile missing")
    if (root / "package.json").exists() and not any((root / x).exists() for x in ("package-lock.json", "pnpm-lock.yaml", "yarn.lock")):
        failures.append("Node lockfile missing")
    if (root / "Cargo.toml").exists() and not (root / "Cargo.lock").exists():
        failures.append("Cargo.lock missing")
    sbom = root / ".ados/sbom.json"
    if not sbom.exists():
        failures.append(".ados/sbom.json missing")
    else:
        try:
            import json
            raw = json.loads(sbom.read_text(encoding="utf-8"))
            if not isinstance(raw.get("components"), list):
                failures.append("SBOM components list missing")
        except Exception as exc:
            failures.append(f"SBOM invalid: {exc}")
    return DoctorCheck("supply_chain_readiness", "PASS" if not failures else "WARN", "ready" if not failures else "; ".join(failures))

def run_doctor(root: Path) -> list[DoctorCheck]:
    root = root.resolve()
    checks: list[DoctorCheck] = []
    constitution_path = root / ".ados/constitution.json"
    impact_path = root / ".ados/impact.json"
    project_path = root / ".ados/project.json"
    checks.append(_config_check("constitution", constitution_path, Constitution.from_file))
    checks.append(_config_check("impact", impact_path, ImpactModel.from_file))
    checks.append(_config_check("project", project_path, ProjectConfig.from_file))

    try:
        inside = _git(root, "rev-parse", "--is-inside-work-tree")
        if inside.lower() != "true":
            raise RuntimeError("path is not inside a Git working tree")
        try:
            head = _git(root, "rev-parse", "HEAD")
            tree = _git(root, "rev-parse", "HEAD^{tree}")
        except Exception as exc:
            # A freshly initialized repository has a valid Git control plane but
            # an unborn HEAD until the first commit. That is not a storage/config
            # failure; release certification will still require an exact commit.
            checks.append(DoctorCheck("git_repository", "SKIP", f"Git repository valid but HEAD is unborn: {type(exc).__name__}: {exc}"))
        else:
            checks.append(DoctorCheck("git_repository", "PASS", f"HEAD={head} tree={tree}"))
    except Exception as exc:
        checks.append(DoctorCheck("git_repository", "FAIL", f"{type(exc).__name__}: {exc}"))

    try:
        constitution = Constitution.from_file(constitution_path)
        project = ProjectConfig.from_file(project_path)
    except Exception:
        constitution = None
        project = None

    if constitution is not None and project is not None:
        checks.append(_project_manifest_check(root, constitution, "adapter_manifest", project.adapter_manifest, load_manifest_adapters))
        checks.append(_project_manifest_check(root, constitution, "command_manifest", project.command_manifest, load_command_gates))
        checks.append(_repository_identity_check(root, project))
        checks.append(_trust_check(root, project))
        checks.append(_runner_trust_check(root, project))
        checks.append(_vulnerability_trust_check(root, project))
        checks.append(_deployment_trust_check(root, project))
        checks.append(_build_manifest_check(root, project))
        checks.append(_gate_coverage_check(root, project))
        checks.append(_supply_chain_readiness(root))
        checks.append(DoctorCheck("control_role", "PASS" if project.control_role == "controller_auditor" else "FAIL", project.control_role))
        checks.append(DoctorCheck("storage_scope", "PASS", "SQLite control plane is explicitly single-node; distributed mode is refused rather than emulated"))
    else:
        checks.append(DoctorCheck("adapter_manifest", "SKIP", "project/constitution invalid; manifest verification skipped"))
        checks.append(DoctorCheck("command_manifest", "SKIP", "project/constitution invalid; manifest verification skipped"))

    control_dir = root / ".ados"
    checks.append(_durability_check(control_dir))
    checks.append(_sqlite_check(control_dir))
    return checks
