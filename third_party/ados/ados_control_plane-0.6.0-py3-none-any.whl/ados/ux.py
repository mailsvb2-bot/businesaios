from __future__ import annotations

from dataclasses import dataclass, field

from .models import GateResult, GateStatus


@dataclass
class UXScreen:
    screen_id: str
    states_present: set[str] = field(default_factory=set)
    required_states: set[str] = field(default_factory=lambda: {"normal"})
    keyboard_accessible: bool = False
    labels_present: bool = False
    has_async_action: bool = False
    async_feedback_present: bool = False
    has_error_state: bool = False
    error_has_recovery_action: bool = False
    has_dangerous_action: bool = False
    dangerous_actions_confirmed: bool = False
    has_empty_state: bool = False
    empty_state_has_next_action: bool = False
    responsive_required: bool = False
    responsive_checked: bool = False
    localization_required: bool = False
    localization_checked: bool = False
    accessibility_required: bool = False
    contrast_checked: bool = False
    focus_visible: bool = False
    screen_reader_semantics: bool = False
    zoom_checked: bool = False
    touch_targets_required: bool = False
    touch_targets_checked: bool = False
    heuristics: dict[str, bool] = field(default_factory=dict)
    evidence_refs: dict[str, str] = field(default_factory=dict)


def ux_hard_gate(screen: UXScreen, *, require_measured_evidence: bool = False) -> GateResult:
    failures: list[str] = []
    verified_fields: list[str] = []
    missing_states = screen.required_states - screen.states_present
    if missing_states: failures.append(f"missing states={sorted(missing_states)}")
    else: verified_fields.append("states_present")
    checks = [
        ("keyboard_accessible", screen.keyboard_accessible, "keyboard accessibility not verified"),
        ("labels_present", screen.labels_present, "accessible labels missing"),
    ]
    if screen.has_async_action: checks.append(("async_feedback_present", screen.async_feedback_present, "async loading/success/error feedback missing"))
    if screen.has_error_state: checks.append(("error_has_recovery_action", screen.error_has_recovery_action, "error state is a dead end"))
    if screen.has_dangerous_action: checks.append(("dangerous_actions_confirmed", screen.dangerous_actions_confirmed, "dangerous action lacks confirmation"))
    if screen.has_empty_state: checks.append(("empty_state_has_next_action", screen.empty_state_has_next_action, "empty state lacks next action"))
    if screen.responsive_required: checks.append(("responsive_checked", screen.responsive_checked, "responsive behavior not verified"))
    if screen.localization_required: checks.append(("localization_checked", screen.localization_checked, "localization not verified"))
    if screen.accessibility_required:
        checks.extend([
            ("contrast_checked", screen.contrast_checked, "contrast not verified"),
            ("focus_visible", screen.focus_visible, "visible focus not verified"),
            ("screen_reader_semantics", screen.screen_reader_semantics, "screen-reader semantics not verified"),
            ("zoom_checked", screen.zoom_checked, "zoom/reflow behavior not verified"),
        ])
    if screen.touch_targets_required: checks.append(("touch_targets_checked", screen.touch_targets_checked, "touch target sizing not verified"))
    for field_name, ok, message in checks:
        if not ok: failures.append(message)
        else: verified_fields.append(field_name)
    if failures: return GateResult("ux", GateStatus.FAIL, "; ".join(failures))
    if require_measured_evidence:
        unmeasured = [field_name for field_name in verified_fields if field_name not in screen.evidence_refs]
        if unmeasured:
            return GateResult("ux", GateStatus.UNKNOWN, f"UX assertions lack measured evidence: {unmeasured}")
    return GateResult("ux", GateStatus.PASS, "applicable hard UX rules satisfied", {"heuristics": screen.heuristics, "evidence_refs": screen.evidence_refs})
