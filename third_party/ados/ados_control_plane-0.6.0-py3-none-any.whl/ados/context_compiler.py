from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any

from .models import Task
from .util import stable_hash


ROLE_FIELDS = {
    "builder": ("requirements", "decisions", "architecture", "regressions", "changed_files"),
    "reviewer": ("requirements", "decisions", "architecture", "regressions", "diff", "evidence"),
    "release": ("candidate", "evidence", "release_policy"),
    "production_verifier": ("candidate", "production", "journeys", "rollback"),
}


def compile_context(task: Task, role: str, source: dict[str, Any]) -> dict[str, Any]:
    fields = ROLE_FIELDS.get(role, tuple(source.keys()))
    payload = {
        "task": task.to_dict(),
        "role": role,
        "context": {key: source.get(key) for key in fields if key in source},
    }
    payload["context_hash"] = stable_hash(payload)
    return payload
